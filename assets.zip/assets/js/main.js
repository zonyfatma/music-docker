// Main JavaScript for BeatBay Music Website

function initPageBehaviors() {
	// NOTE: click handlers for `.song-item` are defined inline in views
	// to allow passing full song objects to the player. Avoid binding
	// duplicate handlers here by marking elements after binding.

	// Album card play button handlers
	const playButtons = document.querySelectorAll(".play-overlay");
	playButtons.forEach((button) => {
		if (button.dataset.pjaxBound) return;
		button.dataset.pjaxBound = '1';
		button.addEventListener("click", function (e) {
			e.stopPropagation();
			// Play first song of album
			console.log("Playing album...");
		});
	});

	// Like / Favorite button handlers (centralized server-backed toggle)
	const likeButtons = document.querySelectorAll(".btn-like, .favorite-btn");
	likeButtons.forEach((button) => {
		if (button.dataset.pjaxBound) return;
		button.dataset.pjaxBound = '1';
		button.addEventListener("click", function (e) {
			e.stopPropagation();
			e.preventDefault();

			// Player has its own handler (togglePlayerFavorite), ignore it here
			if (this.id === 'playerLikeBtn') return;

			// Avoid concurrent requests
			if (this.dataset.processing === '1') return;
			this.dataset.processing = '1';

			// Resolve item id and type
			let itemId = this.dataset.itemId || this.dataset.songId || this.dataset.musicId || null;
			const type = this.dataset.type || 'song';

			// fallback: if button is inside .song-item, read that element's data-song-id or data-music-id
			if (!itemId) {
				const parent = this.closest('.song-item, .song-item-profile, .song-card');
				if (parent) itemId = parent.dataset.songId || parent.dataset.musicId || null;
			}

			if (!itemId) {
				console.warn('[favorites] could not determine item id for favorite toggle');
				this.dataset.processing = '0';
				return;
			}

			const icon = this.querySelector('i');
			const url = (window.appBaseUrl || '') + 'profile/toggle_favorite';

			fetch(url, {
				method: 'POST',
				headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'X-Requested-With': 'XMLHttpRequest' },
				body: 'item_id=' + encodeURIComponent(itemId) + '&type=' + encodeURIComponent(type)
			}).then(resp => {
				// If server redirected to login page (user not logged in), redirect the whole page
				if (resp.redirected || (resp.url && resp.url.indexOf('/auth/login') !== -1)) {
					window.location.href = (window.appBaseUrl || '') + 'auth/login';
					return Promise.reject('redirect');
				}
				const ct = resp.headers.get('content-type') || '';
				if (ct.indexOf('application/json') === -1) {
					// Unexpected HTML response (probably login). Redirect to login.
					window.location.href = (window.appBaseUrl || '') + 'auth/login';
					return Promise.reject('not-json');
				}
				return resp.json();
			}).then(data => {
				if (!data) return;
				if (data.success) {
					if (data.is_favorited) {
						if (icon) { icon.className = 'fas fa-heart'; icon.style.color = 'var(--accent-green)'; }
						this.classList.add('favorited');

						// Dispatch event for other listeners to update UI (e.g., Profile favorites list)
						try {
							const ev = new CustomEvent('favorites:added', { detail: { id: itemId } });
							document.dispatchEvent(ev);
						} catch (e) { console.warn('dispatch favorites:added failed', e); }
					} else {
						if (icon) { icon.className = 'far fa-heart'; icon.style.color = ''; }
						this.classList.remove('favorited');

						// Dispatch removed event
						try {
							const ev = new CustomEvent('favorites:removed', { detail: { id: itemId } });
							document.dispatchEvent(ev);
						} catch (e) { console.warn('dispatch favorites:removed failed', e); }
					}
				} else {
					console.warn('[favorites] toggle failed', data);
				}
			}).catch(err => {
				if (err !== 'redirect' && err !== 'not-json') console.error('Favorite toggle error', err);
			}).finally(() => {
				try { this.dataset.processing = '0'; } catch(e){}
			});
		});
	});

	// Helpers: when on profile favorites tab, insert/remove favorite song entries in realtime
	function removeSongFromFavoritesDOM(songId) {
		try {
			const el = document.querySelector('.song-item-profile[data-song-id="' + songId + '"]');
			if (el) el.remove();
		} catch (e) { console.warn('removeSongFromFavoritesDOM error', e); }
	}

	function addSongToFavoritesDOM(song) {
		try {
			if (!song || !song.id) return;
			const container = document.querySelector('#favorites .songs-list');
			if (!container) return;

			// Avoid duplicate
			if (document.querySelector('.song-item-profile[data-song-id="' + song.id + '"]')) return;

			const cover = song.cover_image ? ((window.appBaseUrl || '') + 'assets/images/albums/' + song.cover_image) : ('https://ui-avatars.com/api/?name=' + encodeURIComponent(song.title || '') );
			const albumTitle = song.album_title || song.album || '';
			const artistName = song.artist_name || song.artist || '';

			const div = document.createElement('div');
			div.className = 'song-item-profile';
			div.setAttribute('data-song-id', song.id);
			div.innerHTML = '<img src="'+cover+'" alt="'+(song.title||'')+'" class="song-cover-small">' +
				'<div class="song-details-profile"><h4>'+ (song.title||'Untitled') +'</h4><p>'+ artistName + (albumTitle ? (' • ' + albumTitle) : '') +'</p></div>' +
				'<div class="song-actions">' +
				'<button class="btn-play-small" onclick="playSong('+ song.id +')"><i class="fas fa-play"></i></button>' +
				'<button class="favorite-btn favorited" data-item-id="'+ song.id +'" data-type="song"><i class="fas fa-heart"></i></button>' +
				'</div>';

			// Prepend to container
			container.insertBefore(div, container.firstChild);

			// Re-run binding for newly added elements
			try { initPageBehaviors(); } catch(e){}
		} catch (e) { console.warn('addSongToFavoritesDOM error', e); }
	}

	// After a successful toggle, if we're on the profile favorites tab, keep the UI in sync
	// We'll attach a small listener using event delegation to handle server responses
	document.addEventListener('favorites:added', function(e) {
		const songId = e.detail && e.detail.id;
		if (!songId) return;
		// Fetch song metadata (try uploaded endpoint first, fallback to play endpoint)
		const tryFetch = (url) => fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' } }).then(r => r.ok ? r.json() : Promise.reject(r));
		const base = window.appBaseUrl || '';
		tryFetch(base + 'home/get_uploaded_music/' + songId).then(data => {
			// some endpoints return object, some wrap in {song:...}
			const s = data && data.id ? data : (data && data.song ? data.song : null);
			if (s) addSongToFavoritesDOM(s);
		}).catch(() => {
			tryFetch(base + 'home/play/' + songId).then(data => {
				const s = data && data.id ? data : (data && data.song ? data.song : null);
				if (s) addSongToFavoritesDOM(s);
			}).catch(err => console.warn('Failed to fetch song metadata for favorites insert', err));
		});
	});

	document.addEventListener('favorites:removed', function(e) {
		const songId = e.detail && e.detail.id;
		if (!songId) return;
		removeSongFromFavoritesDOM(songId);
	});

	// Player controls: call global player functions so the audio element is controlled
	const playPauseBtn = document.getElementById('playPauseBtn');
	if (playPauseBtn && !playPauseBtn.dataset.pjaxBound) {
		playPauseBtn.dataset.pjaxBound = '1';
		playPauseBtn.addEventListener('click', function (e) {
			e.preventDefault();
			if (typeof window.togglePlayPause === 'function') {
				try { window.togglePlayPause(); } catch (err) { console.error(err); }
			} else if (typeof togglePlayPause === 'function') {
				try { togglePlayPause(); } catch (err) { console.error(err); }
			}
		});
	}

	const prevBtn = document.getElementById('prevBtn');
	if (prevBtn && !prevBtn.dataset.pjaxBound) {
		prevBtn.dataset.pjaxBound = '1';
		prevBtn.addEventListener('click', function (e) {
			e.preventDefault();
			if (typeof window.previousTrack === 'function') {
				try { window.previousTrack(); } catch (err) { console.error(err); }
			} else if (typeof previousTrack === 'function') {
				try { previousTrack(); } catch (err) { console.error(err); }
			}
		});
	}

	const nextBtn = document.getElementById('nextBtn');
	if (nextBtn && !nextBtn.dataset.pjaxBound) {
		nextBtn.dataset.pjaxBound = '1';
		nextBtn.addEventListener('click', function (e) {
			e.preventDefault();
			if (typeof window.nextTrack === 'function') {
				try { window.nextTrack(); } catch (err) { console.error(err); }
			} else if (typeof nextTrack === 'function') {
				try { nextTrack(); } catch (err) { console.error(err); }
			}
		});
	}

	const shuffleBtn = document.getElementById('shuffleBtn');
	if (shuffleBtn && !shuffleBtn.dataset.pjaxBound) {
		shuffleBtn.dataset.pjaxBound = '1';
		shuffleBtn.addEventListener('click', function (e) {
			e.preventDefault();
			if (typeof window.toggleShuffle === 'function') {
				try { window.toggleShuffle(); } catch (err) { console.error(err); }
			} else if (typeof toggleShuffle === 'function') {
				try { toggleShuffle(); } catch (err) { console.error(err); }
			}
		});
	}

	const repeatBtn = document.getElementById('repeatBtn');
	if (repeatBtn && !repeatBtn.dataset.pjaxBound) {
		repeatBtn.dataset.pjaxBound = '1';
		repeatBtn.addEventListener('click', function (e) {
			e.preventDefault();
			if (typeof window.toggleRepeat === 'function') {
				try { window.toggleRepeat(); } catch (err) { console.error(err); }
			} else if (typeof toggleRepeat === 'function') {
				try { toggleRepeat(); } catch (err) { console.error(err); }
			}
		});
	}

	// Progress bar interaction
	const progressBar = document.querySelector(".progress-bar");
	if (progressBar && !progressBar.dataset.pjaxBound) {
		progressBar.dataset.pjaxBound = '1';
		progressBar.addEventListener("click", function (e) {
			const rect = this.getBoundingClientRect();
			const percent = ((e.clientX - rect.left) / rect.width) * 100;
			const fill = this.querySelector(".progress-fill");
			if (fill) fill.style.width = percent + "%";
		});
	}

	// Volume bar interaction
	const volumeBar = document.querySelector(".volume-bar");
	if (volumeBar && !volumeBar.dataset.pjaxBound) {
		volumeBar.dataset.pjaxBound = '1';
		volumeBar.addEventListener("click", function (e) {
			const rect = this.getBoundingClientRect();
			const percent = ((e.clientX - rect.left) / rect.width) * 100;
			const fill = this.querySelector(".volume-fill");
			if (fill) fill.style.width = percent + "%";
		});
	}

	// Search functionality
	const searchInput = document.querySelector(".search-bar input");
	if (searchInput && !searchInput.dataset.pjaxBound) {
		searchInput.dataset.pjaxBound = '1';
		let searchTimeout;
		searchInput.addEventListener("input", function () {
			clearTimeout(searchTimeout);
			const query = this.value;

			if (query.length > 2) {
				searchTimeout = setTimeout(() => {
					// Perform search
					console.log("Searching for:", query);
					fetch('/home/search_uploaded?q=' + encodeURIComponent(query))
						.then(r => r.json())
						.then(data => {
							// render uploaded music partial into a simple overlay
							const containerId = 'search-uploaded-overlay';
							let container = document.getElementById(containerId);
							if (!container) {
								container = document.createElement('div');
								container.id = containerId;
								container.style.position = 'absolute';
								container.style.maxHeight = '60vh';
								container.style.overflow = 'auto';
								container.style.background = '#111';
								container.style.border = '1px solid #222';
								container.style.padding = '12px';
								container.style.zIndex = 9999;

								// Position the overlay directly below the search input
								try {
									const rect = searchInput.getBoundingClientRect();
									const left = rect.left + window.scrollX;
									const top = rect.bottom + window.scrollY + 6; // small gap
									container.style.left = left + 'px';
									container.style.top = top + 'px';
									container.style.minWidth = Math.max(300, rect.width) + 'px';
								} catch (err) {
									// Fallback to default position
									container.style.right = '20px';
									container.style.top = '60px';
									container.style.width = '360px';
								}

								document.body.appendChild(container);

								// Close overlay when clicking outside or pressing Escape
								const outsideClick = (ev) => {
									if (!container.contains(ev.target) && ev.target !== searchInput) {
										container.remove();
										document.removeEventListener('click', outsideClick);
										document.removeEventListener('keydown', escHandler);
									}
								};
								const escHandler = (ev) => {
									if (ev.key === 'Escape') {
										container.remove();
										document.removeEventListener('click', outsideClick);
										document.removeEventListener('keydown', escHandler);
									}
								};
								// attach listeners
								setTimeout(() => document.addEventListener('click', outsideClick), 0);
								document.addEventListener('keydown', escHandler);
							}
							container.innerHTML = '<h4 style="margin:0 0 8px 0;color:#fff">Uploaded Music</h4>';
							if (!data.uploaded_music || data.uploaded_music.length === 0) {
								container.innerHTML += '<div style="color:#bbb">No results</div>';
								return;
							}
							data.uploaded_music.forEach(m => {
								const item = document.createElement('div');
								item.style.padding = '8px 6px';
								item.style.borderBottom = '1px solid #222';
								item.style.cursor = 'pointer';
								item.innerHTML = '<div style="color:#fff;font-weight:600">' + (m.title || '') + '</div>' +
									'<div style="color:#bbb;font-size:12px">' + (m.artist || '') + ' &middot; ' + (m.album || '') + '</div>';
								item.addEventListener('click', function() {
									if (window.playSong) window.playSong(m);
									container.remove();
								});
								container.appendChild(item);
							});
						}).catch(e => console.error('Search uploaded error', e));
				}, 500);
			}
		});
	}

	// Navigation - visual active class handling
	const navItems = document.querySelectorAll(".nav-item");
	navItems.forEach((item) => {
		if (item.dataset.pjaxBound) return;
		item.dataset.pjaxBound = '1';
		item.addEventListener("click", function (e) {
			// Don't prevent default for actual links
			if (this.getAttribute("href") === "#") {
				e.preventDefault();
			}

			// Remove active class from all items in the same nav
			const parent = this.closest("nav, .library-section, .playlist-section");
			if (parent) {
				parent
					.querySelectorAll(".nav-item")
					.forEach((i) => i.classList.remove("active"));
			}

			// Add active class to clicked item
			this.classList.add("active");
		});
	});

	// Artist cards click
	const artistCards = document.querySelectorAll(".artist-card");
	artistCards.forEach((card) => {
		if (card.dataset.pjaxBound) return;
		card.dataset.pjaxBound = '1';
		card.addEventListener("click", function () {
			const artistName = this.querySelector("h4").textContent;
			console.log("Clicked artist:", artistName);
			// Navigate to artist page
		});
	});

	// Recent item click
	const recentItems = document.querySelectorAll(".recent-item");
	recentItems.forEach((item) => {
		if (item.dataset.pjaxBound) return;
		item.dataset.pjaxBound = '1';
		item.addEventListener("click", function () {
			const songTitle = this.querySelector("h4").textContent;
			console.log("Playing recent song:", songTitle);
			// If element has data-song-id or data-music-id, let delegated handler handle it
			if (this.dataset.songId || this.dataset.musicId) return;
			// Fallback: try to search by title (best-effort)
			fetch((window.appBaseUrl || '') + 'home/search_uploaded?q=' + encodeURIComponent(songTitle))
				.then(r => r.json())
				.then(data => {
					if (data && data.uploaded_music && data.uploaded_music.length) {
						if (window.playSong) window.playSong(data.uploaded_music[0]);
					}
				})
				.catch(e => console.error('Recent item fallback search error', e));
		});
	});

	// Delegated click handler: intercept clicks on elements with data-music-id or data-song-id
	document.addEventListener('click', function (e) {
		const el = e.target.closest('[data-music-id], [data-song-id]');
		if (!el) return;
		// Allow normal links to proceed if user Ctrl+clicks or opens in new tab
		if (e.defaultPrevented) return;
		e.preventDefault();
		const musicId = el.dataset.musicId;
		const songId = el.dataset.songId;
		// Prefer uploaded music endpoint
		if (musicId) {
			const url = (window.appBaseUrl || '') + 'home/get_uploaded_music/' + musicId;
			fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
				.then(res => {
					if (!res.ok) throw res;
					return res.json();
				})
				.then(data => {
					if (window.playSong) window.playSong(data);
				})
				.catch(err => {
					// Fallback to play endpoint (song id)
					console.warn('get_uploaded_music failed, falling back to play:', err);
					if (songId) {
						const fallback = (window.appBaseUrl || '') + 'home/play/' + songId;
						fetch(fallback, { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
							.then(r => r.json())
							.then(d => { if (window.playSong) window.playSong(d); })
							.catch(e => console.error('Fallback play error', e));
					}
				});
			return;
		}
		if (songId) {
			const url = (window.appBaseUrl || '') + 'home/play/' + songId;
			fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
				.then(res => res.json())
				.then(data => { if (window.playSong) window.playSong(data); })
				.catch(err => console.error('play by id failed', err));
		}
	});

	// Build a page-level song list automatically from .song-item onclick JSON
	try {
		if (!window.pageSongList) {
			const items = document.querySelectorAll('.song-item');
			if (items && items.length) {
				const parsed = Array.from(items).map(el => {
					const onclick = el.getAttribute('onclick') || '';
					const start = onclick.indexOf('(');
					const end = onclick.lastIndexOf(')');
					if (start >= 0 && end > start) {
						const jsonText = onclick.slice(start + 1, end);
						try { return JSON.parse(jsonText); } catch (e) { return null; }
					}
					return null;
				}).filter(Boolean);
				if (parsed.length) {
					window.pageSongList = parsed;
					console.debug('[main.js] built pageSongList from DOM, length=', parsed.length);
				}
			}
		}
	} catch (e) { console.warn('Error building pageSongList', e); }
}

// Initial run on full page load
document.addEventListener("DOMContentLoaded", function () { initPageBehaviors(); });
// Also initialize profile tabs if profile page is already loaded
document.addEventListener("DOMContentLoaded", function () { try { initProfileTabs(); } catch(e){} });
// Re-bind behaviours after PJAX navigation (if site emits this event)
window.addEventListener('pjax:loaded', function() {
	try { initPageBehaviors(); } catch (e) { console.warn('initPageBehaviors on pjax:loaded failed', e); }
	try { initProfileTabs(); } catch (e) { /* initProfileTabs may be defined later */ }
});

// Initialize profile tabs (used by profile page). Safe to call multiple times.
function initProfileTabs() {
	try {
		const tabsContainer = document.querySelector('.profile-tabs');
		if (!tabsContainer) return;
		const tabBtns = Array.from(tabsContainer.querySelectorAll('.tab-btn'));
		if (!tabBtns.length) return;

		tabBtns.forEach(btn => {
			if (btn.dataset.bound === '1') return;
			btn.dataset.bound = '1';
			btn.addEventListener('click', function() {
				// Remove active class from all tabs and contents
				tabBtns.forEach(b => b.classList.remove('active'));
				document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
				this.classList.add('active');
				const tabId = this.getAttribute('data-tab');
				const el = document.getElementById(tabId);
				if (el) {
					el.classList.add('active');
					try { el.scrollIntoView({behavior:'smooth'}); } catch(e){}
				}
			});
		});

		// Open from hash if present
		const hash = (window.location.hash || '').replace('#','');
		if (hash) {
			const btn = tabBtns.find(b => b.getAttribute('data-tab') === hash);
			if (btn) btn.click();
		}
	} catch (e) { console.warn('initProfileTabs error', e); }
}

// Force full navigation when sidebar Favorite Songs clicked (avoid PJAX inconsistencies)
document.addEventListener('click', function(e) {
	const el = e.target.closest('#sidebar-favorites-link');
	if (!el) return;
	// Prevent other handlers (PJAX) from intercepting
	e.preventDefault();
	const href = el.getAttribute('href');
	if (href) {
		// Use full navigation to ensure server renders profile page completely
		window.location.href = href;
	}
});
// Genre filter: moved from inline discover view to centralized main.js
function initGenreFilter() {
	try {
		const categoryCards = document.querySelectorAll('.category-card');
		if (!categoryCards || !categoryCards.length) return;

		function el(sel){ return document.querySelector(sel); }
		function els(sel){ return Array.from(document.querySelectorAll(sel)); }

		function renderSongs(songs){
			const grid = el('#genre-songs-grid');
			if (!grid) return;
			grid.innerHTML = '';
			if (!songs || songs.length === 0) {
				grid.innerHTML = '<p>No songs found for this genre.</p>';
				return;
			}
			songs.forEach(function(s){
				const div = document.createElement('div');
				div.className = 'song-card';
				const cover = s.cover_image ? ((window.appBaseUrl || '') + 'assets/images/albums/' + s.cover_image) : ('https://ui-avatars.com/api/?name=' + encodeURIComponent(s.title));
				div.innerHTML = '<div class="song-cover-small"><img src="'+cover+'" alt="'+(s.title||'')+'" onerror="this.src=\'https://ui-avatars.com/api/?name='+encodeURIComponent(s.title)+'\'"></div>'+
								'<div class="song-info"><h4>'+ (s.title||'Untitled') +'</h4><p>'+ (s.artist_name||'Unknown') +'</p></div>'+
								'<div class="song-actions"><button class="btn-play-small" data-music-id="'+(s.id||'')+'">Play</button></div>';
				if (s && s.id) {
					div.setAttribute('data-music-id', s.id);
					div.style.cursor = 'pointer';
				}
				grid.appendChild(div);
			});
		}

		function showSpinner() {
			const grid = el('#genre-songs-grid');
			if (!grid) return;
			grid.innerHTML = '<div class="loading-spinner" style="padding:24px;text-align:center;color:#bbb">Loading…</div>';
		}

		function openGenre(genre, pushState){
			const section = el('#genre-results-section');
			const title = el('#genre-results-title');
			const seeAll = el('#genre-see-all');
			if (!section || !title) return;
			section.style.display = 'block';
			title.textContent = 'Genre: ' + genre;
			if (seeAll) {
				seeAll.style.display = 'inline-block';
				seeAll.setAttribute('href', (window.appBaseUrl || '') + 'discover/genre/' + encodeURIComponent(genre));
			}
			showSpinner();
			fetch((window.appBaseUrl || '') + 'discover/genre/' + encodeURIComponent(genre), { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
				.then(function(res){ if (!res.ok) throw res; return res.json(); })
				.then(function(data){ renderSongs(data.songs || []); if (pushState) { try { history.pushState({ genre: genre, songs: data.songs }, '', (window.appBaseUrl || '') + 'discover/genre/' + encodeURIComponent(genre)); } catch (e) { console.warn('pushState failed', e); } } })
				.catch(function(err){
					console.error('Error fetching genre songs', err);
					const grid = el('#genre-songs-grid'); if (grid) grid.innerHTML = '<div style="padding:16px;color:#f66">Gagal memuat lagu. Silakan coba lagi.</div>';
				});
		}

		categoryCards.forEach(function(card){
			if (card.dataset.genreBound) return;
			card.dataset.genreBound = '1';
			card.addEventListener('click', function(){
				const genre = this.getAttribute('data-genre');
				if (!genre) return;
				openGenre(genre, true);
			});
		});

		// handle popstate to restore genre results
		window.addEventListener('popstate', function(ev){
			if (ev.state && ev.state.genre) {
				const genre = ev.state.genre;
				const songs = ev.state.songs || null;
				const section = document.querySelector('#genre-results-section');
				if (section) section.style.display = 'block';
				const title = document.querySelector('#genre-results-title'); if (title) title.textContent = 'Genre: ' + genre;
				if (songs) renderSongs(songs); else openGenre(genre, false);
			} else {
				const section = document.querySelector('#genre-results-section'); if (section) section.style.display = 'none';
			}
		});

	} catch (e) { console.error('initGenreFilter error', e); }
}

// Init genre filter on load and after PJAX
document.addEventListener('DOMContentLoaded', function(){ initGenreFilter(); });
window.addEventListener('pjax:loaded', function(){ initGenreFilter(); });

// Function to play a song by ID (renamed to avoid conflict with player global)
function playSongById(songId) {
	console.log("playSongById called, ID:", songId);

	// This function no longer overrides the player global `playSong`.
	// Implement AJAX call here if you want to fetch song metadata by ID
	// and then call `window.playSong(songData)` defined in the player.

	/* Example:
	fetch('/musikk/home/play/' + songId, {
		method: 'GET',
		headers: { 'X-Requested-With': 'XMLHttpRequest' }
	})
	.then(res => res.json())
	.then(data => {
		if (window.playSong) window.playSong(data);
	});
	*/
}

// Function to update player
function updatePlayer(songData) {
	// Update now playing info
	const nowPlayingTitle = document.querySelector(".now-playing-info h4");
	const nowPlayingArtist = document.querySelector(".now-playing-info p");
	const nowPlayingCover = document.querySelector(".now-playing-cover img");

	if (nowPlayingTitle) nowPlayingTitle.textContent = songData.title;
	if (nowPlayingArtist) nowPlayingArtist.textContent = songData.artist_name;
	if (nowPlayingCover) nowPlayingCover.src = songData.cover_image;

	// Reset progress
	const progressFill = document.querySelector(".progress-fill");
	if (progressFill) progressFill.style.width = "0%";

	// Start playing animation
	const playBtn = document.querySelector(".control-play i");
	if (playBtn) {
		playBtn.classList.remove("fa-play");
		playBtn.classList.add("fa-pause");
	}
}

// Format number with commas
function formatNumber(num) {
	return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

// Format duration
function formatDuration(seconds) {
	const mins = Math.floor(seconds / 60);
	const secs = seconds % 60;
	return `${mins}:${secs.toString().padStart(2, "0")}`;
}

// Time ago formatter
function timeAgo(date) {
	const seconds = Math.floor((new Date() - new Date(date)) / 1000);

	let interval = seconds / 31536000;
	if (interval > 1) return Math.floor(interval) + " years ago";

	interval = seconds / 2592000;
	if (interval > 1) return Math.floor(interval) + " months ago";

	interval = seconds / 86400;
	if (interval > 1) return Math.floor(interval) + " days ago";

	interval = seconds / 3600;
	if (interval > 1) return Math.floor(interval) + "hr ago";

	interval = seconds / 60;
	if (interval > 1) return Math.floor(interval) + "min ago";

	return "just now";
}

// PJAX-like navigation to keep audio player persistent across pages
(function() {
	// Helper: determine same-origin internal link
	function isInternalLink(a) {
		if (!a || !a.getAttribute) return false;
		const href = a.getAttribute('href');
		if (!href || href.startsWith('#') || href.startsWith('mailto:') || href.startsWith('tel:')) return false;
		// external if has protocol and hostname differs
		try {
			const url = new URL(href, window.location.origin);
			return url.origin === window.location.origin;
		} catch (e) {
			return true; // relative links considered internal
		}
	}

	async function pjaxLoad(url, push = true) {
		try {
			console.debug('[PJAX] loading', url);
			const res = await fetch(url, { headers: { 'X-PJAX': 'true' } });
			if (!res.ok) { window.location.href = url; return; }
			const text = await res.text();
			const parser = new DOMParser();
			const doc = parser.parseFromString(text, 'text/html');
			const newMain = doc.querySelector('main.main-content');
			const currentMain = document.querySelector('main.main-content');
			if (newMain && currentMain) {
				// Replace content
				currentMain.innerHTML = newMain.innerHTML;

				// Execute any inline scripts from newMain so functions are available
				const scripts = newMain.querySelectorAll('script');
				scripts.forEach(s => {
					try {
						const sc = document.createElement('script');
						if (s.src) {
							sc.src = s.src;
							sc.async = false;
							document.head.appendChild(sc);
						} else {
							sc.text = s.textContent || s.innerText || '';
							document.body.appendChild(sc);
							// remove immediately to avoid duplication
							document.body.removeChild(sc);
						}
					} catch (e) { console.warn('Error executing PJAX script', e); }
				});

				// Update title
				const newTitle = doc.querySelector('title');
				if (newTitle) document.title = newTitle.textContent;
				// Update URL
				if (push) history.pushState({ pjax: true }, '', url);
				// Notify listeners to rebind behaviors
				window.dispatchEvent(new Event('pjax:loaded'));
				// Scroll to top of main
				window.scrollTo({ top: 0 });
				console.debug('[PJAX] loaded', url);
			} else {
				// Can't find container: full redirect
				window.location.href = url;
			}
		} catch (err) {
			console.error('PJAX load failed, falling back to full load', err);
			window.location.href = url;
		}
	}

	// Intercept clicks on links
	document.addEventListener('click', function(e) {
		const a = e.target.closest('a');
		if (!a) return;
		if (!isInternalLink(a)) return;
		// Skip links that have data-no-pjax or target
		if (a.hasAttribute('data-no-pjax') || a.target === '_blank') return;
		// Skip logout and forms/actions
		const href = a.getAttribute('href');
		if (!href || href === '#' || href.startsWith('javascript:')) return;

		// Prevent default and load via PJAX
		e.preventDefault();
		pjaxLoad(href, true);
	});

	// Fallback delegated handler for Play/Pause button in case direct bindings fail
	document.addEventListener('click', function(e) {
		const btn = e.target.closest('#playPauseBtn');
		if (!btn) return;
		console.debug('[PJAX-Fallback] playPause button clicked');
		e.preventDefault();
		if (typeof window.togglePlayPause === 'function') {
			try { window.togglePlayPause(); } catch (err) { console.error(err); }
		} else if (typeof togglePlayPause === 'function') {
			try { togglePlayPause(); } catch (err) { console.error(err); }
		} else {
			console.warn('togglePlayPause not available');
		}
	});

	// Handle browser back/forward
	window.addEventListener('popstate', function(e) {
		const url = location.href;
		pjaxLoad(url, false);
	});

	// Optional: allow manual rebind after PJAX
	window.addEventListener('pjax:loaded', function() {
		// Re-run some lightweight init tasks: rebind dynamic elements
		// For safety, call functions if defined
		if (typeof window.onPjaxLoaded === 'function') {
			try { window.onPjaxLoaded(); } catch (e) { console.error(e); }
		}
	});
})();

// Expose a simple hook that other scripts can implement to rebind behaviors after PJAX
window.onPjaxLoaded = function() {
	// Re-run any initialization that needs to bind to new DOM nodes
	// Example: re-attach play button handlers or other UI bits
	try {
		// Re-run search input binding if present
		const evt = new Event('DOMContentLoaded');
		document.dispatchEvent(evt);
	} catch (e) {
		console.error('onPjaxLoaded error', e);
	}
};
