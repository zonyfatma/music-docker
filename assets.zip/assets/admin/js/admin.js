/**
 * ADMIN DASHBOARD JAVASCRIPT
 * Handles all interactive features for the admin dashboard
 */

$(document).ready(function () {
	// ==================================
	// SEARCH FUNCTIONALITY
	// ==================================

	let searchTimeout;
	const searchInput = $("#admin-search-input");
	const searchForm = $("#admin-search-form");

	searchInput.on("keyup", function () {
		clearTimeout(searchTimeout);
		const query = $(this).val();

		if (query.length >= 3) {
			searchTimeout = setTimeout(function () {
				performSearch(query);
			}, 500);
		} else {
			hideSearchResults();
		}
	});

	searchForm.on("submit", function (e) {
		e.preventDefault();
		const query = searchInput.val();
		if (query.length >= 3) {
			performSearch(query);
		}
	});

	function performSearch(query) {
		$.ajax({
			url: baseUrl + "admin/ajax_search",
			method: "GET",
			data: { q: query, type: "all" },
			dataType: "json",
			success: function (response) {
				displaySearchResults(response);
			},
			error: function () {
				console.error("Search failed");
			},
		});
	}

	function displaySearchResults(results) {
		let html = '<div id="search-results">';

		// Users
		if (results.users && results.users.length > 0) {
			html +=
				'<div class="p-2 bg-light"><strong class="result-type text-primary">Pengguna</strong></div>';
			results.users.forEach(function (user) {
				html +=
					'<div class="result-item" onclick="window.location=\'' +
					baseUrl +
					"admin/user_detail/" +
					user.user_id +
					"'\">";
				html +=
					'<i class="fas fa-user me-2"></i>' +
					user.username +
					' <small class="text-muted">(' +
					user.email +
					")</small>";
				html += "</div>";
			});
		}

		// Music
		if (results.music && results.music.length > 0) {
			html +=
				'<div class="p-2 bg-light"><strong class="result-type text-success">Musik</strong></div>';
			results.music.forEach(function (music) {
				html +=
					'<div class="result-item" onclick="window.location=\'' +
					baseUrl +
					"admin/music_detail/" +
					music.music_id +
					"'\">";
				html +=
					'<i class="fas fa-music me-2"></i>' +
					music.title +
					' <small class="text-muted">- ' +
					music.artist +
					"</small>";
				html += "</div>";
			});
		}

		// Podcasts
		if (results.podcasts && results.podcasts.length > 0) {
			html +=
				'<div class="p-2 bg-light"><strong class="result-type text-info">Podcast</strong></div>';
			results.podcasts.forEach(function (podcast) {
				html +=
					'<div class="result-item" onclick="window.location=\'' +
					baseUrl +
					"admin/podcast_detail/" +
					podcast.podcast_id +
					"'\">";
				html +=
					'<i class="fas fa-podcast me-2"></i>' +
					podcast.title +
					' <small class="text-muted">- ' +
					podcast.host +
					"</small>";
				html += "</div>";
			});
		}

		if (
			!results.users ||
			(results.users.length === 0 && !results.music) ||
			(results.music.length === 0 && !results.podcasts) ||
			results.podcasts.length === 0
		) {
			html +=
				'<div class="p-3 text-center text-muted">Tidak ada hasil ditemukan</div>';
		}

		html += "</div>";

		// Remove existing results
		$("#search-results").remove();

		// Add new results
		searchForm.append(html);
	}

	function hideSearchResults() {
		$("#search-results").remove();
	}

	// Click outside to close search results
	$(document).on("click", function (e) {
		if (!$(e.target).closest("#admin-search-form").length) {
			hideSearchResults();
		}
	});

	// ==================================
	// AUTO-HIDE ALERTS
	// ==================================

	setTimeout(function () {
		$(".alert").fadeOut("slow", function () {
			$(this).remove();
		});
	}, 5000);

	// ==================================
	// CONFIRM DELETE ACTIONS
	// ==================================

	$("[data-confirm]").on("click", function (e) {
		const message = $(this).data("confirm");
		if (!confirm(message)) {
			e.preventDefault();
			return false;
		}
	});

	// ==================================
	// MOBILE SIDEBAR TOGGLE
	// ==================================

	$("#sidebar-toggle").on("click", function () {
		$("#sidebar").toggleClass("show");
	});

	// ==================================
	// NOTIFICATION MARK AS READ
	// ==================================

	$(".notification-item").on("click", function () {
		const notifId = $(this).data("id");
		if (notifId) {
			markNotificationRead(notifId);
		}
	});

	function markNotificationRead(notifId) {
		$.ajax({
			url: baseUrl + "admin/notification_read/" + notifId,
			method: "POST",
			success: function () {
				// Update notification count
				updateNotificationCount();
			},
		});
	}

	function updateNotificationCount() {
		$.ajax({
			url: baseUrl + "admin/ajax_get_stats",
			method: "GET",
			dataType: "json",
			success: function (stats) {
				const count = stats.unread_notifications;
				if (count > 0) {
					$(".notification-badge").text(count).show();
				} else {
					$(".notification-badge").hide();
				}
			},
		});
	}

	// ==================================
	// DATA TABLE ENHANCEMENTS
	// ==================================

	// Add striped effect on hover
	$(".table-hover tbody tr").hover(
		function () {
			$(this).addClass("table-active");
		},
		function () {
			$(this).removeClass("table-active");
		}
	);

	// ==================================
	// TOOLTIPS
	// ==================================

	// Initialize Bootstrap tooltips
	const tooltipTriggerList = [].slice.call(
		document.querySelectorAll('[data-bs-toggle="tooltip"]')
	);
	tooltipTriggerList.map(function (tooltipTriggerEl) {
		return new bootstrap.Tooltip(tooltipTriggerEl);
	});

	// ==================================
	// EXPORT FUNCTIONS
	// ==================================

	$(".export-btn").on("click", function () {
		const type = $(this).data("type");
		const format = $(this).data("format");

		const dateFrom = $("#date_from").val();
		const dateTo = $("#date_to").val();

		let url =
			baseUrl + "admin/export_report?type=" + type + "&format=" + format;

		if (dateFrom) url += "&date_from=" + dateFrom;
		if (dateTo) url += "&date_to=" + dateTo;

		window.location.href = url;
	});

	// ==================================
	// LIVE STATS UPDATE
	// ==================================

	// Update dashboard stats every 60 seconds
	if ($("#usageTrendChart").length > 0) {
		setInterval(function () {
			updateDashboardStats();
		}, 60000);
	}

	function updateDashboardStats() {
		$.ajax({
			url: baseUrl + "admin/ajax_get_stats",
			method: "GET",
			dataType: "json",
			success: function (stats) {
				// Update stat numbers with animation
				animateValue(
					"total-users",
					parseInt($("#total-users").text().replace(/,/g, "")),
					stats.total_users,
					1000
				);
				animateValue(
					"total-content",
					parseInt($("#total-content").text().replace(/,/g, "")),
					stats.total_music + stats.total_podcasts,
					1000
				);
				animateValue(
					"plays-today",
					parseInt($("#plays-today").text().replace(/,/g, "")),
					stats.plays_today,
					1000
				);
				animateValue(
					"pending-content",
					parseInt($("#pending-content").text().replace(/,/g, "")),
					stats.pending_content,
					1000
				);
			},
		});
	}

	function animateValue(id, start, end, duration) {
		const elem = document.getElementById(id);
		if (!elem) return;

		const range = end - start;
		let current = start;
		const increment = end > start ? 1 : -1;
		const stepTime = Math.abs(Math.floor(duration / range));

		const timer = setInterval(function () {
			current += increment;
			elem.textContent = current.toLocaleString();
			if (current == end) {
				clearInterval(timer);
			}
		}, stepTime);
	}

	// ==================================
	// FORM VALIDATION
	// ==================================

	$("form").on("submit", function () {
		const submitBtn = $(this).find('button[type="submit"]');
		submitBtn.prop("disabled", true);
		submitBtn.html(
			'<span class="spinner-border spinner-border-sm me-2"></span>Memproses...'
		);
	});
});

// ==================================
// GLOBAL HELPER FUNCTIONS
// ==================================

// Get base URL
const baseUrl = window.location.origin + "/musikk/";

// Format number with thousands separator
function formatNumber(num) {
	return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

// Format date
function formatDate(dateString) {
	const date = new Date(dateString);
	const options = { year: "numeric", month: "short", day: "numeric" };
	return date.toLocaleDateString("id-ID", options);
}

// Show loading overlay
function showLoading() {
	$("body").append(
		'<div id="loading-overlay" style="position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.5);z-index:9999;display:flex;align-items:center;justify-content:center;"><div class="spinner-border text-light" style="width:3rem;height:3rem;"></div></div>'
	);
}

// Hide loading overlay
function hideLoading() {
	$("#loading-overlay").remove();
}

// Show toast notification
function showToast(message, type = "success") {
	const toastClass = type === "success" ? "bg-success" : "bg-danger";
	const toast = `
        <div class="position-fixed bottom-0 end-0 p-3" style="z-index: 11">
            <div class="toast ${toastClass} text-white" role="alert">
                <div class="toast-header">
                    <strong class="me-auto">Notifikasi</strong>
                    <button type="button" class="btn-close" data-bs-dismiss="toast"></button>
                </div>
                <div class="toast-body">
                    ${message}
                </div>
            </div>
        </div>
    `;

	$("body").append(toast);
	const toastElement = new bootstrap.Toast($(".toast").last());
	toastElement.show();

	setTimeout(function () {
		$(".toast").last().remove();
	}, 5000);
}
