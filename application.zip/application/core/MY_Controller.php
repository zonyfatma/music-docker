<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MY_Controller extends CI_Controller {
    
    /**
     * @var CI_DB_query_builder
     */
    public $db;

    /**
     * @var CI_Router
     */
    protected $router;

    /**
     * @var CI_Session
     */
    public $session;

    /**
     * @var CI_Output
     */
    public $output;

    /**
     * @var array
     */
    protected $app_settings;

    /**
     * @var Admin_model
     */
    public $Admin_model;

    public function __construct() {
        parent::__construct();

        // Load necessary libraries and helpers
        $this->load->database();
        $this->load->library('session');
        // The router is automatically available as $this->router
        
        // Load application settings
        $this->load->model('Admin_model');
        $this->app_settings = $this->Admin_model->get_app_settings();
        
        // Check maintenance mode on every request
        $this->check_maintenance_mode();
    }
    
    /**
     * Check if maintenance mode is enabled
     * Block non-admin users when maintenance mode is active
     */
    protected function check_maintenance_mode() {
        // Get maintenance mode setting
        $query = $this->db->get_where('system_settings', array('setting_key' => 'maintenance_mode'));
        $maintenance_setting = $query->row_array();
        
        // Check if maintenance mode is enabled
        if ($maintenance_setting && $maintenance_setting['setting_value'] == 'enabled') {
            // Giyaaet current controller
            $current_controller = $this->router->fetch_class();
            
            // Allow access to auth controller for login
            if (strtolower($current_controller) == 'auth') {
                return;
            }
            
            // Check if user is logged in
            $user_id = $this->session->userdata('user_id');
            $user_role = $this->session->userdata('role_id');
            
            // Allow admin access (role_id = 1)
            if ($user_id && $user_role == 1) {
                return;
            }
            
            // Block non-admin users - show maintenance page
            header("HTTP/1.1 503 Service Temporarily Unavailable");
            header("Status: 503 Service Temporarily Unavailable");
            header("Retry-After: 3600");
            
            include(APPPATH . 'views/maintenance.php');
            exit;
        }
    }
}
