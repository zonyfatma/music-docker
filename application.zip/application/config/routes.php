<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/userguide3/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'home';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

// Test page
$route['test'] = 'test/index';
$route['test/info'] = 'test/info';

// Artist and Music routes
$route['artist/(:num)'] = 'home/artist/$1';
$route['play/(:num)'] = 'home/play/$1';
$route['search'] = 'home/search';

// Discover routes
$route['discover'] = 'discover/index';
$route['discover/category/(:any)'] = 'discover/category/$1';

// Radio routes
$route['radio'] = 'radio/index';
$route['radio/station/(:num)'] = 'radio/station/$1';

// Albums routes
$route['albums'] = 'albums/index';
$route['albums/view/(:num)'] = 'albums/view/$1';

// Podcast routes
$route['podcast'] = 'podcast/index';
$route['podcast/show/(:num)'] = 'podcast/show/$1';

// Authentication routes
$route['auth/login'] = 'auth/login';
$route['auth/register'] = 'auth/register';
$route['auth/logout'] = 'auth/logout';
$route['auth/google'] = 'auth/google';
$route['auth/check_login'] = 'auth/check_login';

// Profile routes
$route['profile'] = 'profile/index';
$route['profile/edit'] = 'profile/edit';
$route['profile/playlist/(:num)'] = 'profile/playlist/$1';
$route['profile/create_playlist'] = 'profile/create_playlist';
$route['profile/update_playlist'] = 'profile/update_playlist';
$route['profile/delete_playlist'] = 'profile/delete_playlist';
$route['profile/add_to_playlist'] = 'profile/add_to_playlist';
$route['profile/remove_from_playlist'] = 'profile/remove_from_playlist';
$route['profile/toggle_favorite'] = 'profile/toggle_favorite';
$route['profile/track_play'] = 'profile/track_play';

// Admin routes
$route['admin'] = 'admin/index';
$route['admin/dashboard'] = 'admin/dashboard';
$route['admin/users'] = 'admin/users';
$route['admin/user_detail/(:num)'] = 'admin/user_detail/$1';
$route['admin/user_update/(:num)'] = 'admin/user_update/$1';
$route['admin/user_delete/(:num)'] = 'admin/user_delete/$1';
$route['admin/user_block/(:num)'] = 'admin/user_block/$1';
$route['admin/user_unblock/(:num)'] = 'admin/user_unblock/$1';
$route['admin/music'] = 'admin/music';
$route['admin/music_detail/(:num)'] = 'admin/music_detail/$1';
$route['admin/music_update/(:num)'] = 'admin/music_update/$1';
$route['admin/music_delete/(:num)'] = 'admin/music_delete/$1';
$route['admin/music_approve/(:num)'] = 'admin/music_approve/$1';
$route['admin/music_reject/(:num)'] = 'admin/music_reject/$1';
$route['admin/podcasts'] = 'admin/podcasts';
$route['admin/podcast_detail/(:num)'] = 'admin/podcast_detail/$1';
$route['admin/podcast_update/(:num)'] = 'admin/podcast_update/$1';
$route['admin/podcast_delete/(:num)'] = 'admin/podcast_delete/$1';
$route['admin/playlists'] = 'admin/playlists';
$route['admin/playlist_delete/(:num)'] = 'admin/playlist_delete/$1';
$route['admin/activity_logs'] = 'admin/activity_logs';
$route['admin/notifications'] = 'admin/notifications';
$route['admin/mark_notification_read/(:num)'] = 'admin/mark_notification_read/$1';
$route['admin/mark_all_read'] = 'admin/mark_all_read';
$route['admin/reports'] = 'admin/reports';
$route['admin/settings'] = 'admin/settings';
$route['admin/settings_update'] = 'admin/settings_update';
$route['admin/(:any)'] = 'admin/$1';
