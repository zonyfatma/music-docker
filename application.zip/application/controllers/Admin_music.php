<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_music extends MY_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Admin_model');
        $this->load->library('upload');
        
        // Check if user is admin
        if (!$this->session->userdata('user_id') || $this->session->userdata('role_id') != 1) {
            redirect('auth/login');
        }
    }

    public function index() {
        $data['title'] = 'Upload Musik';
        $data['music_list'] = $this->Admin_model->get_all_music();
        
        $this->load->view('admin/header', $data);
        $this->load->view('admin/sidebar');
        $this->load->view('admin/upload_music', $data);
        $this->load->view('admin/footer');
    }

    public function upload() {
        $data['title'] = 'Upload Musik';
        
        $this->load->view('admin/header', $data);
        $this->load->view('admin/sidebar');
        $this->load->view('admin/upload_music', $data);
        $this->load->view('admin/footer');
    }

    public function do_upload() {
        // Configure upload for cover image
        $cover_config['upload_path'] = './assets/images/albums/';
        $cover_config['allowed_types'] = 'gif|jpg|jpeg|png|webp';
        $cover_config['max_size'] = 5120; // 5MB
        $cover_config['encrypt_name'] = TRUE;

        $this->upload->initialize($cover_config);
        
        $cover_image = '';
        if (!empty($_FILES['cover_image']['name'])) {
            if ($this->upload->do_upload('cover_image')) {
                $cover_data = $this->upload->data();
                $cover_image = $cover_data['file_name'];
            } else {
                $this->session->set_flashdata('error', $this->upload->display_errors());
                redirect('admin_music/upload');
                return;
            }
        }

        // Configure upload for audio file
        $audio_config['upload_path'] = './uploads/audio/';
        $audio_config['allowed_types'] = 'mp3|wav|ogg|m4a';
        $audio_config['max_size'] = 51200; // 50MB
        $audio_config['encrypt_name'] = TRUE;

        $this->upload->initialize($audio_config);
        
        $audio_file = '';
        $audio_url = $this->input->post('audio_url'); // URL eksternal
        
        if (!empty($_FILES['audio_file']['name'])) {
            // Upload from file
            // --- Debug logging: record $_FILES and mime detection ---
            try {
                $debug = array();
                $debug['time'] = date('Y-m-d H:i:s');
                if (isset($_FILES['audio_file'])) {
                    $debug['file_name'] = $_FILES['audio_file']['name'];
                    $debug['file_type_reported'] = $_FILES['audio_file']['type'];
                    $debug['tmp_name'] = $_FILES['audio_file']['tmp_name'];
                    $debug['size'] = $_FILES['audio_file']['size'];
                    if (is_uploaded_file($_FILES['audio_file']['tmp_name'])) {
                        if (function_exists('finfo_open')) {
                            $finfo = finfo_open(FILEINFO_MIME_TYPE);
                            $detected = finfo_file($finfo, $_FILES['audio_file']['tmp_name']);
                            finfo_close($finfo);
                            $debug['finfo_mime'] = $detected;
                        } else {
                            $debug['finfo_mime'] = 'finfo_not_available';
                        }
                    } else {
                        $debug['finfo_mime'] = 'tmp_not_uploaded_or_missing';
                    }
                } else {
                    $debug['file'] = 'audio_file not present in $_FILES';
                }
                $log_line = "[UPLOAD_DEBUG] " . json_encode($debug) . PHP_EOL;
                @file_put_contents(APPPATH . 'logs/upload_debug.log', $log_line, FILE_APPEND);
                if (function_exists('log_message')) {
                    log_message('error', $log_line);
                }
            } catch (Exception $e) {
                // ignore logging errors
            }

            if ($this->upload->do_upload('audio_file')) {
                $audio_data = $this->upload->data();
                $audio_file = 'uploads/audio/' . $audio_data['file_name'];
            } else {
                // Delete uploaded cover if audio upload fails
                if ($cover_image && file_exists('./assets/images/albums/' . $cover_image)) {
                    unlink('./assets/images/albums/' . $cover_image);
                }
                // Log upload error details
                try {
                    $error_debug = array(
                        'time' => date('Y-m-d H:i:s'),
                        'upload_errors' => strip_tags($this->upload->display_errors('', '')),
                    );
                    $err_line = "[UPLOAD_ERROR] " . json_encode($error_debug) . PHP_EOL;
                    @file_put_contents(APPPATH . 'logs/upload_debug.log', $err_line, FILE_APPEND);
                    if (function_exists('log_message')) {
                        log_message('error', $err_line);
                    }
                } catch (Exception $e) {
                    // ignore
                }
                $this->session->set_flashdata('error', $this->upload->display_errors());
                redirect('admin_music/upload');
                return;
            }
        } elseif (!empty($audio_url)) {
            // Use external URL
            $audio_file = $audio_url;
        } else {
            // Use demo/sample audio
            $audio_file = 'assets/audio/demo.mp3';
        }

        // Get audio duration (if local file)
        $duration = 0;
        if (!filter_var($audio_file, FILTER_VALIDATE_URL) && file_exists('./' . $audio_file)) {
            $duration = $this->get_audio_duration('./' . $audio_file);
        }

        // Insert to database
        $music_data = array(
            'title' => $this->input->post('title'),
            'artist' => $this->input->post('artist'),
            'album' => $this->input->post('album'),
            'genre' => $this->input->post('genre'),
            'duration' => $duration,
            'file_path' => $audio_file,
            'cover_image' => $cover_image,
            'upload_by' => $this->session->userdata('user_id'),
            'status' => 'approved'
        );

        $result = $this->Admin_model->insert_music($music_data);

        if ($result) {
            $this->session->set_flashdata('success', 'Music uploaded successfully!');
        } else {
            $this->session->set_flashdata('error', 'Failed to upload music.');
        }

        redirect('admin_music');
    }

    public function edit($music_id) {
        $data['music'] = $this->Admin_model->get_music_by_id($music_id);
        if (!$data['music']) {
            show_404();
        }
        $this->load->view('admin/edit_music', $data);
    }

    public function update($music_id) {
        $music = $this->Admin_model->get_music_by_id($music_id);
        if (!$music) {
            show_404();
        }

        $cover_image = $music->cover_image;
        $audio_file = $music->file_path;

        // Update cover image if new file uploaded
        if (!empty($_FILES['cover_image']['name'])) {
            $cover_config['upload_path'] = './assets/images/albums/';
            $cover_config['allowed_types'] = 'gif|jpg|jpeg|png|webp';
            $cover_config['max_size'] = 5120;
            $cover_config['encrypt_name'] = TRUE;

            $this->upload->initialize($cover_config);
            
            if ($this->upload->do_upload('cover_image')) {
                // Delete old cover
                if ($cover_image && file_exists('./assets/images/albums/' . $cover_image)) {
                    unlink('./assets/images/albums/' . $cover_image);
                }
                $cover_data = $this->upload->data();
                $cover_image = $cover_data['file_name'];
            }
        }

        // Update audio file if new file uploaded
        if (!empty($_FILES['audio_file']['name'])) {
            $audio_config['upload_path'] = './uploads/audio/';
            $audio_config['allowed_types'] = 'mp3|wav|ogg|m4a';
            $audio_config['max_size'] = 51200;
            $audio_config['encrypt_name'] = TRUE;

            $this->upload->initialize($audio_config);

            // --- Debug logging for update upload ---
            try {
                $debug = array('time' => date('Y-m-d H:i:s'));
                if (isset($_FILES['audio_file'])) {
                    $debug['file_name'] = $_FILES['audio_file']['name'];
                    $debug['file_type_reported'] = $_FILES['audio_file']['type'];
                    $debug['tmp_name'] = $_FILES['audio_file']['tmp_name'];
                    $debug['size'] = $_FILES['audio_file']['size'];
                    if (is_uploaded_file($_FILES['audio_file']['tmp_name']) && function_exists('finfo_open')) {
                        $finfo = finfo_open(FILEINFO_MIME_TYPE);
                        $debug['finfo_mime'] = finfo_file($finfo, $_FILES['audio_file']['tmp_name']);
                        finfo_close($finfo);
                    }
                }
                @file_put_contents(APPPATH . 'logs/upload_debug.log', "[UPDATE_UPLOAD_DEBUG] " . json_encode($debug) . PHP_EOL, FILE_APPEND);
                if (function_exists('log_message')) { log_message('error', "[UPDATE_UPLOAD_DEBUG] " . json_encode($debug)); }
            } catch (Exception $e) {}

            if ($this->upload->do_upload('audio_file')) {
                // Delete old audio
                if ($audio_file && file_exists('./' . $audio_file) && !filter_var($audio_file, FILTER_VALIDATE_URL)) {
                    unlink('./' . $audio_file);
                }
                $audio_data = $this->upload->data();
                $audio_file = 'uploads/audio/' . $audio_data['file_name'];
            } else {
                // Log update upload errors
                try {
                    $error_debug = array(
                        'time' => date('Y-m-d H:i:s'),
                        'upload_errors' => strip_tags($this->upload->display_errors('', '')),
                    );
                    @file_put_contents(APPPATH . 'logs/upload_debug.log', "[UPDATE_UPLOAD_ERROR] " . json_encode($error_debug) . PHP_EOL, FILE_APPEND);
                    if (function_exists('log_message')) { log_message('error', "[UPDATE_UPLOAD_ERROR] " . json_encode($error_debug)); }
                } catch (Exception $e) {}
            }
        } elseif (!empty($this->input->post('audio_url'))) {
            $audio_file = $this->input->post('audio_url');
        }

        // Get duration if audio file changed
        $duration = $music->duration;
        if ($audio_file != $music->file_path) {
            if (!filter_var($audio_file, FILTER_VALIDATE_URL) && file_exists('./' . $audio_file)) {
                $duration = $this->get_audio_duration('./' . $audio_file);
            }
        }

        $music_data = array(
            'title' => $this->input->post('title'),
            'artist' => $this->input->post('artist'),
            'album' => $this->input->post('album'),
            'genre' => $this->input->post('genre'),
            'duration' => $duration,
            'file_path' => $audio_file,
            'cover_image' => $cover_image
        );

        $result = $this->Admin_model->update_music($music_id, $music_data);

        if ($result) {
            $this->session->set_flashdata('success', 'Music updated successfully!');
        } else {
            $this->session->set_flashdata('error', 'Failed to update music.');
        }

        redirect('admin_music');
    }

    public function delete($music_id) {
        $music = $this->Admin_model->get_music_by_id($music_id);
        if (!$music) {
            show_404();
        }

        // Delete files
        if ($music->cover_image && file_exists('./assets/images/albums/' . $music->cover_image)) {
            unlink('./assets/images/albums/' . $music->cover_image);
        }
        if ($music->file_path && file_exists('./' . $music->file_path) && !filter_var($music->file_path, FILTER_VALIDATE_URL)) {
            unlink('./' . $music->file_path);
        }

        $result = $this->Admin_model->delete_music($music_id);

        if ($result) {
            $this->session->set_flashdata('success', 'Music deleted successfully!');
        } else {
            $this->session->set_flashdata('error', 'Failed to delete music.');
        }

        redirect('admin_music');
    }

    // Helper function to get audio duration
    private function get_audio_duration($file) {
        if (!file_exists($file)) {
            return 0;
        }

        // Using getID3 library if available, otherwise return 0
        // You can install getID3 library for more accurate duration
        // For now, return default duration
        return 180; // 3 minutes default
    }
}
