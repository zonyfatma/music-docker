<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profile extends MY_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('User_model');
        $this->load->model('Playlist_model');
        $this->load->model('Music_model'); // Load Music_model to fix the error
        $this->load->library('session');
        $this->load->helper('url');
        
        // Check if user is logged in
        if (!$this->session->userdata('user_id')) {
            redirect(base_url('auth/login'));
        }
    }

    /**
     * User profile page
     */
    public function index() {
        $user_id = $this->session->userdata('user_id');
        
        $data['user'] = $this->User_model->get_user_by_id($user_id);
        $data['playlists'] = $this->Playlist_model->get_user_playlists($user_id);
        $data['favorite_songs'] = $this->Playlist_model->get_favorite_songs($user_id);
        $data['favorite_albums'] = $this->Playlist_model->get_favorite_albums($user_id);
        $data['play_history'] = $this->Playlist_model->get_play_history($user_id, 20);
        $data['recently_played'] = $this->Playlist_model->get_recently_played($user_id, 10);
        $data['most_played'] = $this->Playlist_model->get_most_played($user_id, 10);
        
        $this->load->view('profile/index', $data);
    }

    /**
     * Edit profile
     */
    public function edit() {
        $user_id = $this->session->userdata('user_id');
        
        if ($this->input->method() === 'post') {
            $update_data = array(
                'full_name' => $this->input->post('full_name'),
                'username' => $this->input->post('username')
            );
            
            if ($this->User_model->update_profile($user_id, $update_data)) {
                // Update session
                $this->session->set_userdata('full_name', $update_data['full_name']);
                $this->session->set_userdata('username', $update_data['username']);
                
                $this->session->set_flashdata('success', 'Profile updated successfully!');
            } else {
                $this->session->set_flashdata('error', 'Failed to update profile');
            }
            
            redirect(base_url('profile'));
        }
        
        $data['user'] = $this->User_model->get_user_by_id($user_id);
        $this->load->view('profile/edit', $data);
    }

    /**
     * View playlist
     */
    public function playlist($playlist_id) {
        $user_id = $this->session->userdata('user_id');
        
        $data['playlist'] = $this->Playlist_model->get_playlist($playlist_id);
        
        if (!$data['playlist']) {
            show_404();
        }
        
        // Check if user owns playlist or if it's public
        if ($data['playlist']->user_id != $user_id && !$data['playlist']->is_public) {
            show_error('You do not have permission to view this playlist', 403);
        }
        
        $data['songs'] = $this->Playlist_model->get_playlist_songs($playlist_id);
        $data['is_owner'] = ($data['playlist']->user_id == $user_id);
        
        $this->load->view('profile/playlist', $data);
    }

    /**
     * Create playlist (AJAX)
     */
    public function create_playlist() {
        header('Content-Type: application/json');
        
        $user_id = $this->session->userdata('user_id');
        
        $playlist_data = array(
            'name' => $this->input->post('name'),
            'description' => $this->input->post('description'),
            'is_public' => $this->input->post('is_public') ?? 1
        );
        
        $playlist_id = $this->Playlist_model->create_playlist($user_id, $playlist_data);
        
        if ($playlist_id) {
            echo json_encode(array(
                'success' => true,
                'playlist_id' => $playlist_id,
                'message' => 'Playlist created successfully!'
            ));
        } else {
            echo json_encode(array(
                'success' => false,
                'message' => 'Failed to create playlist'
            ));
        }
    }

    /**
     * Update playlist (AJAX)
     */
    public function update_playlist() {
        header('Content-Type: application/json');
        
        $user_id = $this->session->userdata('user_id');
        $playlist_id = $this->input->post('playlist_id');
        
        // Check ownership
        if (!$this->Playlist_model->is_playlist_owner($playlist_id, $user_id)) {
            echo json_encode(array('success' => false, 'message' => 'Unauthorized'));
            return;
        }
        
        $update_data = array(
            'name' => $this->input->post('name'),
            'description' => $this->input->post('description'),
            'is_public' => $this->input->post('is_public')
        );
        
        if ($this->Playlist_model->update_playlist($playlist_id, $update_data)) {
            echo json_encode(array('success' => true, 'message' => 'Playlist updated!'));
        } else {
            echo json_encode(array('success' => false, 'message' => 'Update failed'));
        }
    }

    /**
     * Delete playlist (AJAX)
     */
    public function delete_playlist() {
        header('Content-Type: application/json');
        
        $user_id = $this->session->userdata('user_id');
        $playlist_id = $this->input->post('playlist_id');
        
        // Check ownership
        if (!$this->Playlist_model->is_playlist_owner($playlist_id, $user_id)) {
            echo json_encode(array('success' => false, 'message' => 'Unauthorized'));
            return;
        }
        
        if ($this->Playlist_model->delete_playlist($playlist_id)) {
            echo json_encode(array('success' => true, 'message' => 'Playlist deleted!'));
        } else {
            echo json_encode(array('success' => false, 'message' => 'Delete failed'));
        }
    }

    /**
     * Add song to playlist (AJAX)
     */
    public function add_to_playlist() {
        header('Content-Type: application/json');
        
        $user_id = $this->session->userdata('user_id');
        $playlist_id = $this->input->post('playlist_id');
        $song_id = $this->input->post('song_id');
        
        // Check ownership
        if (!$this->Playlist_model->is_playlist_owner($playlist_id, $user_id)) {
            echo json_encode(array('success' => false, 'message' => 'Unauthorized'));
            return;
        }
        
        if ($this->Playlist_model->add_song_to_playlist($playlist_id, $song_id)) {
            echo json_encode(array('success' => true, 'message' => 'Song added to playlist!'));
        } else {
            echo json_encode(array('success' => false, 'message' => 'Song already in playlist'));
        }
    }

    /**
     * Remove song from playlist (AJAX)
     */
    public function remove_from_playlist() {
        header('Content-Type: application/json');
        
        $user_id = $this->session->userdata('user_id');
        $playlist_id = $this->input->post('playlist_id');
        $song_id = $this->input->post('song_id');
        
        // Check ownership
        if (!$this->Playlist_model->is_playlist_owner($playlist_id, $user_id)) {
            echo json_encode(array('success' => false, 'message' => 'Unauthorized'));
            return;
        }
        
        if ($this->Playlist_model->remove_song_from_playlist($playlist_id, $song_id)) {
            echo json_encode(array('success' => true, 'message' => 'Song removed!'));
        } else {
            echo json_encode(array('success' => false, 'message' => 'Remove failed'));
        }
    }

    /**
     * Toggle favorite (AJAX)
     */
    public function toggle_favorite() {
        header('Content-Type: application/json');
        
        $user_id = $this->session->userdata('user_id');
        $item_id = $this->input->post('item_id');
        $type = $this->input->post('type'); // song, album, artist
        
        $is_favorited = $this->Playlist_model->is_favorited($user_id, $item_id, $type);
        
        if ($is_favorited) {
            // Remove from favorites
            if ($this->Playlist_model->remove_favorite($user_id, $item_id, $type)) {
                echo json_encode(array(
                    'success' => true,
                    'action' => 'removed',
                    'is_favorited' => false,
                    'message' => 'Removed from favorites'
                ));
            } else {
                echo json_encode(array('success' => false, 'message' => 'Failed to remove'));
            }
        } else {
            // Add to favorites
            if ($this->Playlist_model->add_favorite($user_id, $item_id, $type)) {
                echo json_encode(array(
                    'success' => true,
                    'action' => 'added',
                    'is_favorited' => true,
                    'message' => 'Added to favorites'
                ));
            } else {
                echo json_encode(array('success' => false, 'message' => 'Failed to add'));
            }
        }
    }

    /**
     * Track play (AJAX)
     */
    public function track_play() {
        header('Content-Type: application/json');
        
        $user_id = $this->session->userdata('user_id');
        $song_id = $this->input->post('song_id');
        $duration_played = $this->input->post('duration_played') ?? 0;
        
        if ($this->Playlist_model->add_play_history($user_id, $song_id, $duration_played)) {
            echo json_encode(array('success' => true));
        } else {
            echo json_encode(array('success' => false));
        }
    }

    /**
     * Return favorite songs as JSON (AJAX)
     */
    public function get_favorites_ajax() {
        header('Content-Type: application/json');
        $user_id = $this->session->userdata('user_id');
        if (!$user_id) {
            echo json_encode(['success' => false, 'message' => 'Unauthorized']);
            return;
        }
        $songs = $this->Playlist_model->get_favorite_songs($user_id);
        echo json_encode(['success' => true, 'favorites' => $songs]);
    }
}
