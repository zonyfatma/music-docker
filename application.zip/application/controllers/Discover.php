<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Discover extends MY_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Music_model');
    }

    public function index() {
        // Get all artists for discovery
        $data['all_artists'] = $this->Music_model->get_all_artists();
        
        // Get random featured albums - replace demo albums with admin-uploaded music
        $uploaded_featured = $this->Music_model->get_uploaded_music(12);
        $featured_albums = array();
        foreach ($uploaded_featured as $u) {
            $fa = new stdClass();
            $fa->cover_image = isset($u->cover_image) ? $u->cover_image : '';
            $fa->title = isset($u->title) ? $u->title : '';
            $fa->artist_name = isset($u->artist) ? $u->artist : (isset($u->artist_name) ? $u->artist_name : 'Unknown');
            $featured_albums[] = $fa;
        }
        $data['featured_albums'] = $featured_albums;
        
        // Get trending songs - use popular uploaded music instead of legacy songs
        $uploaded_trending = $this->Music_model->get_popular_uploaded_music(12);
        $trending_songs = array();
        foreach ($uploaded_trending as $u) {
            $t = new stdClass();
            $t->cover_image = isset($u->cover_image) ? $u->cover_image : '';
            $t->title = isset($u->title) ? $u->title : '';
            $t->artist_name = isset($u->artist_name) ? $u->artist_name : (isset($u->artist) ? $u->artist : 'Unknown');
            // no release year for uploaded items; leave empty
            $t->release_year = '';
            // also include music id so play buttons can use data-music-id
            if (isset($u->id)) $t->music_id = $u->id;
            $trending_songs[] = $t;
        }
        $data['trending_songs'] = $trending_songs;
        
        // Get new releases - use admin-uploaded music instead of demo albums
        $uploaded = $this->Music_model->get_uploaded_music(8);
        // map uploaded music fields to the album-like shape expected by the view
        $new_releases = array();
        foreach ($uploaded as $u) {
            $nr = new stdClass();
            $nr->cover_image = isset($u->cover_image) ? $u->cover_image : '';
            $nr->title = isset($u->title) ? $u->title : '';
            $nr->artist_name = isset($u->artist) ? $u->artist : (isset($u->artist_name) ? $u->artist_name : 'Unknown');
            // try to use created_at as release year if available
            $nr->release_year = (isset($u->created_at) && $u->created_at) ? date('Y', strtotime($u->created_at)) : '';
            $new_releases[] = $nr;
        }
        $data['new_releases'] = $new_releases;
        
        // Get genres/categories
        $data['categories'] = array(
            array('name' => 'Pop', 'color' => '#E13300', 'icon' => 'fa-star'),
            array('name' => 'Rock', 'color' => '#8E44AD', 'icon' => 'fa-guitar'),
            array('name' => 'Hip-Hop', 'color' => '#F39C12', 'icon' => 'fa-microphone'),
            array('name' => 'Electronic', 'color' => '#3498DB', 'icon' => 'fa-bolt'),
            array('name' => 'Jazz', 'color' => '#E74C3C', 'icon' => 'fa-saxophone'),
            array('name' => 'Classical', 'color' => '#1ABC9C', 'icon' => 'fa-music'),
            array('name' => 'R&B', 'color' => '#9B59B6', 'icon' => 'fa-heart'),
            array('name' => 'Country', 'color' => '#D35400', 'icon' => 'fa-hat-cowboy')
        );

        $this->load->view('discover', $data);
    }

    /**
     * AJAX endpoint: return uploaded music for a given genre
     */
    public function genre($genre_name = null) {
        if (!$genre_name) {
            header('HTTP/1.1 400 Bad Request');
            echo json_encode(array('error' => 'genre required'));
            return;
        }

        $songs = $this->Music_model->get_uploaded_music_by_genre($genre_name, 50);

        header('Content-Type: application/json');
        echo json_encode(array('genre' => $genre_name, 'songs' => $songs));
    }

    public function category($category_name) {
        $data['category'] = $category_name;
        $data['songs'] = $this->Music_model->get_songs_by_category($category_name);
        $this->load->view('category', $data);
    }
}
