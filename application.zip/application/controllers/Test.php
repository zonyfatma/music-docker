<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Test extends MY_Controller {

    public function index() {
        $this->load->view('test_navigation');
    }

    public function info() {
        $this->load->view('info');
    }
}
