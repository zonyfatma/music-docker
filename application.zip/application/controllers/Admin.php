<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends MY_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Admin_model');
        $this->load->library('session');
        $this->load->helper('url');
        
        // Check if user is logged in and is admin
        if (!$this->session->userdata('logged_in')) {
            redirect('auth/login');
        }
        
        $user_id = $this->session->userdata('user_id');
        $user_data = $this->Admin_model->get_user($user_id);
        
        if (!$user_data || $user_data['role_id'] != 1) {
            // Not an admin, redirect to home
            $this->session->set_flashdata('error', 'Anda tidak memiliki akses ke halaman admin.');
            redirect('home');
        }
        
        // Log activity
        $this->log_activity('page_view', 'Mengakses ' . $this->router->fetch_method());
    }
    
    // ==========================================
    // DASHBOARD UTAMA
    // ==========================================
    
    public function index() {
        $this->dashboard();
    }
    
    public function dashboard() {
        $data['title'] = 'Dashboard Admin';
        $data['stats'] = $this->Admin_model->get_dashboard_stats();
        $data['recent_users'] = $this->Admin_model->get_all_users(5, 0);
        $data['notifications'] = $this->Admin_model->get_notifications(5);
        $data['usage_trend'] = $this->Admin_model->get_usage_trend(7);
        
        $this->load->view('admin/header', $data);
        $this->load->view('admin/sidebar');
        $this->load->view('admin/dashboard', $data);
        $this->load->view('admin/footer');
    }
    
    // ==========================================
    // MANAJEMEN PENGGUNA
    // ==========================================
    
    public function users() {
        $limit = 20;
        $page = $this->input->get('page') ? $this->input->get('page') : 1;
        $offset = ($page - 1) * $limit;
        
        $filters = array(
            'status' => $this->input->get('status'),
            'role_id' => $this->input->get('role_id'),
            'search' => $this->input->get('search')
        );
        
        $data['title'] = 'Manajemen Pengguna';
        $data['users'] = $this->Admin_model->get_all_users($limit, $offset, $filters);
        $data['total_users'] = $this->Admin_model->count_users($filters);
        $data['total_pages'] = ceil($data['total_users'] / $limit);
        $data['current_page'] = $page;
        $data['roles'] = $this->Admin_model->get_all_roles();
        
        $this->load->view('admin/header', $data);
        $this->load->view('admin/sidebar');
        $this->load->view('admin/users/list', $data);
        $this->load->view('admin/footer');
    }
    
    public function user_detail($user_id) {
        $data['title'] = 'Detail Pengguna';
        $data['user'] = $this->Admin_model->get_user($user_id);
        
        if (!$data['user']) {
            $this->session->set_flashdata('error', 'Pengguna tidak ditemukan.');
            redirect('admin/users');
        }
        
        $data['activity'] = $this->Admin_model->get_user_activity($user_id, 20);
        $data['roles'] = $this->Admin_model->get_all_roles();
        
        $this->load->view('admin/header', $data);
        $this->load->view('admin/sidebar');
        $this->load->view('admin/users/detail', $data);
        $this->load->view('admin/footer');
    }
    
    public function user_update($user_id) {
        if ($this->input->post()) {
            $update_data = array(
                'username' => $this->input->post('username'),
                'email' => $this->input->post('email'),
                'role_id' => $this->input->post('role_id'),
                'status' => $this->input->post('status')
            );
            
            if ($this->Admin_model->update_user($user_id, $update_data)) {
                $this->log_activity('user_update', 'Memperbarui data pengguna ID: ' . $user_id);
                $this->session->set_flashdata('success', 'Data pengguna berhasil diperbarui.');
            } else {
                $this->session->set_flashdata('error', 'Gagal memperbarui data pengguna.');
            }
        }
        
        redirect('admin/user_detail/' . $user_id);
    }
    
    public function user_delete($user_id) {
        if ($user_id == $this->session->userdata('user_id')) {
            $this->session->set_flashdata('error', 'Anda tidak dapat menghapus akun Anda sendiri.');
            redirect('admin/users');
        }
        
        if ($this->Admin_model->delete_user($user_id)) {
            $this->log_activity('user_delete', 'Menghapus pengguna ID: ' . $user_id);
            $this->session->set_flashdata('success', 'Pengguna berhasil dihapus.');
        } else {
            $this->session->set_flashdata('error', 'Gagal menghapus pengguna.');
        }
        
        redirect('admin/users');
    }
    
    public function user_block($user_id) {
        if ($this->Admin_model->change_user_status($user_id, 'blocked')) {
            $this->log_activity('user_block', 'Memblokir pengguna ID: ' . $user_id);
            $this->session->set_flashdata('success', 'Pengguna berhasil diblokir.');
        } else {
            $this->session->set_flashdata('error', 'Gagal memblokir pengguna.');
        }
        
        redirect('admin/user_detail/' . $user_id);
    }
    
    public function user_unblock($user_id) {
        if ($this->Admin_model->change_user_status($user_id, 'active')) {
            $this->log_activity('user_unblock', 'Mengaktifkan kembali pengguna ID: ' . $user_id);
            $this->session->set_flashdata('success', 'Pengguna berhasil diaktifkan kembali.');
        } else {
            $this->session->set_flashdata('error', 'Gagal mengaktifkan pengguna.');
        }
        
        redirect('admin/user_detail/' . $user_id);
    }
    
    // ==========================================
    // MANAJEMEN MUSIK
    // ==========================================
    
    public function music() {
        $limit = 20;
        $page = $this->input->get('page') ? $this->input->get('page') : 1;
        $offset = ($page - 1) * $limit;
        
        $filters = array(
            'status' => $this->input->get('status'),
            'search' => $this->input->get('search')
        );
        
        $data['title'] = 'Manajemen Musik';
        $data['music'] = $this->Admin_model->get_all_music($limit, $offset, $filters);
        $data['total_music'] = $this->Admin_model->count_music($filters);
        $data['total_pages'] = ceil($data['total_music'] / $limit);
        $data['current_page'] = $page;
        
        $this->load->view('admin/header', $data);
        $this->load->view('admin/sidebar');
        $this->load->view('admin/music/list', $data);
        $this->load->view('admin/footer');
    }
    
    public function music_detail($music_id) {
        $data['title'] = 'Detail Musik';
        $data['music'] = $this->Admin_model->get_music($music_id);
        
        if (!$data['music']) {
            $this->session->set_flashdata('error', 'Musik tidak ditemukan.');
            redirect('admin/music');
        }
        
        $this->load->view('admin/header', $data);
        $this->load->view('admin/sidebar');
        $this->load->view('admin/music/detail', $data);
        $this->load->view('admin/footer');
    }
    
    public function music_approve($music_id) {
        if ($this->Admin_model->approve_music($music_id)) {
            $this->log_activity('music_approve', 'Menyetujui musik ID: ' . $music_id);
            $this->session->set_flashdata('success', 'Musik berhasil disetujui.');
        } else {
            $this->session->set_flashdata('error', 'Gagal menyetujui musik.');
        }
        
        redirect('admin/music');
    }
    
    public function music_reject($music_id) {
        if ($this->Admin_model->reject_music($music_id)) {
            $this->log_activity('music_reject', 'Menolak musik ID: ' . $music_id);
            $this->session->set_flashdata('success', 'Musik berhasil ditolak.');
        } else {
            $this->session->set_flashdata('error', 'Gagal menolak musik.');
        }
        
        redirect('admin/music');
    }
    
    public function music_delete($music_id) {
        if ($this->Admin_model->delete_music($music_id)) {
            $this->log_activity('music_delete', 'Menghapus musik ID: ' . $music_id);
            $this->session->set_flashdata('success', 'Musik berhasil dihapus.');
        } else {
            $this->session->set_flashdata('error', 'Gagal menghapus musik.');
        }
        
        redirect('admin/music');
    }
    
    // ==========================================
    // MANAJEMEN PODCAST
    // ==========================================
    
    public function podcasts() {
        $limit = 20;
        $page = $this->input->get('page') ? $this->input->get('page') : 1;
        $offset = ($page - 1) * $limit;
        
        $filters = array(
            'status' => $this->input->get('status'),
            'search' => $this->input->get('search')
        );
        
        $data['title'] = 'Manajemen Podcast';
        $data['podcasts'] = $this->Admin_model->get_all_podcasts($limit, $offset, $filters);
        $data['total_podcasts'] = $this->Admin_model->count_podcasts($filters);
        $data['total_pages'] = ceil($data['total_podcasts'] / $limit);
        $data['current_page'] = $page;
        
        $this->load->view('admin/header', $data);
        $this->load->view('admin/sidebar');
        $this->load->view('admin/podcasts/list', $data);
        $this->load->view('admin/footer');
    }
    
    public function podcast_detail($podcast_id) {
        $data['title'] = 'Detail Podcast';
        $data['podcast'] = $this->Admin_model->get_podcast($podcast_id);
        
        if (!$data['podcast']) {
            $this->session->set_flashdata('error', 'Podcast tidak ditemukan.');
            redirect('admin/podcasts');
        }
        
        $this->load->view('admin/header', $data);
        $this->load->view('admin/sidebar');
        $this->load->view('admin/podcasts/detail', $data);
        $this->load->view('admin/footer');
    }
    
    public function podcast_delete($podcast_id) {
        if ($this->Admin_model->delete_podcast($podcast_id)) {
            $this->log_activity('podcast_delete', 'Menghapus podcast ID: ' . $podcast_id);
            $this->session->set_flashdata('success', 'Podcast berhasil dihapus.');
        } else {
            $this->session->set_flashdata('error', 'Gagal menghapus podcast.');
        }
        
        redirect('admin/podcasts');
    }
    
    // ==========================================
    // MANAJEMEN PLAYLIST
    // ==========================================
    
    public function playlists() {
        $limit = 20;
        $page = $this->input->get('page') ? $this->input->get('page') : 1;
        $offset = ($page - 1) * $limit;
        
        $filters = array(
            'status' => $this->input->get('status'),
            'search' => $this->input->get('search')
        );
        
        $data['title'] = 'Manajemen Playlist';
        $data['playlists'] = $this->Admin_model->get_all_playlists($limit, $offset, $filters);
        $data['total_playlists'] = $this->Admin_model->count_playlists($filters);
        $data['total_pages'] = ceil($data['total_playlists'] / $limit);
        $data['current_page'] = $page;
        
        $this->load->view('admin/header', $data);
        $this->load->view('admin/sidebar');
        $this->load->view('admin/playlists/list', $data);
        $this->load->view('admin/footer');
    }
    
    public function playlist_delete($playlist_id) {
        if ($this->Admin_model->delete_playlist($playlist_id)) {
            $this->log_activity('playlist_delete', 'Menghapus playlist ID: ' . $playlist_id);
            $this->session->set_flashdata('success', 'Playlist berhasil dihapus.');
        } else {
            $this->session->set_flashdata('error', 'Gagal menghapus playlist.');
        }
        
        redirect('admin/playlists');
    }
    
    // ==========================================
    // LOG AKTIVITAS
    // ==========================================
    
    public function logs() {
        $limit = 50;
        $page = $this->input->get('page') ? $this->input->get('page') : 1;
        $offset = ($page - 1) * $limit;
        
        $filters = array(
            'user_id' => $this->input->get('user_id'),
            'action' => $this->input->get('action'),
            'date_from' => $this->input->get('date_from'),
            'date_to' => $this->input->get('date_to')
        );
        
        $data['title'] = 'Log Aktivitas';
        $data['logs'] = $this->Admin_model->get_activity_logs($limit, $offset, $filters);
        $data['total_logs'] = $this->Admin_model->count_activity_logs($filters);
        $data['total_pages'] = ceil($data['total_logs'] / $limit);
        $data['current_page'] = $page;
        
        $this->load->view('admin/header', $data);
        $this->load->view('admin/sidebar');
        $this->load->view('admin/logs/list', $data);
        $this->load->view('admin/footer');
    }
    
    // ==========================================
    // NOTIFIKASI
    // ==========================================
    
    public function notifications() {
        $data['title'] = 'Notifikasi';
        $data['notifications'] = $this->Admin_model->get_notifications(50);
        
        $this->load->view('admin/header', $data);
        $this->load->view('admin/sidebar');
        $this->load->view('admin/notifications/list', $data);
        $this->load->view('admin/footer');
    }
    
    public function notification_read($notification_id) {
        $this->Admin_model->mark_notification_read($notification_id);
        redirect('admin/notifications');
    }
    
    public function notifications_read_all() {
        $this->Admin_model->mark_all_notifications_read();
        $this->session->set_flashdata('success', 'Semua notifikasi telah ditandai sebagai dibaca.');
        redirect('admin/notifications');
    }
    
    // ==========================================
    // LAPORAN DAN STATISTIK
    // ==========================================
    
    public function reports() {
        $data['title'] = 'Laporan & Statistik';
        $data['stats'] = $this->Admin_model->get_dashboard_stats();
        $data['usage_trend'] = $this->Admin_model->get_usage_trend(30);
        $data['user_growth'] = $this->Admin_model->get_user_growth(30);
        
        $this->load->view('admin/header', $data);
        $this->load->view('admin/sidebar');
        $this->load->view('admin/reports/index', $data);
        $this->load->view('admin/footer');
    }
    
    public function export_report() {
        $type = $this->input->get('type');
        $format = $this->input->get('format');
        $date_from = $this->input->get('date_from');
        $date_to = $this->input->get('date_to');
        
        $report_data = $this->Admin_model->get_report_data($type, $date_from, $date_to);
        
        if ($format == 'csv') {
            $this->export_csv($report_data, $type);
        } elseif ($format == 'pdf') {
            $this->export_pdf($report_data, $type);
        }
    }
    
    private function export_csv($data, $filename) {
        $this->load->helper('download');
        
        $csv = '';
        if (!empty($data)) {
            // Header
            $csv .= implode(',', array_keys($data[0])) . "\n";
            
            // Data
            foreach ($data as $row) {
                $csv .= implode(',', array_map(function($item) {
                    return '"' . str_replace('"', '""', $item) . '"';
                }, $row)) . "\n";
            }
        }
        
        force_download($filename . '_' . date('Y-m-d') . '.csv', $csv);
    }
    
    private function export_pdf($data, $filename) {
        // You'll need to install a PDF library like TCPDF or mPDF
        // This is a placeholder
        $this->session->set_flashdata('info', 'Export PDF akan segera tersedia.');
        redirect('admin/reports');
    }
    
    // ==========================================
    // PENGATURAN SISTEM
    // ==========================================
    
    public function settings() {
        $data['title'] = 'Pengaturan Sistem';
        $data['settings'] = $this->Admin_model->get_all_settings();
        $data['roles'] = $this->Admin_model->get_all_roles();
        
        $this->load->view('admin/header', $data);
        $this->load->view('admin/sidebar');
        $this->load->view('admin/settings/index', $data);
        $this->load->view('admin/footer');
    }
    
    public function settings_update() {
        if ($this->input->post()) {
            $settings = $this->input->post('settings');
            
            foreach ($settings as $key => $value) {
                $this->Admin_model->update_setting($key, $value);
            }
            
            $this->log_activity('settings_update', 'Memperbarui pengaturan sistem');
            $this->session->set_flashdata('success', 'Pengaturan berhasil diperbarui.');
        }
        
        redirect('admin/settings');
    }
    
    // ==========================================
    // HELPER FUNCTIONS
    // ==========================================
    
    private function log_activity($action, $description = '') {
        $this->Admin_model->log_activity(
            $this->session->userdata('user_id'),
            $action,
            $description,
            $this->input->ip_address(),
            $this->input->user_agent()
        );
    }
    
    // ==========================================
    // AJAX ENDPOINTS
    // ==========================================
    
    public function ajax_get_stats() {
        header('Content-Type: application/json');
        echo json_encode($this->Admin_model->get_dashboard_stats());
    }
    
    public function ajax_search() {
        $query = $this->input->get('q');
        $type = $this->input->get('type');
        
        $results = array();
        
        if ($type == 'users' || $type == 'all') {
            $users = $this->Admin_model->get_all_users(5, 0, array('search' => $query));
            $results['users'] = $users;
        }
        
        if ($type == 'music' || $type == 'all') {
            $music = $this->Admin_model->get_all_music(5, 0, array('search' => $query));
            $results['music'] = $music;
        }
        
        if ($type == 'podcasts' || $type == 'all') {
            $podcasts = $this->Admin_model->get_all_podcasts(5, 0, array('search' => $query));
            $results['podcasts'] = $podcasts;
        }
        
        header('Content-Type: application/json');
        echo json_encode($results);
    }
}
