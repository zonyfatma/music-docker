<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends MY_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Music_model');
        $this->load->helper('url');
    }

    public function index() {
        // Default artist (Ed Sheeran - ID 1)
        $artist_id = $this->uri->segment(3) ? $this->uri->segment(3) : 1;
        
        // Get user ID from session if logged in
        $user_id = $this->session->userdata('user_id');
        
        $data['artist'] = $this->Music_model->get_artist($artist_id);
        // Default albums from artist table
        $data['albums'] = $this->Music_model->get_artist_albums($artist_id);

        // If there are uploaded music items for this artist, prefer showing them
        if (!empty($data['artist']) && !empty($data['artist']->name)) {
            $uploaded_albums = $this->Music_model->get_uploaded_music_by_artist($data['artist']->name, 6);
            if (!empty($uploaded_albums)) {
                // Map uploaded music objects to album-like objects expected by the view
                $mapped = array();
                foreach ($uploaded_albums as $m) {
                    $obj = new stdClass();
                    $obj->cover_image = isset($m->cover_image) ? $m->cover_image : '';
                    // Use the music's title as the album card title (uploaded song)
                    $obj->title = isset($m->title) ? $m->title : '';
                    // Derive release year from created_at if present
                    $obj->release_year = isset($m->created_at) && $m->created_at ? date('Y', strtotime($m->created_at)) : '';
                    // album_type: use music.album if present, otherwise mark as 'Single'
                    $obj->album_type = !empty($m->album) ? $m->album : 'Single';
                    $mapped[] = $obj;
                }
                $data['albums'] = $mapped;
            }
        }
        // Use uploaded music (admin uploads) for home page lists so real uploaded tracks are shown
        $data['songs'] = $this->Music_model->get_popular_uploaded_music(20);
        $data['recent_plays'] = $this->Music_model->get_recent_plays(10, $user_id);
        $data['similar_artists'] = $this->Music_model->get_similar_artists($artist_id);
        $data['current_song'] = null;

        // Prefer an uploaded music by this artist for the header/player if available
        if (!empty($data['artist']) && !empty($data['artist']->name)) {
            $uploaded_for_artist = $this->Music_model->get_uploaded_music_by_artist($data['artist']->name, 1);
            if (!empty($uploaded_for_artist)) {
                $data['current_song'] = $uploaded_for_artist[0];
            }
        }

        // Fallback: Get first song for player if available
        if (empty($data['current_song']) && !empty($data['songs'])) {
            $data['current_song'] = $data['songs'][0];
        }

        $this->load->view('home', $data);
    }

    public function artist($artist_id) {
        $this->index();
    }

    public function play($song_id) {
        // Get user ID from session if logged in
        $user_id = $this->session->userdata('user_id');
        
        // Add to recent plays
        $this->Music_model->add_recent_play($song_id, $user_id);
        
        // Increment play count
        $this->Music_model->increment_play_count($song_id);
        
        // Get song details and return as JSON for AJAX
        $song = $this->Music_model->get_song($song_id);
        
        if ($this->input->is_ajax_request()) {
            echo json_encode($song);
        } else {
            redirect('home');
        }
    }

    public function search() {
        $keyword = $this->input->get('q');
        
        if ($keyword) {
            $data['results'] = $this->Music_model->search($keyword);
            $data['keyword'] = $keyword;
            
            if ($this->input->is_ajax_request()) {
                echo json_encode($data['results']);
            } else {
                // load default search view if exists; also include uploaded_music partial
                // ensure `uploaded_music` is available for view
                $data['uploaded_music'] = isset($data['results']['uploaded_music']) ? $data['results']['uploaded_music'] : [];
                if (file_exists(APPPATH . 'views/search.php')) {
                    $this->load->view('search', $data);
                } else {
                    // fallback: render a simple page showing uploaded music results
                    $this->load->view('partials/header', $data);
                    echo '<main class="main-content"><h2>Search Results for: ' . htmlspecialchars($keyword) . '</h2>';
                    $this->load->view('partials/search_uploaded', array('uploaded_music' => $data['uploaded_music']));
                    echo '</main>';
                    $this->load->view('partials/player');
                }
            }
        } else {
            redirect('home');
        }
    }

    // AJAX endpoint: return uploaded music search results only
    public function search_uploaded() {
        $keyword = $this->input->get('q');
        if (!$keyword) {
            echo json_encode(array('uploaded_music' => []));
            return;
        }

        $results = $this->Music_model->search($keyword);
        $uploaded = isset($results['uploaded_music']) ? $results['uploaded_music'] : [];
        echo json_encode(array('uploaded_music' => $uploaded));
    }

    /**
     * Return uploaded music details as JSON (used by client to fetch file path)
     */
    public function get_uploaded_music($music_id = null) {
        if (!$music_id) {
            header('HTTP/1.1 400 Bad Request');
            echo json_encode(array('error' => 'music_id required'));
            return;
        }

        $music = $this->Music_model->get_uploaded_music_by_id($music_id);
        if (!$music) {
            header('HTTP/1.1 404 Not Found');
            echo json_encode(array('error' => 'not found'));
            return;
        }

        header('Content-Type: application/json');
        echo json_encode($music);
    }
}
