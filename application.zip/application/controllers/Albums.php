<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Albums extends MY_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Music_model');
    }

    public function index() {
        // Use model helper to get uploaded albums grouped by (artist + album)
        $all_albums = $this->Music_model->get_uploaded_albums();

        // New Releases - most recent by latest_date
        $data['new_releases'] = array_slice($all_albums, 0, 6);

        // Popular Albums - by play_count
        $popular = $all_albums;
        usort($popular, function($a, $b){ return ($b->play_count ?? 0) - ($a->play_count ?? 0); });
        $data['popular_albums'] = array_slice($popular, 0, 6);

        // Albums by year
        $albums_2024 = array_filter($all_albums, function($a){ return intval($a->release_year) === 2024; });
        $albums_2023 = array_filter($all_albums, function($a){ return intval($a->release_year) === 2023; });
        $data['albums_2024'] = array_slice(array_values($albums_2024), 0, 6);
        $data['albums_2023'] = array_slice(array_values($albums_2023), 0, 6);

        // All albums list
        $data['all_albums'] = $all_albums;

        $this->load->view('albums', $data);
    }

    // View uploaded album by artist + album slug
    public function uploaded($artist_slug = null, $album_slug = null) {
        if (!$artist_slug || !$album_slug) {
            show_404();
            return;
        }

        $artist = urldecode($artist_slug);
        $album = urldecode($album_slug);

        $tracks = $this->Music_model->get_uploaded_album_tracks($artist, $album);
        if (empty($tracks)) {
            // not found
            show_404();
            return;
        }

        $data = array();
        $data['album'] = new stdClass();
        $data['album']->title = !empty($tracks[0]->album) ? $tracks[0]->album : $tracks[0]->title;
        $data['album']->artist_name = $tracks[0]->artist;
        $data['album']->cover_image = $tracks[0]->cover_image ?? '';
        $data['album']->release_year = isset($tracks[0]->created_at) ? date('Y', strtotime($tracks[0]->created_at)) : '';
        $data['songs'] = $tracks;

        $this->load->view('album_uploaded', $data);
    }

    public function view($album_id) {
        $data['album'] = $this->Music_model->get_album_details($album_id);
        $data['songs'] = $this->Music_model->get_album_songs($album_id);
        $data['artist'] = $this->Music_model->get_artist($data['album']->artist_id);
        
        $this->load->view('album_detail', $data);
    }
}
