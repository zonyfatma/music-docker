<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Music extends MY_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Music_model');
    }

    // Halaman browse semua musik
    public function index() {
        $data['all_music'] = $this->Music_model->get_all_music_combined(100);
        $data['uploaded_music'] = $this->Music_model->get_uploaded_music(20);
        // Use popular uploaded music for Trending Now instead of dummy songs
        $data['trending_songs'] = $this->Music_model->get_popular_uploaded_music(20);
        
        $this->load->view('music/browse', $data);
    }

    // Halaman browse musik yang diupload admin
    public function browse() {
        $data['music_list'] = $this->Music_model->get_uploaded_music(50);
        $data['title'] = 'Browse Music';
        
        $this->load->view('music/browse', $data);
    }

    // Play music from uploaded music table
    public function play($music_id) {
        $music = $this->Music_model->get_uploaded_music_by_id($music_id);
        
        if ($music) {
            // Increment play count
            $this->Music_model->increment_music_play_count($music_id);
            
            if ($this->input->is_ajax_request()) {
                echo json_encode($music);
            } else {
                redirect('music/browse');
            }
        } else {
            show_404();
        }
    }
}
