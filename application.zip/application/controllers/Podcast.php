<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Podcast extends MY_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Podcast_model');
        $this->load->model('Music_model'); // Load Music_model to fix the error
    }

    public function index() {
        // Featured podcasts
        $data['featured_podcasts'] = array(
            array(
                'id' => 1,
                'title' => 'The Music Industry Podcast',
                'host' => 'James Anderson',
                'image' => 'music-industry.jpg',
                'episodes' => 156,
                'description' => 'Deep dive into the music business'
            ),
            array(
                'id' => 2,
                'title' => 'Behind The Beat',
                'host' => 'Sarah Williams',
                'image' => 'behind-beat.jpg',
                'episodes' => 89,
                'description' => 'Stories from music producers'
            ),
            array(
                'id' => 3,
                'title' => 'Indie Spotlight',
                'host' => 'Mike Johnson',
                'image' => 'indie-spotlight.jpg',
                'episodes' => 124,
                'description' => 'Showcasing independent artists'
            ),
            array(
                'id' => 4,
                'title' => 'Classic Album Reviews',
                'host' => 'Emma Davis',
                'image' => 'album-reviews.jpg',
                'episodes' => 78,
                'description' => 'Analyzing legendary albums'
            ),
            array(
                'id' => 5,
                'title' => 'Music Tech Talk',
                'host' => 'David Chen',
                'image' => 'music-tech.jpg',
                'episodes' => 92,
                'description' => 'Technology in music production'
            ),
            array(
                'id' => 6,
                'title' => 'Live Sessions',
                'host' => 'Lisa Brown',
                'image' => 'live-sessions.jpg',
                'episodes' => 67,
                'description' => 'Acoustic performances and interviews'
            )
        );

        // Categories
        $data['categories'] = array(
            array('name' => 'Music News', 'color' => '#E13300'),
            array('name' => 'Artist Interviews', 'color' => '#8E44AD'),
            array('name' => 'Music History', 'color' => '#3498DB'),
            array('name' => 'Production Tips', 'color' => '#F39C12'),
            array('name' => 'Live Performances', 'color' => '#1ABC9C'),
            array('name' => 'Industry Insights', 'color' => '#E74C3C')
        );

        // Popular episodes
        $data['popular_episodes'] = array(
            array(
                'id' => 1,
                'title' => 'How Ed Sheeran Writes Hit Songs',
                'podcast' => 'The Music Industry Podcast',
                'duration' => '45:32',
                'date' => '2024-11-10'
            ),
            array(
                'id' => 2,
                'title' => 'The Evolution of Pop Music',
                'podcast' => 'Music Tech Talk',
                'duration' => '52:18',
                'date' => '2024-11-08'
            ),
            array(
                'id' => 3,
                'title' => 'Breaking Into The Music Industry',
                'podcast' => 'Indie Spotlight',
                'duration' => '38:45',
                'date' => '2024-11-05'
            )
        );

        $this->load->view('podcast', $data);
    }

    public function show($podcast_id) {
        $data['podcast_id'] = $podcast_id;
        // Get podcast details and episodes
        $this->load->view('podcast_detail', $data);
    }
}
