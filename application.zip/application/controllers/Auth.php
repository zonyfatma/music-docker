<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('User_model');
        $this->load->library('session');
        $this->load->helper('url');
        $this->load->library('form_validation');
    }

    /**
     * Login page
     */
    public function login() {
        // If already logged in, redirect to home
        if ($this->session->userdata('user_id')) {
            redirect(base_url());
        }

        if ($this->input->method() === 'post') {
            $this->form_validation->set_rules('identifier', 'Email or Username', 'required');
            $this->form_validation->set_rules('password', 'Password', 'required');

            if ($this->form_validation->run() === TRUE) {
                $identifier = $this->input->post('identifier');
                $password = $this->input->post('password');

                $user = $this->User_model->login($identifier, $password);

                if ($user) {
                    // Get user role
                    $this->load->model('Admin_model');
                    $user_details = $this->Admin_model->get_user($user->id);
                    
                    // Update last login and login count
                    $this->db->where('id', $user->id);
                    $this->db->update('users', array(
                        'last_login' => date('Y-m-d H:i:s'),
                        'login_count' => $this->db->query("SELECT login_count FROM users WHERE id = ?", array($user->id))->row()->login_count + 1
                    ));
                    
                    // Set session data
                    $session_data = array(
                        'user_id' => $user->id,
                        'username' => $user->username,
                        'email' => $user->email,
                        'full_name' => $user->full_name,
                        'avatar' => $user->avatar,
                        'is_premium' => $user->is_premium,
                        'role_id' => isset($user_details['role_id']) ? $user_details['role_id'] : 3,
                        'logged_in' => TRUE
                    );
                    $this->session->set_userdata($session_data);

                    // Log login activity
                    if (isset($user_details['role_id'])) {
                        $this->Admin_model->log_activity(
                            $user->id,
                            'login',
                            'User logged in',
                            $this->input->ip_address(),
                            $this->input->user_agent()
                        );
                    }

                    // Set success message
                    $this->session->set_flashdata('success', 'Welcome back, ' . $user->full_name . '!');

                    // Redirect based on role
                    if (isset($user_details['role_id']) && $user_details['role_id'] == 1) {
                        // Admin user - redirect to admin dashboard
                        redirect(base_url('admin'));
                    } else {
                        // Regular user - redirect to home
                        redirect(base_url());
                    }
                } else {
                    $data['error'] = 'Invalid email/username or password';
                    $this->load->view('auth/login', $data);
                }
            } else {
                $this->load->view('auth/login');
            }
        } else {
            $this->load->view('auth/login');
        }
    }

    /**
     * Register page
     */
    public function register() {
        // If already logged in, redirect to home
        if ($this->session->userdata('user_id')) {
            redirect(base_url());
        }

        if ($this->input->method() === 'post') {
            $this->form_validation->set_rules('username', 'Username', 'required|min_length[3]|max_length[50]|alpha_dash');
            $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
            $this->form_validation->set_rules('password', 'Password', 'required|min_length[6]');
            $this->form_validation->set_rules('confirm_password', 'Confirm Password', 'required|matches[password]');
            $this->form_validation->set_rules('full_name', 'Full Name', 'required|max_length[100]');

            if ($this->form_validation->run() === TRUE) {
                // Check if username exists
                if ($this->User_model->username_exists($this->input->post('username'))) {
                    $data['error'] = 'Username already exists';
                    $this->load->view('auth/register', $data);
                    return;
                }

                // Check if email exists
                if ($this->User_model->email_exists($this->input->post('email'))) {
                    $data['error'] = 'Email already registered';
                    $this->load->view('auth/register', $data);
                    return;
                }

                // Register user
                $register_data = array(
                    'username' => $this->input->post('username'),
                    'email' => $this->input->post('email'),
                    'password' => $this->input->post('password'),
                    'full_name' => $this->input->post('full_name')
                );

                if ($this->User_model->register($register_data)) {
                    $this->session->set_flashdata('success', 'Registration successful! Please login.');
                    redirect(base_url('auth/login'));
                } else {
                    $data['error'] = 'Registration failed. Please try again.';
                    $this->load->view('auth/register', $data);
                }
            } else {
                $this->load->view('auth/register');
            }
        } else {
            $this->load->view('auth/register');
        }
    }

    /**
     * Logout
     */
    public function logout() {
        // Destroy session
        $this->session->unset_userdata('user_id');
        $this->session->unset_userdata('username');
        $this->session->unset_userdata('email');
        $this->session->unset_userdata('full_name');
        $this->session->unset_userdata('avatar');
        $this->session->unset_userdata('is_premium');
        $this->session->unset_userdata('logged_in');
        
        $this->session->set_flashdata('success', 'You have been logged out successfully.');
        redirect(base_url('auth/login'));
    }

    /**
     * Check if user is logged in (for AJAX requests)
     */
    public function check_login() {
        header('Content-Type: application/json');
        echo json_encode(array(
            'logged_in' => $this->session->userdata('logged_in') ? true : false,
            'user_id' => $this->session->userdata('user_id')
        ));
    }

    /**
     * Google OAuth login (placeholder)
     */
    public function google() {
        // This is a placeholder for Google OAuth integration
        // You would need to:
        // 1. Install Google API PHP Client library
        // 2. Configure OAuth credentials in Google Cloud Console
        // 3. Implement OAuth flow
        
        $data['error'] = 'Google OAuth not yet configured';
        $this->load->view('auth/login', $data);
    }
}
