<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Radio extends MY_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Music_model');
    }

    public function index() {
        // Get artist-based radio stations
        $data['artist_radios'] = $this->Music_model->get_all_artists();
        
        // Featured radio stations
        $data['featured_radios'] = array(
            array(
                'id' => 1,
                'name' => 'Top Hits Radio',
                'description' => 'The biggest hits from around the world',
                'image' => 'top-hits-radio.jpg',
                'listeners' => 1250000
            ),
            array(
                'id' => 2,
                'name' => 'Chill Vibes',
                'description' => 'Relax and unwind with smooth tracks',
                'image' => 'chill-vibes.jpg',
                'listeners' => 850000
            ),
            array(
                'id' => 3,
                'name' => 'Workout Beats',
                'description' => 'High energy music for your workout',
                'image' => 'workout-beats.jpg',
                'listeners' => 620000
            ),
            array(
                'id' => 4,
                'name' => 'Indie Mix',
                'description' => 'Discover new indie artists',
                'image' => 'indie-mix.jpg',
                'listeners' => 480000
            ),
            array(
                'id' => 5,
                'name' => 'Classic Rock',
                'description' => 'Legendary rock anthems',
                'image' => 'classic-rock.jpg',
                'listeners' => 920000
            ),
            array(
                'id' => 6,
                'name' => 'Jazz Cafe',
                'description' => 'Smooth jazz for relaxing moments',
                'image' => 'jazz-cafe.jpg',
                'listeners' => 340000
            )
        );

        // Genre-based radios
        $data['genre_radios'] = array(
            array('name' => 'Pop Radio', 'color' => '#FF6B9D'),
            array('name' => 'Rock Radio', 'color' => '#8E44AD'),
            array('name' => 'Hip-Hop Radio', 'color' => '#F39C12'),
            array('name' => 'Electronic Radio', 'color' => '#3498DB'),
            array('name' => 'R&B Radio', 'color' => '#E74C3C'),
            array('name' => 'Country Radio', 'color' => '#D35400')
        );

        $this->load->view('radio', $data);
    }

    public function station($station_id) {
        $data['station_id'] = $station_id;
        // Get station details and playlist
        $this->load->view('radio_station', $data);
    }
}
