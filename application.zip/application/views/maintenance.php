<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mode Maintenance - Musikk</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .maintenance-container {
            background: white;
            border-radius: 20px;
            padding: 60px 40px;
            max-width: 600px;
            text-align: center;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        }
        
        .maintenance-icon {
            font-size: 80px;
            margin-bottom: 20px;
            animation: rotate 3s linear infinite;
        }
        
        @keyframes rotate {
            from {
                transform: rotate(0deg);
            }
            to {
                transform: rotate(360deg);
            }
        }
        
        h1 {
            color: #333;
            font-size: 36px;
            margin-bottom: 20px;
            font-weight: 700;
        }
        
        p {
            color: #666;
            font-size: 18px;
            line-height: 1.6;
            margin-bottom: 30px;
        }
        
        .back-button {
            display: inline-block;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 15px 40px;
            text-decoration: none;
            border-radius: 50px;
            font-size: 16px;
            font-weight: 600;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        
        .back-button:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(102, 126, 234, 0.4);
        }
        
        .features {
            margin-top: 40px;
            padding-top: 30px;
            border-top: 2px solid #f0f0f0;
        }
        
        .features h3 {
            color: #333;
            font-size: 20px;
            margin-bottom: 15px;
        }
        
        .features ul {
            list-style: none;
            color: #666;
            font-size: 16px;
        }
        
        .features ul li {
            margin: 10px 0;
            padding-left: 25px;
            position: relative;
        }
        
        .features ul li:before {
            content: "✓";
            position: absolute;
            left: 0;
            color: #667eea;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="maintenance-container">
        <div class="maintenance-icon">⚙️</div>
        <h1>Mode Maintenance Aktif</h1>
        <p>
            Maaf, situs sedang dalam mode pemeliharaan. Kami sedang melakukan pembaruan sistem untuk memberikan pengalaman yang lebih baik.
        </p>
        <p>
            Silakan coba kembali beberapa saat lagi. Terima kasih atas kesabaran Anda!
        </p>
        <a href="/musikk/index.php/auth/logout" class="back-button">Kembali ke Halaman Login</a>
        
        <div class="features">
            <h3>Yang Sedang Kami Tingkatkan:</h3>
            <ul>
                <li>Peningkatan performa sistem</li>
                <li>Perbaikan bug dan optimasi</li>
                <li>Penambahan fitur baru</li>
                <li>Pembaruan keamanan</li>
            </ul>
        </div>
    </div>
</body>
</html>
