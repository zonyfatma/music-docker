<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile - BeatBay</title>
    <link rel="stylesheet" href="<?= base_url('assets/css/main.css') ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        .profile-header {
            padding: 40px;
            background: linear-gradient(135deg, #1ed760 0%, #17a74e 100%);
            border-radius: 12px;
            margin-bottom: 30px;
            display: flex;
            align-items: center;
            gap: 30px;
        }
        
        .profile-avatar {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            border: 5px solid rgba(255, 255, 255, 0.3);
            object-fit: cover;
        }
        
        .profile-info h1 {
            font-size: 48px;
            font-weight: 900;
            margin-bottom: 10px;
            color: #fff;
        }
        
        .profile-stats {
            display: flex;
            gap: 30px;
            margin-top: 15px;
        }
        
        .stat-item {
            display: flex;
            flex-direction: column;
        }
        
        .stat-number {
            font-size: 24px;
            font-weight: 700;
            color: #fff;
        }
        
        .stat-label {
            font-size: 14px;
            color: rgba(255, 255, 255, 0.8);
        }
        
        .profile-tabs {
            display: flex;
            gap: 20px;
            border-bottom: 1px solid var(--border-color);
            margin-bottom: 30px;
        }
        
        .tab-btn {
            padding: 15px 20px;
            background: none;
            border: none;
            color: var(--text-secondary);
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            position: relative;
            transition: all 0.3s ease;
        }
        
        .tab-btn.active {
            color: var(--accent-green);
        }
        
        .tab-btn.active::after {
            content: '';
            position: absolute;
            bottom: -1px;
            left: 0;
            right: 0;
            height: 2px;
            background: var(--accent-green);
        }
        
        .tab-content {
            display: none;
        }
        
        .tab-content.active {
            display: block;
        }
        
        .create-playlist-card {
            padding: 40px;
            background: linear-gradient(135deg, rgba(30, 215, 96, 0.1) 0%, rgba(30, 215, 96, 0.05) 100%);
            border: 2px dashed var(--accent-green);
            border-radius: 12px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .create-playlist-card:hover {
            background: linear-gradient(135deg, rgba(30, 215, 96, 0.15) 0%, rgba(30, 215, 96, 0.08) 100%);
            transform: translateY(-2px);
        }
        
        .create-playlist-card i {
            font-size: 48px;
            color: var(--accent-green);
            margin-bottom: 15px;
        }
        
        .playlists-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .playlist-card {
            background: var(--bg-card);
            border-radius: 8px;
            padding: 16px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .playlist-card:hover {
            background: var(--bg-hover);
            transform: translateY(-4px);
        }
        
        .playlist-cover {
            width: 100%;
            height: 200px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 8px;
            margin-bottom: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 48px;
            color: #fff;
        }
        
        .playlist-card h3 {
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 4px;
        }
        
        .playlist-card p {
            font-size: 13px;
            color: var(--text-secondary);
        }
        
        .songs-list {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }
        
        .song-item-profile {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 12px;
            background: var(--bg-card);
            border-radius: 8px;
            transition: all 0.3s ease;
        }
        
        .song-item-profile:hover {
            background: var(--bg-hover);
        }
        
        .song-cover-small {
            width: 50px;
            height: 50px;
            border-radius: 4px;
            object-fit: cover;
        }
        
        .song-details-profile {
            flex: 1;
        }
        
        .song-details-profile h4 {
            font-size: 14px;
            font-weight: 600;
            margin-bottom: 4px;
        }
        
        .song-details-profile p {
            font-size: 12px;
            color: var(--text-secondary);
        }
        
        .song-actions {
            display: flex;
            gap: 10px;
        }
        
        .btn-play-small {
            width: 36px;
            height: 36px;
            background: var(--accent-green);
            border: none;
            border-radius: 50%;
            color: #000;
            font-size: 14px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s ease;
        }
        
        .btn-play-small:hover {
            transform: scale(1.1);
        }
        
        .empty-state {
            text-align: center;
            padding: 60px 20px;
        }
        
        .empty-state i {
            font-size: 64px;
            color: var(--text-secondary);
            margin-bottom: 20px;
            opacity: 0.5;
        }
        
        .empty-state h3 {
            font-size: 24px;
            margin-bottom: 10px;
        }
        
        .empty-state p {
            color: var(--text-secondary);
            font-size: 14px;
        }
    </style>
</head>
<body>
    <div class="container">
        <?php $this->load->view('partials/sidebar'); ?>

        <main class="main-content">
            <?php $this->load->view('partials/header'); ?>

            <div class="content-wrapper">
                <!-- Profile Header -->
                <div class="profile-header">
                    <img src="<?= $user->avatar ?? 'https://ui-avatars.com/api/?name=' . urlencode($user->full_name) . '&size=150&background=1ed760&color=fff' ?>" 
                         alt="<?= $user->full_name ?>" 
                         class="profile-avatar">
                    <div class="profile-info">
                        <h1><?= $user->full_name ?></h1>
                        <p>@<?= $user->username ?> • <?= $user->is_premium ? '<i class="fas fa-crown"></i> Premium Member' : 'Free Member' ?></p>
                        <div class="profile-stats">
                            <div class="stat-item">
                                <span class="stat-number"><?= count($playlists) ?></span>
                                <span class="stat-label">Playlists</span>
                            </div>
                            <div class="stat-item">
                                <span class="stat-number"><?= count($favorite_songs) ?></span>
                                <span class="stat-label">Favorites</span>
                            </div>
                            <div class="stat-item">
                                <span class="stat-number"><?= count($recently_played) ?></span>
                                <span class="stat-label">Recently Played</span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Tabs -->
                <div class="profile-tabs">
                    <button class="tab-btn active" data-tab="playlists">
                        <i class="fas fa-list-music"></i> My Playlists
                    </button>
                    <button class="tab-btn" data-tab="favorites">
                        <i class="fas fa-heart"></i> Favorites
                    </button>
                    <!-- Listening History and Most Played tabs removed -->
                </div>

                <!-- Tab: My Playlists -->
                <div class="tab-content active" id="playlists">
                    <div class="playlists-grid">
                        <div class="create-playlist-card" onclick="createPlaylist()">
                            <i class="fas fa-plus-circle"></i>
                            <h3>Create New Playlist</h3>
                            <p>Start building your collection</p>
                        </div>
                        
                        <?php foreach($playlists as $playlist): ?>
                        <div class="playlist-card" onclick="window.location.href='<?= base_url('profile/playlist/' . $playlist->id) ?>'">
                            <div class="playlist-cover">
                                <i class="fas fa-music"></i>
                            </div>
                            <h3><?= $playlist->name ?></h3>
                            <p><?= $playlist->song_count ?> songs</p>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Tab: Favorites -->
                <div class="tab-content" id="favorites">
                    <?php if(count($favorite_songs) > 0): ?>
                    <div class="songs-list">
                        <?php foreach($favorite_songs as $song): ?>
                        <div class="song-item-profile">
                            <img src="<?= $song->album_cover ?? 'https://ui-avatars.com/api/?name=' . urlencode($song->title) . '&size=50' ?>" 
                                 alt="<?= $song->title ?>" 
                                 class="song-cover-small">
                            <div class="song-details-profile">
                                <h4><?= $song->title ?></h4>
                                <p><?= $song->artist_name ?> • <?= $song->album_title ?></p>
                            </div>
                            <div class="song-actions">
                                <button class="btn-play-small" onclick="playSong(<?= $song->id ?>)">
                                    <i class="fas fa-play"></i>
                                </button>
                                <button class="favorite-btn favorited" data-item-id="<?= $song->id ?>" data-type="song">
                                    <i class="fas fa-heart"></i>
                                </button>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-heart"></i>
                        <h3>No favorites yet</h3>
                        <p>Start adding songs to your favorites to see them here</p>
                    </div>
                    <?php endif; ?>
                </div>
                    <!-- Listening History and Most Played tabs removed -->
            </div>
        </main>

        <?php $this->load->view('partials/right_sidebar'); ?>
        <?php $this->load->view('partials/player'); ?>
    </div>

    <script>
        // Tab switching
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                // Remove active class from all tabs and contents
                document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
                document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
                
                // Add active class to clicked tab
                this.classList.add('active');
                
                // Show corresponding content
                const tabId = this.getAttribute('data-tab');
                document.getElementById(tabId).classList.add('active');
            });
        });

        // If the URL has a hash (#favorites etc.), open that tab automatically
        (function openTabFromHash(){
            const hash = (window.location.hash || '').replace('#','');
            if (!hash) return;
            const btn = Array.from(document.querySelectorAll('.tab-btn')).find(b => b.getAttribute('data-tab') === hash);
            if (btn) {
                btn.click();
                // scroll into view for better UX
                try { document.getElementById(hash).scrollIntoView({behavior:'smooth'}); } catch(e){}
            }
        })();

        // Create playlist
        function createPlaylist() {
            const name = prompt('Enter playlist name:');
            if (name) {
                fetch('<?= base_url('profile/create_playlist') ?>', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'name=' + encodeURIComponent(name)
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('Playlist created successfully!');
                        window.location.reload();
                    } else {
                        alert('Failed to create playlist');
                    }
                });
            }
        }

        // Toggle favorite
        function toggleFavorite(itemId, type, btn) {
            fetch('<?= base_url('profile/toggle_favorite') ?>', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'item_id=' + itemId + '&type=' + type
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    if (data.is_favorited) {
                        btn.classList.add('favorited');
                    } else {
                        btn.classList.remove('favorited');
                        // Remove from DOM if in favorites tab
                        if (document.getElementById('favorites').classList.contains('active')) {
                            btn.closest('.song-item-profile').remove();
                        }
                    }
                }
            });
        }

        // Play song
        function playSong(songId) {
            // Track play
            fetch('<?= base_url('profile/track_play') ?>', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'song_id=' + songId
            });
            
            // Add actual play functionality here
            alert('Playing song ID: ' + songId);
        }
    </script>
    <script src="<?= base_url('assets/js/main.js') ?>"></script>
</body>
</html>
