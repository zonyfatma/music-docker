<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - BeatBay</title>
    <link rel="stylesheet" href="<?= base_url('assets/css/main.css') ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        .auth-container {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #0a0e27 0%, #1a1f3a 100%);
            padding: 20px;
        }
        
        .auth-box {
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 40px;
            width: 100%;
            max-width: 450px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .auth-logo {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .auth-logo i {
            font-size: 50px;
            color: #1ed760;
            margin-bottom: 10px;
        }
        
        .auth-logo h1 {
            color: #fff;
            font-size: 28px;
            font-weight: 700;
            margin: 10px 0;
        }
        
        .auth-logo p {
            color: #b3b3b3;
            font-size: 14px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            color: #fff;
            font-size: 14px;
            font-weight: 500;
            margin-bottom: 8px;
        }
        
        .form-group input {
            width: 100%;
            padding: 12px 15px;
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 8px;
            color: #fff;
            font-size: 14px;
            transition: all 0.3s ease;
        }
        
        .form-group input:focus {
            outline: none;
            border-color: #1ed760;
            background: rgba(255, 255, 255, 0.15);
        }
        
        .form-group input::placeholder {
            color: #666;
        }
        
        .btn-register {
            width: 100%;
            padding: 14px;
            background: #1ed760;
            border: none;
            border-radius: 50px;
            color: #000;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-top: 10px;
        }
        
        .btn-register:hover {
            background: #1fdf64;
            transform: scale(1.02);
        }
        
        .divider {
            display: flex;
            align-items: center;
            margin: 25px 0;
            color: #666;
            font-size: 14px;
        }
        
        .divider::before,
        .divider::after {
            content: '';
            flex: 1;
            height: 1px;
            background: rgba(255, 255, 255, 0.1);
        }
        
        .divider span {
            padding: 0 15px;
        }
        
        .btn-google {
            width: 100%;
            padding: 12px;
            background: #fff;
            border: none;
            border-radius: 50px;
            color: #000;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }
        
        .btn-google:hover {
            background: #f0f0f0;
        }
        
        .btn-google i {
            font-size: 18px;
        }
        
        .auth-footer {
            text-align: center;
            margin-top: 25px;
            color: #b3b3b3;
            font-size: 14px;
        }
        
        .auth-footer a {
            color: #1ed760;
            text-decoration: none;
            font-weight: 600;
        }
        
        .auth-footer a:hover {
            text-decoration: underline;
        }
        
        .alert {
            padding: 12px 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 14px;
        }
        
        .alert-error {
            background: rgba(255, 69, 58, 0.2);
            border: 1px solid rgba(255, 69, 58, 0.4);
            color: #ff453a;
        }
        
        .validation-errors {
            background: rgba(255, 69, 58, 0.2);
            border: 1px solid rgba(255, 69, 58, 0.4);
            border-radius: 8px;
            padding: 12px 15px;
            margin-bottom: 20px;
            color: #ff453a;
            font-size: 13px;
        }
        
        .validation-errors ul {
            margin: 0;
            padding-left: 20px;
        }
        
        .validation-errors li {
            margin: 5px 0;
        }
    </style>
</head>
<body>
    <div class="auth-container">
        <div class="auth-box">
            <div class="auth-logo">
                <i class="fas fa-music"></i>
                <h1>Join BeatBay</h1>
                <p>Create your account and start listening</p>
            </div>

            <?php if (isset($error)): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i> <?= $error ?>
                </div>
            <?php endif; ?>

            <?php if (validation_errors()): ?>
                <div class="validation-errors">
                    <?= validation_errors() ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="<?= base_url('auth/register') ?>">
                <div class="form-group">
                    <label for="full_name">Full Name</label>
                    <input 
                        type="text" 
                        id="full_name" 
                        name="full_name" 
                        placeholder="Enter your full name" 
                        required
                        value="<?= set_value('full_name') ?>"
                    >
                </div>

                <div class="form-group">
                    <label for="username">Username</label>
                    <input 
                        type="text" 
                        id="username" 
                        name="username" 
                        placeholder="Choose a username" 
                        required
                        value="<?= set_value('username') ?>"
                    >
                </div>

                <div class="form-group">
                    <label for="email">Email</label>
                    <input 
                        type="email" 
                        id="email" 
                        name="email" 
                        placeholder="Enter your email" 
                        required
                        value="<?= set_value('email') ?>"
                    >
                </div>

                <div class="form-group">
                    <label for="password">Password</label>
                    <input 
                        type="password" 
                        id="password" 
                        name="password" 
                        placeholder="Create a password (min 6 characters)" 
                        required
                    >
                </div>

                <div class="form-group">
                    <label for="confirm_password">Confirm Password</label>
                    <input 
                        type="password" 
                        id="confirm_password" 
                        name="confirm_password" 
                        placeholder="Confirm your password" 
                        required
                    >
                </div>

                <button type="submit" class="btn-register">
                    Create Account
                </button>
            </form>

            <div class="divider">
                <span>OR</span>
            </div>

            <button class="btn-google" onclick="alert('Google OAuth not yet configured')">
                <i class="fab fa-google"></i>
                Sign up with Google
            </button>

            <div class="auth-footer">
                Already have an account? <a href="<?= base_url('auth/login') ?>">Login</a>
            </div>
        </div>
    </div>
</body>
</html>
