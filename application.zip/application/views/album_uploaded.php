<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($album->title) ? $album->title : 'Album' ?> - <?= isset($this->app_settings['app_name']) ? $this->app_settings['app_name'] : 'Musikk' ?></title>
    <link rel="stylesheet" href="<?= base_url('assets/css/main.css') ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="container">
        <?php $this->load->view('partials/sidebar'); ?>
        <main class="main-content album-page">
            <?php $this->load->view('partials/header'); ?>

            <section class="page-title-section">
                <h1 class="page-title"><?= htmlspecialchars($album->title) ?></h1>
                <p class="page-subtitle"><?= htmlspecialchars($album->artist_name) ?></p>
            </section>

            <section class="album-detail-section">
                <div class="album-detail-header">
                    <div class="album-cover-large">
                        <?php if (!empty($album->cover_image)): ?>
                            <img src="<?= base_url('assets/images/albums/' . $album->cover_image) ?>" alt="<?= htmlspecialchars($album->title) ?>" onerror="this.src='https://ui-avatars.com/api/?name=<?= urlencode($album->title) ?>&size=300&background=random'">
                        <?php else: ?>
                            <img src="https://ui-avatars.com/api/?name=<?= urlencode($album->title) ?>&size=300&background=random" alt="<?= htmlspecialchars($album->title) ?>">
                        <?php endif; ?>
                    </div>
                    <div class="album-meta">
                        <h2><?= htmlspecialchars($album->title) ?></h2>
                        <p><?= htmlspecialchars($album->artist_name) ?><?php if(!empty($album->release_year)): ?> • <?= $album->release_year ?><?php endif; ?></p>
                        <p><?= count($songs) ?> tracks</p>
                    </div>
                </div>

                <div class="songs-list">
                    <?php $i=1; foreach($songs as $s): ?>
                    <div class="song-item" data-music-id="<?= $s->music_id ?>" onclick="playMusic(<?= htmlspecialchars(json_encode($s)) ?>)">
                        <div class="song-number"><?= $i ?></div>
                        <div class="song-cover">
                            <?php if (!empty($s->cover_image)): ?>
                                <img src="<?= base_url('assets/images/albums/' . $s->cover_image) ?>" alt="<?= htmlspecialchars($s->title) ?>" onerror="this.src='https://ui-avatars.com/api/?name=<?= urlencode($s->title) ?>&size=100&background=random'">
                            <?php else: ?>
                                <img src="https://ui-avatars.com/api/?name=<?= urlencode($s->title) ?>&size=100&background=random" alt="<?= htmlspecialchars($s->title) ?>">
                            <?php endif; ?>
                        </div>
                        <div class="song-details">
                            <h4 class="song-title"><?= htmlspecialchars($s->title) ?></h4>
                            <p class="song-artist"><?= htmlspecialchars($s->artist) ?></p>
                        </div>
                        <div class="song-stats">
                            <i class="fas fa-play"></i>
                            <span><?= number_format($s->play_count ?? 0) ?></span>
                        </div>
                        <div class="song-duration">
                            <i class="far fa-clock"></i>
                            <span><?= is_numeric($s->duration) ? gmdate('i:s', $s->duration) : '0:00' ?></span>
                        </div>
                    </div>
                    <?php $i++; endforeach; ?>
                </div>
            </section>

        </main>
        <?php $this->load->view('partials/right_sidebar'); ?>
    </div>

    <?php $this->load->view('partials/player'); ?>
    <script src="<?= base_url('assets/js/main.js') ?>"></script>
</body>
</html>