<?php
$this->load->model('Music_model');
$songs = $this->Music_model->get_trending_songs(1);
$current_song = !empty($songs) ? $songs[0] : null;

// Treat default demo/trending entry (e.g. "Blinding Lights - The Weeknd") as no current song
$show_placeholder = false;
if ($current_song) {
    $title = strtolower(trim($current_song->title ?? ''));
    $artist = strtolower(trim($current_song->artist_name ?? $current_song->artist ?? ''));
    if ($title === 'blinding lights' && strpos($artist, 'weeknd') !== false) {
        $current_song = null;
        $show_placeholder = true;
    }
}
?>
<div class="music-player" id="musicPlayer">
    <div class="player-left">
        <div class="now-playing-cover">
            <?php if ($current_song): ?>
                <img id="playerCover" src="<?= base_url('assets/images/albums/' . $current_song->cover_image) ?>" alt="<?= $current_song->title ?>" onerror="this.src='https://ui-avatars.com/api/?name=<?= urlencode($current_song->title) ?>&size=100&background=random'">
            <?php else: ?>
                <img id="playerCover" src="https://ui-avatars.com/api/?name=Belum+ada+pemutaran+musik&size=100&background=random" alt="No music">
            <?php endif; ?>
        </div>
        <div class="now-playing-info">
            <h4 id="playerTitle"><?= $current_song ? $current_song->title : 'Belum ada pemutaran musik' ?></h4>
            <p id="playerArtist"><?= $current_song ? ($current_song->artist_name ?? $current_song->artist) : '' ?></p>
        </div>
        <button class="btn-player-like favorite-btn" id="playerLikeBtn" onclick="togglePlayerFavorite()">
            <i class="far fa-heart"></i>
        </button>
    </div>

    <div class="player-center">
        <div class="player-controls">
            <button class="control-btn" id="shuffleBtn" onclick="console.log('[Player-btn] shuffle clicked'); toggleShuffle();" title="Shuffle">
                <i class="fas fa-random"></i>
            </button>
            <button class="control-btn" id="prevBtn" onclick="console.log('[Player-btn] prev clicked'); previousTrack();" title="Previous">
                <i class="fas fa-step-backward"></i>
            </button>
            <button class="control-btn control-play" id="playPauseBtn" onclick="console.log('[Player-btn] playPause clicked'); togglePlayPause();" title="Play/Pause">
                <i class="fas fa-play"></i>
            </button>
            <button class="control-btn" id="nextBtn" onclick="console.log('[Player-btn] next clicked'); nextTrack();" title="Next">
                <i class="fas fa-step-forward"></i>
            </button>
            <button class="control-btn" id="repeatBtn" onclick="console.log('[Player-btn] repeat clicked'); toggleRepeat();" title="Repeat">
                <i class="fas fa-redo"></i>
            </button>
        </div>
        <div class="player-progress">
            <span class="time-current" id="currentTime">0:00</span>
            <div class="progress-bar" id="progressBar" onclick="seekTrack(event)">
                <div class="progress-fill" id="progressFill" style="width: 0%">
                    <div class="progress-handle"></div>
                </div>
            </div>
            <span class="time-total" id="totalTime">0:00</span>
        </div>
    </div>

    <div class="player-right">
        <button class="control-btn" id="volumeBtn" onclick="toggleMute()" title="Mute/Unmute">
            <i class="fas fa-volume-up"></i>
        </button>
        <div class="volume-bar" id="volumeBar" onclick="setVolume(event)">
            <div class="volume-fill" id="volumeFill" style="width: 70%">
                <div class="volume-handle"></div>
            </div>
        </div>
        <button class="control-btn" id="queueBtn" onclick="toggleQueue()" title="Show Queue">
            <i class="fas fa-list"></i>
        </button>
    </div>

    <!-- Queue Panel -->
    <div class="queue-panel" id="queuePanel">
        <div class="queue-header">
            <h3><i class="fas fa-list-music"></i> Queue</h3>
            <button class="close-queue" onclick="toggleQueue()">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <div class="queue-content" id="queueContent">
            <p class="queue-empty">No songs in queue</p>
        </div>
    </div>
</div>

<!-- Hidden Audio Element -->
<audio id="audioPlayer" style="display: none;"></audio>

<script>
// Player State
const playerState = {
    currentSong: <?= json_encode($current_song) ?>,
    queue: [],
    currentIndex: 0,
    isPlaying: false,
    isShuffle: false,
    repeatMode: 0, // 0: off, 1: repeat all, 2: repeat one
    volume: 0.7,
    isMuted: false,
    duration: 0,
    currentTime: 0
};

// Expose base url for client scripts
try { window.appBaseUrl = '<?= base_url() ?>'; } catch (e) { window.appBaseUrl = '/'; }

// Prevent rapid double-toggle from causing immediate re-toggle (inline onclick + bound handler)
let _player_lastToggleAt = 0;
const _player_toggleDebounceMs = 300;
// Guard to ignore concurrent toggle processing
let _player_processingToggle = false;
// Navigation debounce to prevent double-next/prev clicks
let _player_lastNavAt = 0;
const _player_navDebounceMs = 300;

// Audio Element
    // Helper to always get the current audio element (handles PJAX / DOM replacements)
    function getAudio() {
        return document.getElementById('audioPlayer');
    }

    // Initialize player (safe: ensure runs whether script loads before/after DOMContentLoaded)
    function initPlayer() {
        console.log('[Player] initPlayer - initializing player');
        updatePlayerUI();

        const audio = getAudio();
        if (!audio) {
            console.warn('[Player] audio element not found during init');
            return;
        }

        // Ensure volume is set
        audio.volume = playerState.volume;

        // Remove existing listeners to avoid duplicates (if element was re-used)
        try {
            audio.removeEventListener('loadedmetadata', onAudioLoaded);
            audio.removeEventListener('timeupdate', onTimeUpdate);
            audio.removeEventListener('ended', onTrackEnded);
        } catch (e) { /* ignore */ }

        // Audio event listeners
        audio.addEventListener('loadedmetadata', onAudioLoaded);
        audio.addEventListener('timeupdate', onTimeUpdate);
        audio.addEventListener('ended', onTrackEnded);
        audio.addEventListener('play', () => { playerState.isPlaying = true; updatePlayButton(); });
        audio.addEventListener('pause', () => { playerState.isPlaying = false; updatePlayButton(); });

        // Load sample queue
        loadQueue();

        // Re-export globals (ensure they reference latest functions)
        try {
            window.getAudio = getAudio;
            window.togglePlayPause = togglePlayPause;
            window.previousTrack = previousTrack;
            window.nextTrack = nextTrack;
            window.toggleShuffle = toggleShuffle;
            window.toggleRepeat = toggleRepeat;
            window.playSong = window.playSong || function(songData) { console.warn('playSong not set yet'); };
        } catch (e) { console.warn('Failed to export player controls', e); }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initPlayer);
    } else {
        initPlayer();
    }

    // Ensure re-init after PJAX loads (main.js dispatches 'pjax:loaded')
    window.addEventListener('pjax:loaded', function() {
        setTimeout(initPlayer, 10);
    });

// (duplicate initPlayer removed)

// Toggle Play/Pause
function togglePlayPause() {
    console.log('[Player] togglePlayPause called - isPlaying:', playerState.isPlaying);
    const audio = getAudio();
    if (!audio) { console.warn('togglePlayPause: audio element missing'); return; }
    // Guard: ignore re-entrant calls while a toggle is processing
    if (_player_processingToggle) {
        console.debug('[Player] togglePlayPause ignored - processing in progress');
        return;
    }

    _player_processingToggle = true;
    try {
        // If currently playing -> pause synchronously
        if (!audio.paused) {
            audio.pause();
            playerState.isPlaying = false;
            updatePlayButton();
            // release lock shortly after
            setTimeout(() => { _player_processingToggle = false; }, 150);
            return;
        }

        // Try to play and handle Promise result (autoplay may reject)
        const now = Date.now();
        if (now - _player_lastToggleAt < _player_toggleDebounceMs) {
            console.debug('[Player] togglePlayPause ignored due to rapid double-call');
            _player_processingToggle = false;
            return;
        }
        _player_lastToggleAt = now;

        const p = audio.play();
        if (p && typeof p.then === 'function') {
            p.then(() => {
                console.log('[Player] audio.play() succeeded');
                playerState.isPlaying = !audio.paused;
                updatePlayButton();
                _player_processingToggle = false;
            }).catch(err => {
                console.error('[Player] audio.play() failed:', err);
                playerState.isPlaying = !audio.paused;
                updatePlayButton();
                _player_processingToggle = false;
                alert('Unable to start playback. Silakan klik tombol Play lagi untuk mencoba.');
            });
        } else {
            // no Promise returned
            playerState.isPlaying = !audio.paused;
            updatePlayButton();
            _player_processingToggle = false;
        }
    } catch (err) {
        console.error('[Player] togglePlayPause error', err);
        playerState.isPlaying = !audio.paused;
        updatePlayButton();
        _player_processingToggle = false;
    }
}

// Update Play Button
function updatePlayButton() {
    const icon = document.querySelector('#playPauseBtn i');
    if (playerState.isPlaying) {
        icon.className = 'fas fa-pause';
    } else {
        icon.className = 'fas fa-play';
    }
}

// Previous Track
function previousTrack() {
    const nowNav = Date.now();
    if (nowNav - _player_lastNavAt < _player_navDebounceMs) {
        console.debug('[Player] previousTrack ignored due to nav debounce');
        return;
    }
    _player_lastNavAt = nowNav;

    console.log('[Player] previousTrack called - currentIndex:', playerState.currentIndex, 'queueLength:', playerState.queue.length);
    console.debug('[Player] previousTrack - queue ids:', playerState.queue.map(s=>s.id));
    if (playerState.currentIndex > 0) {
        playerState.currentIndex--;
        console.debug('[Player] previousTrack - new currentIndex:', playerState.currentIndex);
        loadTrack(playerState.queue[playerState.currentIndex]);
    } else {
        console.debug('[Player] previousTrack - at start of queue, cannot move previous');
    }
}

// Next Track
function nextTrack() {
    const nowNav = Date.now();
    if (nowNav - _player_lastNavAt < _player_navDebounceMs) {
        console.debug('[Player] nextTrack ignored due to nav debounce');
        return;
    }
    _player_lastNavAt = nowNav;

    console.log('[Player] nextTrack called - currentIndex:', playerState.currentIndex, 'queueLength:', playerState.queue.length);
    console.debug('[Player] nextTrack - queue ids:', playerState.queue.map(s=>s.id));
    if (playerState.isShuffle) {
        // Random next track
        const randomIndex = Math.floor(Math.random() * playerState.queue.length);
        playerState.currentIndex = randomIndex;
    } else {
        // Sequential next
        if (playerState.currentIndex < playerState.queue.length - 1) {
            playerState.currentIndex++;
        } else if (playerState.repeatMode === 1) {
            playerState.currentIndex = 0; // Loop back to start
        } else {
            console.debug('[Player] nextTrack - at end of queue, no next track');
            return; // End of queue
        }
    }
    console.debug('[Player] nextTrack - new currentIndex:', playerState.currentIndex);
    
    loadTrack(playerState.queue[playerState.currentIndex]);
}

// Toggle Shuffle
function toggleShuffle() {
    console.log('[Player] toggleShuffle called - before:', playerState.isShuffle);
    playerState.isShuffle = !playerState.isShuffle;
    const btn = document.getElementById('shuffleBtn');
    if (playerState.isShuffle) {
        btn.classList.add('active');
        btn.style.color = 'var(--accent-green)';
    } else {
        btn.classList.remove('active');
        btn.style.color = '';
    }
}

// Toggle Repeat
function toggleRepeat() {
    console.log('[Player] toggleRepeat called - before:', playerState.repeatMode);
    playerState.repeatMode = (playerState.repeatMode + 1) % 3;
    const btn = document.getElementById('repeatBtn');
    const icon = btn.querySelector('i');
    
    if (playerState.repeatMode === 0) {
        btn.style.color = '';
        icon.className = 'fas fa-redo';
    } else if (playerState.repeatMode === 1) {
        btn.style.color = 'var(--accent-green)';
        icon.className = 'fas fa-redo';
    } else {
        btn.style.color = 'var(--accent-green)';
        icon.className = 'fas fa-redo-alt';
        btn.title = 'Repeat One';
    }
}

// Seek Track
function seekTrack(event) {
    const audio = getAudio();
    if (!audio) return;
    const bar = document.getElementById('progressBar');
    const rect = bar.getBoundingClientRect();
    const percent = (event.clientX - rect.left) / rect.width;
    const newTime = percent * audio.duration;
    
    if (!isNaN(newTime)) {
        audio.currentTime = newTime;
    }
}

// Toggle Mute
function toggleMute() {
    playerState.isMuted = !playerState.isMuted;
    const audio = getAudio();
    if (audio) audio.muted = playerState.isMuted;
    
    const icon = document.querySelector('#volumeBtn i');
    if (playerState.isMuted) {
        icon.className = 'fas fa-volume-mute';
    } else {
        if (playerState.volume > 0.5) {
            icon.className = 'fas fa-volume-up';
        } else if (playerState.volume > 0) {
            icon.className = 'fas fa-volume-down';
        } else {
            icon.className = 'fas fa-volume-mute';
        }
    }
}

// Set Volume
function setVolume(event) {
    const bar = document.getElementById('volumeBar');
    const rect = bar.getBoundingClientRect();
    const percent = Math.max(0, Math.min(1, (event.clientX - rect.left) / rect.width));
    
    playerState.volume = percent;
    const audio = getAudio();
    if (audio) audio.volume = percent;
    playerState.isMuted = false;
    if (audio) audio.muted = false;
    
    document.getElementById('volumeFill').style.width = (percent * 100) + '%';
    
    // Update volume icon
    const icon = document.querySelector('#volumeBtn i');
    if (percent > 0.5) {
        icon.className = 'fas fa-volume-up';
    } else if (percent > 0) {
        icon.className = 'fas fa-volume-down';
    } else {
        icon.className = 'fas fa-volume-mute';
    }
}

// Toggle Queue
function toggleQueue() {
    const panel = document.getElementById('queuePanel');
    panel.classList.toggle('active');
}

// Audio Loaded
function onAudioLoaded() {
    const audio = getAudio();
    if (!audio) return;
    playerState.duration = audio.duration;
    document.getElementById('totalTime').textContent = formatTime(audio.duration);
}

// Time Update
function onTimeUpdate() {
    const audio = getAudio();
    if (!audio) return;
    playerState.currentTime = audio.currentTime;
    const percent = (audio.currentTime / audio.duration) * 100;
    
    document.getElementById('progressFill').style.width = percent + '%';
    document.getElementById('currentTime').textContent = formatTime(audio.currentTime);
    
    // Track play for history (send to server after 30 seconds)
    if (audio.currentTime > 30 && !playerState.tracked) {
        playerState.tracked = true;
        if (playerState.currentSong && playerState.currentSong.id) {
            trackPlay(playerState.currentSong.id, Math.floor(audio.currentTime));
        }
    }
}

// Track Ended
function onTrackEnded() {
    const audio = getAudio();
    if (!audio) return;
    console.debug('[Player] onTrackEnded - currentIndex:', playerState.currentIndex, 'queueLength:', playerState.queue.length);
    if (playerState.repeatMode === 2) {
        // Repeat one
        audio.currentTime = 0;
        audio.play();
    } else {
        // Next track
        nextTrack();
    }
}

// Load Track
function loadTrack(song) {
    console.log('loadTrack called with:', song);
    playerState.currentSong = song;
    playerState.tracked = false;
    console.debug('[Player] loadTrack: queueLength before update=', playerState.queue.length, 'currentIndex=', playerState.currentIndex);
    
    // Update UI
    document.getElementById('playerTitle').textContent = song.title;
    document.getElementById('playerArtist').textContent = song.artist_name || song.artist;
    
    // Handle cover image
    const coverUrl = song.cover_image 
        ? '<?= base_url("assets/images/albums/") ?>' + song.cover_image
        : song.cover_url || 'https://ui-avatars.com/api/?name=' + encodeURIComponent(song.title);
    document.getElementById('playerCover').src = coverUrl;
    
    // Load audio file with existence check and fallback
    if (song.audio_file || song.file_path) {
        const audioSrc = song.audio_file || song.file_path;
        console.log('Audio source:', audioSrc);

        // Normalize to absolute URL
        let finalUrl = '';
        if (audioSrc.startsWith('http://') || audioSrc.startsWith('https://')) {
            finalUrl = audioSrc;
        } else {
            const cleanPath = audioSrc.replace(/^\/+/, '');
            finalUrl = '<?= base_url() ?>' + cleanPath;
        }

        console.log('Checking audio URL availability:', finalUrl);

        // Assign source immediately so play() can run inside user gesture; check HEAD in background
        const audioEl = getAudio();
        if (!audioEl) {
            console.warn('loadTrack: audio element not found');
            return;
        }
        audioEl.src = finalUrl;
        console.log('Assigned audio.src (optimistic):', audioEl.src);
        audioEl.load();

        // Try to play (may be allowed if this call is part of a user gesture)
        try {
            const p = audioEl.play();
            if (p && typeof p.then === 'function') {
                p.then(() => console.log('audio.play() succeeded (optimistic)')).catch(err => {
                    console.warn('audio.play() rejected (optimistic):', err);
                });
            }
        } catch (err) {
            console.warn('audio.play() optimistic attempt threw:', err);
        }

        // Background HEAD check to fallback if file missing
        fetch(finalUrl, { method: 'HEAD' })
            .then(response => {
                if (response.ok) {
                    console.log('HEAD OK for', finalUrl);
                } else {
                    console.warn('HEAD failed; falling back to demo audio');
                    if (audioEl.src === finalUrl) {
                        audioEl.src = 'https://www.learningcontainer.com/wp-content/uploads/2020/02/Kalimba.mp3';
                        audioEl.load();
                    }
                }
            }).catch(err => console.warn('HEAD check error', err));
    } else {
        console.warn('No audio file available for:', song.title);
        alert('Audio file not available for this track.');
    }
    
    updateQueueUI();
}

// Update Player UI
function updatePlayerUI() {
    // If no current song, show placeholder and disable play
    if (!playerState.currentSong) {
        const titleEl = document.getElementById('playerTitle');
        const artistEl = document.getElementById('playerArtist');
        const coverEl = document.getElementById('playerCover');
        const playBtn = document.getElementById('playPauseBtn');
        const icon = document.querySelector('#playPauseBtn i');
        if (titleEl) titleEl.textContent = 'Belum ada pemutaran musik';
        if (artistEl) artistEl.textContent = '';
        if (coverEl) coverEl.src = 'https://ui-avatars.com/api/?name=Belum+ada+pemutaran+musik&size=100&background=random';
        if (playBtn) playBtn.disabled = true;
        if (icon) icon.className = 'fas fa-play';
        return;
    }

    // Ensure play button enabled when we have a song
    const playBtn = document.getElementById('playPauseBtn');
    if (playBtn) playBtn.disabled = false;

    // Initialize UI with current song
    updatePlayButton();
}

// Load Queue (Sample Data)
function loadQueue() {
    // In production, this would load from server
    // If queue already populated (e.g. from pageSongList), don't overwrite it.
    if (!Array.isArray(playerState.queue) || playerState.queue.length === 0) {
        playerState.queue = [];
        if (playerState.currentSong) {
            playerState.queue.push(playerState.currentSong);
        }
    } else {
        console.debug('[Player] loadQueue: queue already populated, length=', playerState.queue.length);
    }
    updateQueueUI();
}

// Update Queue UI
function updateQueueUI() {
    const container = document.getElementById('queueContent');
    
    if (playerState.queue.length === 0) {
        container.innerHTML = '<p class="queue-empty">No songs in queue</p>';
        return;
    }
    
    container.innerHTML = playerState.queue.map((song, index) => `
        <div class="queue-item ${index === playerState.currentIndex ? 'active' : ''}" onclick="playFromQueue(${index})">
            <span class="queue-number">${index + 1}</span>
            <div class="queue-song-info">
                <div class="queue-song-title">${song.title}</div>
                <div class="queue-song-artist">${song.artist_name}</div>
            </div>
            <span class="queue-duration">${formatTime(song.duration || 0)}</span>
        </div>
    `).join('');
}

// Play from Queue
function playFromQueue(index) {
    playerState.currentIndex = index;
    loadTrack(playerState.queue[index]);
}

// Format Time
function formatTime(seconds) {
    if (isNaN(seconds)) return '0:00';
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return mins + ':' + (secs < 10 ? '0' : '') + secs;
}

// Toggle Player Favorite
function togglePlayerFavorite() {
    const btn = document.getElementById('playerLikeBtn');
    const icon = btn.querySelector('i');

    <?php if($this->session->userdata('logged_in')): ?>
    fetch('<?= base_url('profile/toggle_favorite') ?>', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'item_id=' + playerState.currentSong.id + '&type=song'
    })
    .then(res => res.json())
    .then(data => {
        if (data && data.success) {
            if (data.is_favorited) {
                icon.className = 'fas fa-heart';
                btn.classList.add('favorited');
                document.dispatchEvent(new CustomEvent('favorites:added', { detail: { id: playerState.currentSong.id }}));
            } else {
                icon.className = 'far fa-heart';
                btn.classList.remove('favorited');
                document.dispatchEvent(new CustomEvent('favorites:removed', { detail: { id: playerState.currentSong.id }}));
            }
        }
    })
    .catch(e => { console.warn('player favorite failed', e); });
    <?php else: ?>
    alert('Please login to add favorites');
    <?php endif; ?>
}

// Track Play
function trackPlay(songId, duration) {
    <?php if($this->session->userdata('logged_in')): ?>
    fetch('<?= base_url('profile/track_play') ?>', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'song_id=' + songId + '&duration_played=' + duration
    });
    <?php endif; ?>
}

// Add to queue (global function)
function addToQueue(song) {
    playerState.queue.push(song);
    updateQueueUI();
}

// Play song directly (global function)
window.playSong = function(songData) {
    console.log('playSong called with:', songData);
    
    // Normalize songData to support multiple data shapes (songs table, music table, playlist objects)
    if (!songData || typeof songData !== 'object') {
        console.error('Invalid song data:', songData);
        alert('Invalid song data');
        return;
    }

    // Normalize ID field (some records use music_id, song_id, or id)
    if (!songData.id) {
        if (songData.music_id) songData.id = songData.music_id;
        else if (songData.song_id) songData.id = songData.song_id;
    }

    // Normalize audio file path (some records use file_path or audio_file)
    if (!songData.audio_file) {
        if (songData.file_path) songData.audio_file = songData.file_path;
    }

    // Normalize artist name
    if (!songData.artist_name) {
        if (songData.artist) songData.artist_name = songData.artist;
    }

    // Provide a minimal title fallback
    if (!songData.title && songData.name) songData.title = songData.name;
    
    // If a page-level song list exists, use it as the queue and set index accordingly
    if (Array.isArray(window.pageSongList) && window.pageSongList.length > 0) {
        console.debug('[Player] playSong: using pageSongList length=', window.pageSongList.length);
        // Ensure pageSongList entries are normalized similarly
        playerState.queue = window.pageSongList.map(s => {
            if (!s.id) s.id = s.music_id || s.song_id || s.id;
            if (!s.audio_file) s.audio_file = s.file_path || s.audio_file;
            if (!s.artist_name) s.artist_name = s.artist || s.artist_name;
            return s;
        });
        const idx = playerState.queue.findIndex(s => Number(s.id) === Number(songData.id));
        playerState.currentIndex = idx >= 0 ? idx : 0;
        console.debug('[Player] playSong: set currentIndex=', playerState.currentIndex, 'queueLength=', playerState.queue.length);
        loadTrack(playerState.queue[playerState.currentIndex]);
        return;
    }

    // Add to queue if not already there
    const existingIndex = playerState.queue.findIndex(s => String(s.id) === String(songData.id));
    
    if (existingIndex === -1) {
        playerState.queue.push(songData);
        playerState.currentIndex = playerState.queue.length - 1;
    } else {
        playerState.currentIndex = existingIndex;
    }
    
    console.debug('[Player] playSong: fallback queueLength=', playerState.queue.length, 'currentIndex=', playerState.currentIndex);
    loadTrack(songData);
};

// Expose addToQueue globally
window.addToQueue = addToQueue;

// Expose player controls and audio element to global scope for external handlers
try {
    window.audioPlayer = getAudio;
    window.togglePlayPause = togglePlayPause;
    window.previousTrack = previousTrack;
    window.nextTrack = nextTrack;
    window.toggleShuffle = toggleShuffle;
    window.toggleRepeat = toggleRepeat;
    console.debug('[Player] exported controls to window');
} catch (e) {
    console.warn('Failed to export player controls', e);
}

// Backwards-compatible wrapper: some templates call `playMusic(...)`.
// Keep it as a thin proxy to the canonical `playSong` function.
try {
    if (typeof window.playMusic === 'undefined') {
        window.playMusic = function(songData) {
            if (typeof window.playSong === 'function') {
                return window.playSong(songData);
            }
            console.warn('playMusic called but playSong is not available', songData);
        };
    }
} catch (e) { console.warn('Failed to install playMusic wrapper', e); }
</script>
