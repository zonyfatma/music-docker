<aside class="sidebar">
    <div class="logo">
        <div class="logo-icon">
            <i class="fas fa-music"></i>
        </div>
        <span class="logo-text">BeatBay<small>.com</small></span>
    </div>

    <nav class="main-nav">
        <a href="<?= base_url() ?>" class="nav-item <?= $this->uri->segment(1) == '' ? 'active' : '' ?>">
            <i class="fas fa-home"></i>
            <span>Home</span>
        </a>
        <a href="<?= base_url('music') ?>" class="nav-item <?= $this->uri->segment(1) == 'music' ? 'active' : '' ?>">
            <i class="fas fa-music"></i>
            <span>Browse Music</span>
        </a>
        <a href="<?= base_url('discover') ?>" class="nav-item <?= $this->uri->segment(1) == 'discover' ? 'active' : '' ?>">
            <i class="fas fa-compass"></i>
            <span>Discover</span>
        </a>
        <a href="<?= base_url('radio') ?>" class="nav-item <?= $this->uri->segment(1) == 'radio' ? 'active' : '' ?>">
            <i class="fas fa-radio"></i>
            <span>Radio</span>
        </a>
        <a href="<?= base_url('albums') ?>" class="nav-item <?= $this->uri->segment(1) == 'albums' ? 'active' : '' ?>">
            <i class="fas fa-compact-disc"></i>
            <span>Albums</span>
        </a>
        <a href="<?= base_url('podcast') ?>" class="nav-item <?= $this->uri->segment(1) == 'podcast' ? 'active' : '' ?>">
            <i class="fas fa-podcast"></i>
            <span>Podcast</span>
        </a>
    </nav>

    <div class="library-section">
        <h3>LIBRARY</h3>
        <a href="#" class="nav-item">
            <i class="fas fa-clock"></i>
            <span>Recently Added</span>
        </a>
        <a id="sidebar-favorites-link" href="<?= base_url('profile#favorites') ?>" class="nav-item <?= $this->uri->segment(1) == 'profile' ? 'active' : '' ?>">
            <i class="fas fa-heart"></i>
            <span>Favorite Songs</span>
        </a>
        <a href="#" class="nav-item">
            <i class="fas fa-folder"></i>
            <span>Local Files</span>
        </a>
    </div>

    <div class="playlist-section">
        <div class="playlist-header">
            <h3>PLAYLIST</h3>
            <button class="add-playlist"><i class="fas fa-plus"></i></button>
        </div>
        <a href="#" class="nav-item">
            <i class="fas fa-music"></i>
            <span>Lo-fi Music</span>
        </a>
        <a href="#" class="nav-item">
            <i class="fas fa-music"></i>
            <span>Best of Bon Jovi</span>
        </a>
        <a href="#" class="nav-item">
            <i class="fas fa-music"></i>
            <span>Best of John Mayer</span>
        </a>
    </div>
</aside>
