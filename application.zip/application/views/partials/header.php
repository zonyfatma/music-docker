<header class="header">
    <button class="back-btn" onclick="window.history.back()">
        <i class="fas fa-chevron-left"></i>
    </button>
    
    <div class="breadcrumb">
        <a href="<?= base_url() ?>">Home</a>
        <?php if($this->uri->segment(1)): ?>
        <i class="fas fa-chevron-right"></i>
        <span><?= ucfirst($this->uri->segment(1)) ?></span>
        <?php endif; ?>
    </div>

    <div class="search-bar">
        <i class="fas fa-search"></i>
        <input type="text" placeholder="Search music, artist, albums..." id="globalSearchInput">
    </div>

    <div class="header-actions">
        <?php if($this->session->userdata('logged_in')): ?>
            <button class="notification-btn">
                <i class="fas fa-bell"></i>
            </button>
            <div class="user-profile" id="userProfileDropdown">
                <?php
                $user_name = $this->session->userdata('full_name') ?? $this->session->userdata('username') ?? 'User';
                $avatar_url = $this->session->userdata('avatar') ?? 'https://ui-avatars.com/api/?name=' . urlencode($user_name) . '&background=1ed760&color=fff';
                ?>
                <img src="<?= $avatar_url ?>" alt="<?= $user_name ?>" onerror="this.src='https://ui-avatars.com/api/?name=<?= urlencode($user_name) ?>&background=1ed760&color=fff'">
                <div class="user-info">
                    <span class="user-name"><?= $user_name ?></span>
                    <span class="user-status">
                        <?php if($this->session->userdata('is_premium')): ?>
                            Premium <i class="fas fa-crown"></i>
                        <?php else: ?>
                            Free
                        <?php endif; ?>
                    </span>
                </div>
                <i class="fas fa-chevron-down"></i>
                
                <!-- User Dropdown Menu -->
                <div class="user-dropdown" id="userDropdownMenu">
                    <a href="<?= base_url('profile') ?>">
                        <i class="fas fa-user"></i> My Profile
                    </a>
                    <a href="<?= base_url('profile') ?>">
                        <i class="fas fa-list-music"></i> My Playlists
                    </a>
                    <a href="<?= base_url('profile') ?>">
                        <i class="fas fa-heart"></i> Favorites
                    </a>
                    <a href="<?= base_url('profile') ?>">
                        <i class="fas fa-history"></i> Listening History
                    </a>
                    <?php if(!$this->session->userdata('is_premium')): ?>
                    <a href="#" onclick="alert('Upgrade to Premium coming soon!')">
                        <i class="fas fa-crown"></i> Upgrade to Premium
                    </a>
                    <?php endif; ?>
                    <div class="dropdown-divider"></div>
                    <a href="<?= base_url('auth/logout') ?>" class="logout-link">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </div>
            </div>
        <?php else: ?>
            <a href="<?= base_url('auth/login') ?>" class="btn-login-header">
                <i class="fas fa-sign-in-alt"></i> Login
            </a>
            <a href="<?= base_url('auth/register') ?>" class="btn-signup-header">
                <i class="fas fa-user-plus"></i> Sign Up
            </a>
        <?php endif; ?>
    </div>
</header>

<script>
// User dropdown toggle
document.addEventListener('DOMContentLoaded', function() {
    const userProfile = document.getElementById('userProfileDropdown');
    const dropdown = document.getElementById('userDropdownMenu');
    
    if (userProfile && dropdown) {
        userProfile.addEventListener('click', function(e) {
            e.stopPropagation();
            dropdown.classList.toggle('active');
        });
        
        // Close dropdown when clicking outside
        document.addEventListener('click', function() {
            dropdown.classList.remove('active');
        });
    }
});
</script>
