<aside class="right-sidebar">
    <!-- Fans Also Like -->
    <section class="fans-also-like">
        <div class="section-header">
            <h3>Trending Artists</h3>
            <a href="#" class="see-all">See All</a>
        </div>
        <div class="artists-carousel">
            <?php
            // Replace dummy trending artists with admin-uploaded music (popular uploads)
            $this->load->model('Music_model');
            $uploaded = $this->Music_model->get_popular_uploaded_music(4);
            if (!empty($uploaded)) {
                foreach($uploaded as $track):
            ?>
            <div class="artist-card" data-music-id="<?= $track->id ?>">
                <a href="<?= base_url('music/' . $track->id) ?>">
                    <img src="<?= base_url('assets/images/albums/' . ($track->cover_image ?: '')) ?>" alt="<?= htmlspecialchars($track->title) ?>" onerror="this.src='https://ui-avatars.com/api/?name=<?= urlencode($track->title) ?>&size=200&background=random'">
                    <div class="artist-card-info">
                        <h4><?= htmlspecialchars($track->title) ?></h4>
                        <p><?= htmlspecialchars($track->artist_name ?: $track->artist) ?></p>
                    </div>
                </a>
            </div>
            <?php
                endforeach;
            } else {
                // Fallback to similar artists if no uploaded music available
                $similar_artists = isset($similar_artists) ? $similar_artists : $this->Music_model->get_similar_artists(1, 4);
                foreach($similar_artists as $artist):
            ?>
            <div class="artist-card">
                <a href="<?= base_url('artist/' . $artist->id) ?>">
                    <img src="<?= base_url('assets/images/artists/' . $artist->image) ?>" alt="<?= $artist->name ?>" onerror="this.src='https://ui-avatars.com/api/?name=<?= urlencode($artist->name) ?>&size=200&background=random'">
                    <div class="artist-card-info">
                        <h4><?= $artist->name ?></h4>
                        <p>Artist</p>
                    </div>
                </a>
            </div>
            <?php
                endforeach;
            }
            ?>
        </div>
    </section>

    <!-- Recent Played -->
    <section class="recent-played">
        <div class="section-header">
            <h3>Recent Played</h3>
            <a href="#" class="see-all">See All</a>
        </div>
        <div class="recent-list">
            <?php
            $recent_plays_list = isset($recent_plays) ? $recent_plays : $this->Music_model->get_recent_plays(5);
            foreach($recent_plays_list as $recent):
            ?>
            <div class="recent-item" data-song-id="<?= $recent->id ?>">
                <div class="recent-cover">
                    <img src="<?= base_url('assets/images/albums/' . $recent->cover_image) ?>" alt="<?= $recent->title ?>" onerror="this.src='https://ui-avatars.com/api/?name=<?= urlencode($recent->title) ?>&size=100&background=random'">
                </div>
                <div class="recent-info">
                    <h4><?= $recent->title ?></h4>
                    <p><?= $recent->artist_name ?></p>
                </div>
                <div class="recent-time">
                    <?php 
                        $time_diff = time() - strtotime($recent->played_at);
                        if ($time_diff < 3600) {
                            echo floor($time_diff / 60) . 'min ago';
                        } else {
                            echo floor($time_diff / 3600) . 'hr ago';
                        }
                    ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </section>
</aside>
