<?php if (empty($uploaded_music)): ?>
<div class="search-uploaded-empty">No uploaded music found.</div>
<?php else: ?>
<div class="search-uploaded-list">
    <?php foreach($uploaded_music as $m): ?>
    <div class="search-uploaded-item" onclick="window.playSong && window.playSong(<?= htmlspecialchars(json_encode($m)) ?>)">
        <div class="search-uploaded-title"><?= htmlspecialchars($m->title) ?></div>
        <div class="search-uploaded-meta"><?= htmlspecialchars($m->artist) ?> &middot; <?= htmlspecialchars($m->album) ?></div>
    </div>
    <?php endforeach; ?>
</div>
<?php endif; ?>
