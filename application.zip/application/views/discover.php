<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($this->app_settings['app_name']) ? $this->app_settings['app_name'] : 'Musikk'; ?> - Discover Music</title>
    <link rel="stylesheet" href="<?= base_url('assets/css/main.css') ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        /* Inline override to ensure Discover genre result thumbnails are constrained */
        #genre-songs-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 16px; }
        .song-card { display:flex; align-items:center; gap:12px; padding:12px; background: rgba(255,255,255,0.02); border-radius:8px; }
        .song-cover-small img { width:84px; height:84px; object-fit:cover; border-radius:6px; }
        .song-info h4 { font-size:15px; margin:0 0 6px 0; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
        .song-info p { font-size:13px; color: #b3b3b3; margin:0; }
        .btn-play-small { background:#1ed760; border:none; color:#0a0e27; padding:8px 12px; border-radius:6px; cursor:pointer; }
    </style>
</head>
<body>
    <div class="container">
        <!-- Sidebar -->
        <?php $this->load->view('partials/sidebar'); ?>

        <!-- Main Content -->
        <main class="main-content">
            <!-- Header -->
            <?php $this->load->view('partials/header'); ?>

            <!-- Page Title -->
            <section class="page-title-section">
                <h1 class="page-title">Discover</h1>
                <p class="page-subtitle">Explore new music, artists, and genres</p>
            </section>

            <!-- Browse Categories -->
            <section class="browse-section">
                <div class="section-header">
                    <h2>Browse by Genre</h2>
                </div>
                <div class="categories-grid">
                    <?php foreach($categories as $category): ?>
                    <div class="category-card" data-genre="<?= htmlspecialchars($category['name'], ENT_QUOTES, 'UTF-8') ?>" style="background-color: <?= $category['color'] ?>; cursor:pointer;">
                        <h3><?= $category['name'] ?></h3>
                        <i class="fas <?= $category['icon'] ?> category-icon"></i>
                    </div>
                    <?php endforeach; ?>
                </div>
            </section>

            <!-- Genre Results (populated via AJAX) -->
            <section class="genre-results-section" style="display:none;" id="genre-results-section">
                <div class="section-header">
                    <h2 id="genre-results-title">Genre: </h2>
                    <a href="#" class="see-all" id="genre-see-all" style="display:none;">See All</a>
                </div>
                <div class="genre-songs-grid" id="genre-songs-grid">
                    <!-- Filled by JS -->
                </div>
            </section>

            <!-- New Releases -->
            <section class="new-releases-section">
                <div class="section-header">
                    <h2>New Releases</h2>
                    <a href="#" class="see-all">See All</a>
                </div>
                <div class="albums-grid">
                    <?php foreach($new_releases as $album): ?>
                    <div class="album-card">
                        <div class="album-cover">
                            <img src="<?= base_url('assets/images/albums/' . $album->cover_image) ?>" alt="<?= $album->title ?>" onerror="this.src='https://ui-avatars.com/api/?name=<?= urlencode($album->title) ?>&size=200&background=random'">
                            <button class="play-overlay">
                                <i class="fas fa-play"></i>
                            </button>
                        </div>
                        <div class="album-info">
                            <h3 class="album-title"><?= $album->title ?></h3>
                            <p class="album-meta"><?= $album->artist_name ?> • <?= $album->release_year ?></p>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </section>

            <!-- Featured Albums -->
            <section class="featured-section">
                <div class="section-header">
                    <h2>Featured Albums</h2>
                    <a href="<?= base_url('albums') ?>" class="see-all">See All</a>
                </div>
                <div class="albums-grid">
                    <?php foreach($featured_albums as $album): ?>
                    <div class="album-card">
                        <div class="album-cover">
                            <img src="<?= base_url('assets/images/albums/' . $album->cover_image) ?>" alt="<?= $album->title ?>" onerror="this.src='https://ui-avatars.com/api/?name=<?= urlencode($album->title) ?>&size=200&background=random'">
                            <button class="play-overlay">
                                <i class="fas fa-play"></i>
                            </button>
                        </div>
                        <div class="album-info">
                            <h3 class="album-title"><?= $album->title ?></h3>
                            <p class="album-meta"><?= $album->artist_name ?></p>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </section>

            <!-- Trending Now (album-style cards like Home Popular Releases) -->
            <section class="trending-section">
                <div class="section-header">
                    <h2>Trending Now</h2>
                </div>
                <div class="albums-grid">
                    <?php foreach(array_slice($trending_songs, 0, 12) as $song): ?>
                    <div class="album-card">
                        <div class="album-cover">
                            <img src="<?= base_url('assets/images/albums/' . $song->cover_image) ?>" alt="<?= $song->title ?>" onerror="this.src='https://ui-avatars.com/api/?name=<?= urlencode($song->title) ?>&size=200&background=random'">
                            <button class="play-overlay" data-music-id="<?= isset($song->music_id) ? $song->music_id : (isset($song->id) ? $song->id : '') ?>">
                                <i class="fas fa-play"></i>
                            </button>
                        </div>
                        <div class="album-info">
                            <h3 class="album-title"><?= $song->title ?></h3>
                            <p class="album-meta"><?= isset($song->artist_name) ? $song->artist_name : (isset($song->artist) ? $song->artist : '') ?><?php if(isset($song->release_year) && $song->release_year): ?> • <?= $song->release_year ?><?php endif; ?></p>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </section>

            <!-- Popular Artists -->
            <section class="artists-section">
                <div class="section-header">
                    <h2>Popular Artists</h2>
                </div>
                <div class="artists-grid-large">
                    <?php foreach($all_artists as $artist): ?>
                    <a href="<?= base_url('artist/' . $artist->id) ?>" class="artist-card-large">
                        <img src="<?= base_url('assets/images/artists/' . $artist->image) ?>" alt="<?= $artist->name ?>" onerror="this.src='https://ui-avatars.com/api/?name=<?= urlencode($artist->name) ?>&size=200&background=random'">
                        <div class="artist-card-info">
                            <h4><?= $artist->name ?></h4>
                            <p><?= number_format($artist->monthly_listeners) ?> listeners</p>
                        </div>
                    </a>
                    <?php endforeach; ?>
                </div>
            </section>

        </main>

        <!-- Right Sidebar -->
        <?php $this->load->view('partials/right_sidebar'); ?>
    </div>

    <!-- Music Player -->
    <?php $this->load->view('partials/player'); ?>

    <script src="<?= base_url('assets/js/main.js') ?>"></script>
</body>
</html>
