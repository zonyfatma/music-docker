<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($this->app_settings['app_name']) ? $this->app_settings['app_name'] : 'Musikk'; ?> - Albums</title>
    <link rel="stylesheet" href="<?= base_url('assets/css/main.css') ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
</head>
<body>
    <div class="container">
        <!-- Sidebar -->
        <?php $this->load->view('partials/sidebar'); ?>

        <!-- Main Content -->
        <main class="main-content">
            <!-- Header -->
            <?php $this->load->view('partials/header'); ?>

            <!-- Page Title -->
            <section class="page-title-section">
                <h1 class="page-title">Albums</h1>
                <p class="page-subtitle">Explore your favorite albums and discover new releases</p>
            </section>

            <!-- New Releases -->
            <section class="new-releases-section">
                <div class="section-header">
                    <h2>New Releases</h2>
                    <a href="#" class="see-all">See All</a>
                </div>
                <div class="albums-grid-large">
                    <?php foreach($new_releases as $album): ?>
                    <?php $artist_enc = rawurlencode($album->artist_name); $title_enc = rawurlencode($album->title); ?>
                    <a href="<?= base_url('albums/uploaded/' . $artist_enc . '/' . $title_enc) ?>" class="album-card-large-link">
                    <div class="album-card-large">
                        <div class="album-cover-large">
                            <img src="<?= base_url('assets/images/albums/' . $album->cover_image) ?>" alt="<?= $album->title ?>" onerror="this.src='https://ui-avatars.com/api/?name=<?= urlencode($album->title) ?>&size=300&background=random'">
                            <div class="album-overlay">
                                <button class="play-overlay-large">
                                    <i class="fas fa-play"></i>
                                </button>
                            </div>
                            <div class="new-badge">NEW</div>
                        </div>
                        <div class="album-info">
                            <h3 class="album-title"><?= $album->title ?></h3>
                            <p class="album-artist"><?= $album->artist_name ?></p>
                            <p class="album-year"><?= $album->release_year ?> • <?= $album->album_type ?></p>
                        </div>
                    </div>
                    </a>
                    <?php endforeach; ?>
                </div>
            </section>

            <!-- Popular Albums -->
            <section class="popular-albums-section">
                <div class="section-header">
                    <h2>Popular Albums</h2>
                    <a href="#" class="see-all">See All</a>
                </div>
                <div class="albums-grid">
                    <?php foreach($popular_albums as $album): ?>
                    <?php $artist_enc = rawurlencode($album->artist_name); $title_enc = rawurlencode($album->title); ?>
                    <a href="<?= base_url('albums/uploaded/' . $artist_enc . '/' . $title_enc) ?>" class="album-card-link">
                    <div class="album-card">
                        <div class="album-cover">
                            <img src="<?= base_url('assets/images/albums/' . $album->cover_image) ?>" alt="<?= $album->title ?>" onerror="this.src='https://ui-avatars.com/api/?name=<?= urlencode($album->title) ?>&size=200&background=random'">
                            <button class="play-overlay">
                                <i class="fas fa-play"></i>
                            </button>
                            <div class="trending-badge">
                                <i class="fas fa-fire"></i>
                            </div>
                        </div>
                        <div class="album-info">
                            <h3 class="album-title"><?= $album->title ?></h3>
                            <p class="album-meta"><?= $album->artist_name ?></p>
                        </div>
                    </div>
                    </a>
                    <?php endforeach; ?>
                </div>
            </section>

            <!-- 2024 Releases -->
            <?php if(!empty($albums_2024)): ?>
            <section class="year-albums-section">
                <div class="section-header">
                    <h2>2024 Releases</h2>
                    <a href="#" class="see-all">See All</a>
                </div>
                <div class="albums-grid">
                    <?php foreach($albums_2024 as $album): ?>
                    <?php $artist_enc = rawurlencode($album->artist_name); $title_enc = rawurlencode($album->title); ?>
                    <a href="<?= base_url('albums/uploaded/' . $artist_enc . '/' . $title_enc) ?>" class="album-card-link">
                    <div class="album-card">
                        <div class="album-cover">
                            <img src="<?= base_url('assets/images/albums/' . $album->cover_image) ?>" alt="<?= $album->title ?>" onerror="this.src='https://ui-avatars.com/api/?name=<?= urlencode($album->title) ?>&size=200&background=random'">
                            <button class="play-overlay">
                                <i class="fas fa-play"></i>
                            </button>
                        </div>
                        <div class="album-info">
                            <h3 class="album-title"><?= $album->title ?></h3>
                            <p class="album-meta"><?= $album->artist_name ?></p>
                        </div>
                    </div>
                    </a>
                    <?php endforeach; ?>
                </div>
            </section>
            <?php endif; ?>

            <!-- 2023 Releases -->
            <?php if(!empty($albums_2023)): ?>
            <section class="year-albums-section">
                <div class="section-header">
                    <h2>2023 Releases</h2>
                    <a href="#" class="see-all">See All</a>
                </div>
                <div class="albums-grid">
                    <?php foreach($albums_2023 as $album): ?>
                    <?php $artist_enc = rawurlencode($album->artist_name); $title_enc = rawurlencode($album->title); ?>
                    <a href="<?= base_url('albums/uploaded/' . $artist_enc . '/' . $title_enc) ?>" class="album-card-link">
                    <div class="album-card">
                        <div class="album-cover">
                            <img src="<?= base_url('assets/images/albums/' . $album->cover_image) ?>" alt="<?= $album->title ?>" onerror="this.src='https://ui-avatars.com/api/?name=<?= urlencode($album->title) ?>&size=200&background=random'">
                            <button class="play-overlay">
                                <i class="fas fa-play"></i>
                            </button>
                        </div>
                        <div class="album-info">
                            <h3 class="album-title"><?= $album->title ?></h3>
                            <p class="album-meta"><?= $album->artist_name ?></p>
                        </div>
                    </div>
                    </a>
                    <?php endforeach; ?>
                </div>
            </section>
            <?php endif; ?>

            <!-- All Albums -->
            <section class="all-albums-section">
                <div class="section-header">
                    <h2>All Albums</h2>
                    <div class="filter-options">
                        <button class="filter-btn active">All</button>
                        <button class="filter-btn">Albums</button>
                        <button class="filter-btn">Singles</button>
                        <button class="filter-btn">EPs</button>
                    </div>
                </div>
                <div class="albums-grid">
                    <?php foreach($all_albums as $album): ?>
                    <?php $artist_enc = rawurlencode($album->artist_name); $title_enc = rawurlencode($album->title); ?>
                    <a href="<?= base_url('albums/uploaded/' . $artist_enc . '/' . $title_enc) ?>" class="album-card-link">
                    <div class="album-card">
                        <div class="album-cover">
                            <img src="<?= base_url('assets/images/albums/' . $album->cover_image) ?>" alt="<?= $album->title ?>" onerror="this.src='https://ui-avatars.com/api/?name=<?= urlencode($album->title) ?>&size=200&background=random'">
                            <button class="play-overlay">
                                <i class="fas fa-play"></i>
                            </button>
                        </div>
                        <div class="album-info">
                            <h3 class="album-title"><?= $album->title ?></h3>
                            <p class="album-meta"><?= $album->artist_name ?> • <?= $album->release_year ?></p>
                        </div>
                    </div>
                    </a>
                    <?php endforeach; ?>
                </div>
            </section>

        </main>

        <!-- Right Sidebar -->
        <?php $this->load->view('partials/right_sidebar'); ?>
    </div>

    <!-- Music Player -->
    <?php $this->load->view('partials/player'); ?>

    <script src="<?= base_url('assets/js/main.js') ?>"></script>
</body>
</html>
