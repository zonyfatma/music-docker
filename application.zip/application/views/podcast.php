<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BeatBay - Podcasts</title>
    <link rel="stylesheet" href="<?= base_url('assets/css/main.css') ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
</head>
<body>
    <div class="container">
        <!-- Sidebar -->
        <?php $this->load->view('partials/sidebar'); ?>

        <!-- Main Content -->
        <main class="main-content">
            <!-- Header -->
            <?php $this->load->view('partials/header'); ?>

            <!-- Page Title -->
            <section class="page-title-section">
                <div class="podcast-hero">
                    <i class="fas fa-podcast podcast-icon-large"></i>
                    <h1 class="page-title">Podcasts</h1>
                    <p class="page-subtitle">Discover music podcasts, interviews, and industry insights</p>
                </div>
            </section>

            <!-- Browse Categories -->
            <section class="podcast-categories-section">
                <div class="section-header">
                    <h2>Browse by Category</h2>
                </div>
                <div class="podcast-categories-grid">
                    <?php foreach($categories as $category): ?>
                    <div class="podcast-category-card" style="background: linear-gradient(135deg, <?= $category['color'] ?>, <?= $category['color'] ?>dd);">
                        <i class="fas fa-microphone-alt"></i>
                        <h3><?= $category['name'] ?></h3>
                    </div>
                    <?php endforeach; ?>
                </div>
            </section>

            <!-- Featured Podcasts -->
            <section class="featured-podcasts-section">
                <div class="section-header">
                    <h2>Featured Podcasts</h2>
                    <a href="#" class="see-all">See All</a>
                </div>
                <div class="podcasts-grid">
                    <?php foreach($featured_podcasts as $podcast): ?>
                    <div class="podcast-card">
                        <div class="podcast-cover">
                            <img src="<?= base_url('assets/images/podcasts/' . $podcast['image']) ?>" alt="<?= $podcast['title'] ?>" onerror="this.src='https://ui-avatars.com/api/?name=<?= urlencode($podcast['title']) ?>&size=300&background=random'">
                            <div class="podcast-overlay">
                                <button class="btn-podcast-play">
                                    <i class="fas fa-play"></i>
                                </button>
                            </div>
                        </div>
                        <div class="podcast-info">
                            <h3 class="podcast-title"><?= $podcast['title'] ?></h3>
                            <p class="podcast-host">
                                <i class="fas fa-user-circle"></i>
                                <?= $podcast['host'] ?>
                            </p>
                            <p class="podcast-description"><?= $podcast['description'] ?></p>
                            <div class="podcast-meta">
                                <span class="episode-count">
                                    <i class="fas fa-list"></i>
                                    <?= $podcast['episodes'] ?> episodes
                                </span>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </section>

            <!-- Popular Episodes -->
            <section class="popular-episodes-section">
                <div class="section-header">
                    <h2>Popular Episodes</h2>
                </div>
                <div class="episodes-list">
                    <?php foreach($popular_episodes as $episode): ?>
                    <div class="episode-item">
                        <button class="episode-play-btn">
                            <i class="fas fa-play"></i>
                        </button>
                        <div class="episode-cover">
                            <img src="<?= base_url('assets/images/podcasts/episode-thumb.jpg') ?>" alt="Episode" onerror="this.src='https://ui-avatars.com/api/?name=Podcast&size=100&background=6B46C1'">
                        </div>
                        <div class="episode-info">
                            <h4 class="episode-title"><?= $episode['title'] ?></h4>
                            <p class="episode-podcast"><?= $episode['podcast'] ?></p>
                            <div class="episode-meta">
                                <span class="episode-date">
                                    <i class="far fa-calendar"></i>
                                    <?= date('M d, Y', strtotime($episode['date'])) ?>
                                </span>
                                <span class="episode-duration">
                                    <i class="far fa-clock"></i>
                                    <?= $episode['duration'] ?>
                                </span>
                            </div>
                        </div>
                        <button class="btn-episode-save">
                            <i class="far fa-bookmark"></i>
                        </button>
                        <button class="btn-episode-more">
                            <i class="fas fa-ellipsis-h"></i>
                        </button>
                    </div>
                    <?php endforeach; ?>
                </div>
            </section>

            <!-- Your Subscriptions -->
            <section class="subscriptions-section">
                <div class="section-header">
                    <h2>Your Subscriptions</h2>
                    <a href="#" class="see-all">Manage</a>
                </div>
                <div class="subscriptions-grid">
                    <?php foreach(array_slice($featured_podcasts, 0, 4) as $podcast): ?>
                    <div class="subscription-card">
                        <div class="subscription-cover">
                            <img src="<?= base_url('assets/images/podcasts/' . $podcast['image']) ?>" alt="<?= $podcast['title'] ?>" onerror="this.src='https://ui-avatars.com/api/?name=<?= urlencode($podcast['title']) ?>&size=200&background=random'">
                            <div class="new-episode-badge">
                                <span>3 New</span>
                            </div>
                        </div>
                        <div class="subscription-info">
                            <h4><?= $podcast['title'] ?></h4>
                            <p><?= $podcast['host'] ?></p>
                            <button class="btn-view-podcast">
                                View Podcast
                            </button>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </section>

            <!-- Recommended for You -->
            <section class="recommended-podcasts-section">
                <div class="section-header">
                    <h2>Recommended for You</h2>
                </div>
                <div class="recommended-list">
                    <?php foreach(array_slice($featured_podcasts, 2, 3) as $podcast): ?>
                    <div class="recommended-item">
                        <div class="recommended-cover">
                            <img src="<?= base_url('assets/images/podcasts/' . $podcast['image']) ?>" alt="<?= $podcast['title'] ?>" onerror="this.src='https://ui-avatars.com/api/?name=<?= urlencode($podcast['title']) ?>&size=150&background=random'">
                        </div>
                        <div class="recommended-info">
                            <h4><?= $podcast['title'] ?></h4>
                            <p class="recommended-host"><?= $podcast['host'] ?></p>
                            <p class="recommended-description"><?= $podcast['description'] ?></p>
                            <div class="recommended-stats">
                                <span><i class="fas fa-list"></i> <?= $podcast['episodes'] ?> episodes</span>
                            </div>
                        </div>
                        <button class="btn-subscribe">
                            <i class="fas fa-plus"></i>
                            Subscribe
                        </button>
                    </div>
                    <?php endforeach; ?>
                </div>
            </section>

        </main>

        <!-- Right Sidebar -->
        <?php $this->load->view('partials/right_sidebar'); ?>
    </div>

    <!-- Music Player -->
    <?php $this->load->view('partials/player'); ?>

    <script src="<?= base_url('assets/js/main.js') ?>"></script>
</body>
</html>
