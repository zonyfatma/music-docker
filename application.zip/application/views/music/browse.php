<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($this->app_settings['app_name']) ? $this->app_settings['app_name'] : 'Musikk'; ?> - Browse Music</title>
    <link rel="stylesheet" href="<?= base_url('assets/css/main.css') ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
</head>
<body>
    <div class="container">
        <!-- Sidebar -->
        <?php $this->load->view('partials/sidebar'); ?>

        <!-- Main Content -->
        <main class="main-content">
            <!-- Header -->
            <?php $this->load->view('partials/header'); ?>

            <!-- Browse Header -->
            <section class="browse-header">
                <h1 class="page-title">
                    <i class="fas fa-music"></i> Browse Music
                </h1>
                <p class="page-subtitle">Discover amazing music from our collection</p>
            </section>

            <!-- Uploaded Music Section -->
            <?php if (!empty($uploaded_music)): ?>
            <section class="music-section">
                <div class="section-header">
                    <h2><i class="fas fa-star"></i> Recently Uploaded</h2>
                </div>
                <div class="songs-list">
                    <?php $index = 1; foreach($uploaded_music as $music): ?>
                    <div class="song-item" data-music-id="<?= $music->music_id ?>" onclick="playMusic(<?= htmlspecialchars(json_encode($music)) ?>)">
                        <div class="song-number"><?= $index ?></div>
                        <div class="song-cover">
                            <?php if ($music->cover_image): ?>
                                <img src="<?= base_url('assets/images/albums/' . $music->cover_image) ?>" alt="<?= $music->title ?>" onerror="this.src='https://ui-avatars.com/api/?name=<?= urlencode($music->title) ?>&size=100&background=random'">
                            <?php else: ?>
                                <img src="https://ui-avatars.com/api/?name=<?= urlencode($music->title) ?>&size=100&background=random" alt="<?= $music->title ?>">
                            <?php endif; ?>
                        </div>
                        <div class="song-details">
                            <h4 class="song-title"><?= $music->title ?></h4>
                            <p class="song-artist"><?= $music->artist ?></p>
                        </div>
                        <?php if ($music->album): ?>
                        <div class="song-album">
                            <span><?= $music->album ?></span>
                        </div>
                        <?php endif; ?>
                        <?php if ($music->genre): ?>
                        <div class="song-genre">
                            <span class="badge"><?= $music->genre ?></span>
                        </div>
                        <?php endif; ?>
                        <div class="song-stats">
                            <i class="fas fa-play"></i>
                            <span><?= number_format($music->play_count) ?></span>
                        </div>
                        <div class="song-duration">
                            <i class="far fa-clock"></i>
                            <span><?= is_numeric($music->duration) ? gmdate('i:s', $music->duration) : '0:00' ?></span>
                        </div>
                        <div class="song-actions">
                            <button class="btn-like favorite-btn" onclick="event.stopPropagation(); toggleFavorite(<?= $music->music_id ?>, 'music', this)">
                                <i class="far fa-heart"></i>
                            </button>
                            <button class="btn-more" onclick="event.stopPropagation(); showMusicMenu(<?= $music->music_id ?>, this)">
                                <i class="fas fa-ellipsis-h"></i>
                            </button>
                        </div>
                    </div>
                    <?php $index++; endforeach; ?>
                </div>
            </section>
            <?php endif; ?>

            <!-- Popular Tracks (use uploaded music from admin) -->
            <?php if (!empty($uploaded_music)): ?>
            <section class="music-section">
                <div class="section-header">
                    <h2><i class="fas fa-fire"></i> Popular Tracks</h2>
                </div>
                <div class="songs-list">
                    <?php $index = 1; foreach($uploaded_music as $track): ?>
                    <div class="song-item" data-music-id="<?= $track->music_id ?>" onclick="playMusic(<?= htmlspecialchars(json_encode($track)) ?>)">
                        <div class="song-number"><?= $index ?></div>
                        <div class="song-cover">
                            <?php if ($track->cover_image): ?>
                                <img src="<?= base_url('assets/images/albums/' . $track->cover_image) ?>" alt="<?= $track->title ?>" onerror="this.src='https://ui-avatars.com/api/?name=<?= urlencode($track->title) ?>&size=100&background=random'">
                            <?php else: ?>
                                <img src="https://ui-avatars.com/api/?name=<?= urlencode($track->title) ?>&size=100&background=random" alt="<?= $track->title ?>">
                            <?php endif; ?>
                        </div>
                        <div class="song-details">
                            <h4 class="song-title"><?= $track->title ?></h4>
                            <p class="song-artist"><?= $track->artist ?></p>
                        </div>
                        <?php if ($track->album): ?>
                        <div class="song-album">
                            <span><?= $track->album ?></span>
                        </div>
                        <?php endif; ?>
                        <?php if ($track->genre): ?>
                        <div class="song-genre">
                            <span class="badge"><?= $track->genre ?></span>
                        </div>
                        <?php endif; ?>
                        <div class="song-stats">
                            <i class="fas fa-play"></i>
                            <span><?= number_format($track->play_count ?? $track->plays ?? 0) ?></span>
                        </div>
                        <div class="song-duration">
                            <i class="far fa-clock"></i>
                            <span><?= is_numeric($track->duration) ? gmdate('i:s', $track->duration) : '0:00' ?></span>
                        </div>
                        <div class="song-actions">
                            <button class="btn-like favorite-btn">
                                <i class="far fa-heart"></i>
                            </button>
                            <button class="btn-more">
                                <i class="fas fa-ellipsis-h"></i>
                            </button>
                        </div>
                    </div>
                    <?php $index++; endforeach; ?>
                </div>
            </section>
            <?php endif; ?>

            <!-- Trending Songs -->
            <?php if (!empty($trending_songs)): ?>
            <section class="music-section">
                <div class="section-header">
                    <h2><i class="fas fa-chart-line"></i> Trending Now</h2>
                </div>
                <div class="songs-grid">
                    <?php foreach($trending_songs as $song): ?>
                    <div class="song-card" onclick="playSong(<?= htmlspecialchars(json_encode($song)) ?>)">
                        <div class="song-card-cover">
                            <img src="<?= base_url('assets/images/albums/' . $song->cover_image) ?>" alt="<?= $song->title ?>" onerror="this.src='https://ui-avatars.com/api/?name=<?= urlencode($song->title) ?>&size=200&background=random'">
                            <button class="play-overlay">
                                <i class="fas fa-play"></i>
                            </button>
                        </div>
                        <div class="song-card-info">
                            <h4><?= $song->title ?></h4>
                            <p><?= $song->artist_name ?></p>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </section>
            <?php endif; ?>

            <?php if (empty($uploaded_music) && empty($all_music) && empty($trending_songs)): ?>
            <section class="empty-state">
                <i class="fas fa-music fa-5x"></i>
                <h2>No Music Available</h2>
                <p>Upload some music from the admin panel to get started!</p>
                <?php if ($this->session->userdata('role_id') == 1): ?>
                <a href="<?= base_url('admin_music') ?>" class="btn-primary">
                    <i class="fas fa-upload"></i> Upload Music
                </a>
                <?php endif; ?>
            </section>
            <?php endif; ?>
        </main>

        <!-- Right Sidebar -->
        <?php $this->load->view('partials/right_sidebar'); ?>
    </div>

    <!-- Music Player -->
    <?php $this->load->view('partials/player'); ?>

    <script src="<?= base_url('assets/js/main.js') ?>"></script>
    <script>
        // Play music from uploaded music table
        function playMusic(musicData) {
            const baseUrl = '<?= base_url() ?>';
            const rawPath = musicData.file_path || '';
            let absUrl = rawPath;

            if (!rawPath) {
                console.warn('No file_path for music item', musicData);
                alert('Audio file tidak tersedia untuk lagu ini.');
                return;
            }

            if (rawPath.startsWith('http://') || rawPath.startsWith('https://')) {
                absUrl = rawPath;
            } else {
                absUrl = baseUrl + rawPath.replace(/^\/+/, '');
            }

            // Check availability then play
            fetch(absUrl, { method: 'HEAD' })
                .then(res => {
                    const songData = {
                        id: musicData.music_id,
                        title: musicData.title,
                        artist: musicData.artist,
                        artist_name: musicData.artist,
                        album: musicData.album || '',
                        file_path: rawPath,
                        audio_file: absUrl,
                        cover_image: musicData.cover_image || '',
                        duration: musicData.duration || 0
                    };

                    if (res.ok) {
                        // File exists, play it
                        if (typeof window.playSong === 'function') {
                            window.playSong(songData);
                        } else {
                            console.error('Player not loaded');
                        }
                    } else {
                        // Fallback to demo audio if not found
                        console.warn('Local audio not found, using demo fallback:', absUrl);
                        songData.audio_file = 'https://www.learningcontainer.com/wp-content/uploads/2020/02/Kalimba.mp3';
                        if (typeof window.playSong === 'function') window.playSong(songData);
                    }
                })
                .catch(err => {
                    console.error('Error checking audio URL', err);
                    const songData = {
                        id: musicData.music_id,
                        title: musicData.title,
                        artist: musicData.artist,
                        artist_name: musicData.artist,
                        album: musicData.album || '',
                        file_path: rawPath,
                        audio_file: absUrl,
                        cover_image: musicData.cover_image || '',
                        duration: musicData.duration || 0
                    };
                    if (typeof window.playSong === 'function') window.playSong(songData);
                });
        }

        // Play track from combined table
        function playTrack(trackData) {
            // Normalize and delegate to playMusic behavior for consistency
            const mapped = {
                music_id: trackData.id,
                title: trackData.title,
                artist: trackData.artist,
                album: trackData.album || '',
                file_path: trackData.file_path,
                cover_image: trackData.cover_image || '',
                duration: trackData.duration || 0
            };
            playMusic(mapped);
        }

        // Toggle favorite
        function toggleFavorite(itemId, type, btn) {
            <?php if($this->session->userdata('logged_in')): ?>
            fetch('<?= base_url('profile/toggle_favorite') ?>', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'item_id=' + itemId + '&type=' + type
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const icon = btn.querySelector('i');
                    if (data.is_favorited) {
                        icon.className = 'fas fa-heart';
                        btn.classList.add('favorited');
                    } else {
                        icon.className = 'far fa-heart';
                        btn.classList.remove('favorited');
                    }
                }
            });
            <?php else: ?>
            window.location.href = '<?= base_url('auth/login') ?>';
            <?php endif; ?>
        }

        // Show music menu
        function showMusicMenu(musicId, btn) {
            <?php if($this->session->userdata('logged_in')): ?>
            alert('Music menu for ID: ' + musicId + '\nFeatures: Add to playlist, Share, Download');
            <?php else: ?>
            window.location.href = '<?= base_url('auth/login') ?>';
            <?php endif; ?>
        }
    </script>

    <style>
        .browse-header {
            padding: 40px 0 20px;
            border-bottom: 1px solid #2a2a2a;
            margin-bottom: 30px;
        }

        .page-title {
            font-size: 48px;
            font-weight: 800;
            margin-bottom: 10px;
            color: #fff;
        }

        .page-subtitle {
            font-size: 16px;
            color: #b3b3b3;
            margin: 0;
        }

        .music-section {
            margin-bottom: 50px;
        }

        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .section-header h2 {
            font-size: 24px;
            font-weight: 700;
            color: #fff;
        }

        .section-header h2 i {
            margin-right: 10px;
            color: #1db954;
        }

        .song-album,
        .song-genre {
            flex: 1;
            padding: 0 15px;
            color: #b3b3b3;
            font-size: 14px;
        }

        .song-genre .badge {
            background: #1db954;
            color: #000;
            padding: 4px 12px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
        }

        .songs-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
            gap: 20px;
        }

        .song-card {
            background: #181818;
            padding: 16px;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        /* Ensure song-card stacks cover above the info (image on top, text below) */
        .song-card {
            display: flex;
            flex-direction: column;
            align-items: flex-start;
        }

        .song-card:hover {
            background: #282828;
        }

        .song-card-cover {
            position: relative;
            width: 100%;
            padding-bottom: 100%;
            margin-bottom: 12px;
            border-radius: 4px;
            overflow: hidden;
        }

        .song-card-cover img {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .song-card-info h4 {
            font-size: 14px;
            font-weight: 600;
            color: #fff;
            margin-bottom: 4px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .song-card-info p {
            font-size: 12px;
            color: #b3b3b3;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .empty-state {
            text-align: center;
            padding: 100px 20px;
            color: #b3b3b3;
        }

        .empty-state i {
            margin-bottom: 20px;
            opacity: 0.3;
        }

        .empty-state h2 {
            color: #fff;
            margin-bottom: 10px;
        }

        .empty-state .btn-primary {
            margin-top: 20px;
            display: inline-block;
            padding: 12px 30px;
            background: #1db954;
            color: #fff;
            text-decoration: none;
            border-radius: 500px;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .empty-state .btn-primary:hover {
            background: #1ed760;
            transform: scale(1.05);
        }
    </style>
</body>
</html>
