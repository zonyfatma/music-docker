<!DOCTYPE html>
<html>
<head>
    <title>BeatBay - System Info</title>
    <style>
        body { font-family: Arial; padding: 20px; background: #f5f5f5; }
        .container { max-width: 800px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        h1 { color: #667eea; }
        .section { margin: 20px 0; padding: 15px; background: #f8f9fa; border-left: 4px solid #667eea; }
        .success { color: green; }
        .error { color: red; }
        .info { color: #666; }
        code { background: #e9ecef; padding: 2px 6px; border-radius: 3px; }
        .btn { background: #667eea; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; display: inline-block; margin: 5px; }
        .btn:hover { background: #5568d3; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🎵 BeatBay - System Information</h1>
        
        <div class="section">
            <h3>📍 Base URL</h3>
            <p><code><?php echo base_url(); ?></code></p>
        </div>

        <div class="section">
            <h3>🔧 CodeIgniter Version</h3>
            <p><code><?php echo CI_VERSION; ?></code></p>
        </div>

        <div class="section">
            <h3>🌐 PHP Version</h3>
            <p><code><?php echo phpversion(); ?></code></p>
        </div>

        <div class="section">
            <h3>📂 Environment</h3>
            <p><code><?php echo ENVIRONMENT; ?></code></p>
        </div>

        <div class="section">
            <h3>🗂️ Database Connection</h3>
            <?php
            try {
                $this->load->database();
                if ($this->db->conn_id) {
                    echo '<p class="success">✅ Database Connected</p>';
                    echo '<p class="info">Database: <code>' . $this->db->database . '</code></p>';
                } else {
                    echo '<p class="error">❌ Database Not Connected</p>';
                }
            } catch (Exception $e) {
                echo '<p class="error">❌ Error: ' . $e->getMessage() . '</p>';
            }
            ?>
        </div>

        <div class="section">
            <h3>📋 Available Routes</h3>
            <ul>
                <li>Home: <code><?php echo base_url(); ?></code></li>
                <li>Discover: <code><?php echo base_url('discover'); ?></code></li>
                <li>Radio: <code><?php echo base_url('radio'); ?></code></li>
                <li>Albums: <code><?php echo base_url('albums'); ?></code></li>
                <li>Podcast: <code><?php echo base_url('podcast'); ?></code></li>
            </ul>
        </div>

        <div class="section">
            <h3>⚙️ mod_rewrite Status</h3>
            <?php
            if (function_exists('apache_get_modules')) {
                $modules = apache_get_modules();
                if (in_array('mod_rewrite', $modules)) {
                    echo '<p class="success">✅ mod_rewrite is ENABLED</p>';
                    echo '<p class="info">You can use clean URLs without index.php</p>';
                } else {
                    echo '<p class="error">❌ mod_rewrite is DISABLED</p>';
                    echo '<p class="info">You need to use index.php in URLs</p>';
                }
            } else {
                echo '<p class="info">⚠️ Cannot detect mod_rewrite status</p>';
                echo '<p class="info">Try accessing URLs to test</p>';
            }
            ?>
        </div>

        <div class="section">
            <h3>🧪 Test Navigation</h3>
            <a href="<?php echo base_url(); ?>" class="btn">🏠 Home</a>
            <a href="<?php echo base_url('discover'); ?>" class="btn">🔍 Discover</a>
            <a href="<?php echo base_url('radio'); ?>" class="btn">📻 Radio</a>
            <a href="<?php echo base_url('albums'); ?>" class="btn">💿 Albums</a>
            <a href="<?php echo base_url('podcast'); ?>" class="btn">🎙️ Podcast</a>
            <br><br>
            <p class="info">Klik button di atas untuk test navigasi. Jika ada error 404, gunakan URL dengan index.php:</p>
            <a href="<?php echo base_url('index.php/discover'); ?>" class="btn">Discover (with index.php)</a>
        </div>

        <div class="section">
            <h3>📝 Notes</h3>
            <ul>
                <li>Jika mod_rewrite tidak aktif, gunakan URL dengan <code>index.php</code></li>
                <li>Contoh: <code>http://localhost/musikk/index.php/discover</code></li>
                <li>Baca file <strong>QUICK_START.md</strong> untuk panduan lengkap</li>
            </ul>
        </div>
    </div>
</body>
</html>
