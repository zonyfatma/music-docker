<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BeatBay - Test Navigation</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .container {
            background: white;
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            max-width: 600px;
            width: 100%;
        }
        h1 {
            color: #667eea;
            margin-bottom: 10px;
            font-size: 32px;
        }
        .subtitle {
            color: #666;
            margin-bottom: 30px;
        }
        .status {
            background: #f0f9ff;
            border-left: 4px solid #3b82f6;
            padding: 15px;
            margin-bottom: 30px;
            border-radius: 4px;
        }
        .status h3 {
            color: #3b82f6;
            margin-bottom: 10px;
        }
        .links {
            display: grid;
            gap: 15px;
        }
        .link-item {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 10px;
            text-decoration: none;
            display: flex;
            align-items: center;
            justify-content: space-between;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .link-item:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(102, 126, 234, 0.4);
        }
        .link-content {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        .icon {
            font-size: 24px;
        }
        .link-info h3 {
            font-size: 18px;
            margin-bottom: 5px;
        }
        .link-info p {
            font-size: 13px;
            opacity: 0.9;
        }
        .arrow {
            font-size: 20px;
        }
        .instructions {
            background: #fff3cd;
            border-left: 4px solid #ffc107;
            padding: 15px;
            margin-top: 30px;
            border-radius: 4px;
        }
        .instructions h3 {
            color: #856404;
            margin-bottom: 10px;
        }
        .instructions ol {
            margin-left: 20px;
            color: #856404;
        }
        .instructions li {
            margin-bottom: 8px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🎵 BeatBay Music</h1>
        <p class="subtitle">Test Navigation - Click untuk test halaman</p>
        
        <div class="status">
            <h3>✅ Status</h3>
            <p>Semua halaman sudah dibuat dan siap ditest!</p>
        </div>

        <div class="links">
            <a href="<?= base_url() ?>" class="link-item">
                <div class="link-content">
                    <span class="icon">🏠</span>
                    <div class="link-info">
                        <h3>Home</h3>
                        <p>Artist profile & popular songs</p>
                    </div>
                </div>
                <span class="arrow">→</span>
            </a>

            <a href="<?= base_url('discover') ?>" class="link-item">
                <div class="link-content">
                    <span class="icon">🔍</span>
                    <div class="link-info">
                        <h3>Discover</h3>
                        <p>Browse by genre & trending</p>
                    </div>
                </div>
                <span class="arrow">→</span>
            </a>

            <a href="<?= base_url('radio') ?>" class="link-item">
                <div class="link-content">
                    <span class="icon">📻</span>
                    <div class="link-info">
                        <h3>Radio</h3>
                        <p>Live streaming stations</p>
                    </div>
                </div>
                <span class="arrow">→</span>
            </a>

            <a href="<?= base_url('albums') ?>" class="link-item">
                <div class="link-content">
                    <span class="icon">💿</span>
                    <div class="link-info">
                        <h3>Albums</h3>
                        <p>Complete music collection</p>
                    </div>
                </div>
                <span class="arrow">→</span>
            </a>

            <a href="<?= base_url('podcast') ?>" class="link-item">
                <div class="link-content">
                    <span class="icon">🎙️</span>
                    <div class="link-info">
                        <h3>Podcast</h3>
                        <p>Music shows & interviews</p>
                    </div>
                </div>
                <span class="arrow">→</span>
            </a>
        </div>

        <div class="instructions">
            <h3>⚠️ Jika Link Tidak Berfungsi:</h3>
            <ol>
                <li>Pastikan mod_rewrite Apache sudah aktif</li>
                <li>Restart WAMP sepenuhnya</li>
                <li>Baca file SETUP_REWRITE.md untuk panduan</li>
                <li>Atau gunakan URL: http://localhost/musikk/index.php/discover</li>
            </ol>
        </div>
    </div>
</body>
</html>
