<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2"><i class="fas fa-chart-bar"></i> Laporan & Statistik</h1>
    <div class="btn-toolbar mb-2 mb-md-0">
        <div class="btn-group me-2">
            <button type="button" class="btn btn-sm btn-outline-primary export-btn" data-type="users" data-format="csv">
                <i class="fas fa-download"></i> Export Users (CSV)
            </button>
            <button type="button" class="btn btn-sm btn-outline-success export-btn" data-type="content" data-format="csv">
                <i class="fas fa-download"></i> Export Content (CSV)
            </button>
        </div>
    </div>
</div>

<!-- Summary Cards -->
<div class="row mb-4">
    <div class="col-md-3">
        <div class="card text-white bg-primary shadow">
            <div class="card-body">
                <h5>Total Pengguna</h5>
                <h2 id="total-users"><?php echo number_format($stats['total_users']); ?></h2>
                <small><?php echo $stats['new_users']; ?> pengguna baru minggu ini</small>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card text-white bg-success shadow">
            <div class="card-body">
                <h5>Total Konten</h5>
                <h2 id="total-content"><?php echo number_format($stats['total_music'] + $stats['total_podcasts']); ?></h2>
                <small><?php echo $stats['total_music']; ?> musik, <?php echo $stats['total_podcasts']; ?> podcast</small>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card text-white bg-info shadow">
            <div class="card-body">
                <h5>Total Playlist</h5>
                <h2><?php echo number_format($stats['total_playlists']); ?></h2>
                <small>Dibuat oleh pengguna</small>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card text-white bg-warning shadow">
            <div class="card-body">
                <h5>Pengguna Aktif</h5>
                <h2><?php echo number_format($stats['active_users']); ?></h2>
                <small>Aktif 30 hari terakhir</small>
            </div>
        </div>
    </div>
</div>

<!-- Charts -->
<div class="row mb-4">
    <div class="col-lg-6">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Tren Penggunaan (30 Hari)</h6>
            </div>
            <div class="card-body">
                <canvas id="usageTrendChart"></canvas>
            </div>
        </div>
    </div>
    
    <div class="col-lg-6">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-success">Pertumbuhan Pengguna (30 Hari)</h6>
            </div>
            <div class="card-body">
                <canvas id="userGrowthChart"></canvas>
            </div>
        </div>
    </div>
</div>

<!-- Export Form -->
<div class="row mb-4">
    <div class="col-lg-12">
        <div class="card shadow">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Export Laporan Kustom</h6>
            </div>
            <div class="card-body">
                <form method="get" action="<?php echo base_url('admin/export_report'); ?>" class="row g-3">
                    <div class="col-md-3">
                        <label class="form-label">Jenis Laporan</label>
                        <select name="type" class="form-select" required>
                            <option value="">Pilih Jenis...</option>
                            <option value="users">Laporan Pengguna</option>
                            <option value="content">Laporan Konten</option>
                            <option value="activity">Laporan Aktivitas</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Format</label>
                        <select name="format" class="form-select" required>
                            <option value="csv">CSV</option>
                            <option value="pdf">PDF (Segera)</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">Dari Tanggal</label>
                        <input type="date" name="date_from" id="date_from" class="form-control">
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">Sampai Tanggal</label>
                        <input type="date" name="date_to" id="date_to" class="form-control">
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">&nbsp;</label>
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="fas fa-download"></i> Export
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
// Usage Trend Chart
const usageCtx = document.getElementById('usageTrendChart');
const usageTrendData = <?php echo json_encode($usage_trend); ?>;

const usageLabels = usageTrendData.map(item => {
    const date = new Date(item.date);
    return date.toLocaleDateString('id-ID', { month: 'short', day: 'numeric' });
});

const usageData = usageTrendData.map(item => item.plays);

new Chart(usageCtx, {
    type: 'line',
    data: {
        labels: usageLabels,
        datasets: [{
            label: 'Jumlah Pemutaran',
            data: usageData,
            borderColor: 'rgb(78, 115, 223)',
            backgroundColor: 'rgba(78, 115, 223, 0.1)',
            tension: 0.4,
            fill: true
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
            legend: {
                display: true,
                position: 'top',
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                ticks: {
                    callback: function(value) {
                        return value.toLocaleString();
                    }
                }
            }
        }
    }
});

// User Growth Chart
const growthCtx = document.getElementById('userGrowthChart');
const userGrowthData = <?php echo json_encode($user_growth); ?>;

const growthLabels = userGrowthData.map(item => {
    const date = new Date(item.date);
    return date.toLocaleDateString('id-ID', { month: 'short', day: 'numeric' });
});

const growthData = userGrowthData.map(item => item.new_users);

new Chart(growthCtx, {
    type: 'bar',
    data: {
        labels: growthLabels,
        datasets: [{
            label: 'Pengguna Baru',
            data: growthData,
            backgroundColor: 'rgba(28, 200, 138, 0.8)',
            borderColor: 'rgb(28, 200, 138)',
            borderWidth: 1
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
            legend: {
                display: true,
                position: 'top',
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                ticks: {
                    stepSize: 1
                }
            }
        }
    }
});
</script>
