<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2"><i class="fas fa-history"></i> Log Aktivitas</h1>
    <div class="btn-toolbar mb-2 mb-md-0">
        <button type="button" class="btn btn-sm btn-outline-secondary" onclick="location.reload();">
            <i class="fas fa-sync-alt"></i> Refresh
        </button>
    </div>
</div>

<!-- Filters -->
<div class="card mb-4">
    <div class="card-body">
        <form method="get" action="<?php echo base_url('admin/logs'); ?>" class="row g-3">
            <div class="col-md-3">
                <label class="form-label">User ID</label>
                <input type="number" name="user_id" class="form-control" placeholder="Filter by User ID..." value="<?php echo $this->input->get('user_id'); ?>">
            </div>
            <div class="col-md-3">
                <label class="form-label">Aksi</label>
                <input type="text" name="action" class="form-control" placeholder="Cari aksi..." value="<?php echo $this->input->get('action'); ?>">
            </div>
            <div class="col-md-2">
                <label class="form-label">Dari Tanggal</label>
                <input type="date" name="date_from" class="form-control" value="<?php echo $this->input->get('date_from'); ?>">
            </div>
            <div class="col-md-2">
                <label class="form-label">Sampai Tanggal</label>
                <input type="date" name="date_to" class="form-control" value="<?php echo $this->input->get('date_to'); ?>">
            </div>
            <div class="col-md-2">
                <label class="form-label">&nbsp;</label>
                <button type="submit" class="btn btn-primary w-100">
                    <i class="fas fa-filter"></i> Filter
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Logs Table -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">
            Activity Logs (<?php echo number_format($total_logs); ?> total)
        </h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered table-hover table-sm">
                <thead>
                    <tr>
                        <th width="50">ID</th>
                        <th>Waktu</th>
                        <th>User</th>
                        <th>Aksi</th>
                        <th>Deskripsi</th>
                        <th>IP Address</th>
                        <th>User Agent</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($logs)): ?>
                        <?php foreach ($logs as $log): ?>
                        <tr>
                            <td><?php echo $log['log_id']; ?></td>
                            <td><?php echo date('d/m/Y H:i:s', strtotime($log['created_at'])); ?></td>
                            <td>
                                <?php if ($log['username']): ?>
                                <a href="<?php echo base_url('admin/user_detail/' . $log['user_id']); ?>">
                                    <?php echo $log['username']; ?>
                                </a>
                                <?php else: ?>
                                <span class="text-muted">System</span>
                                <?php endif; ?>
                            </td>
                            <td><span class="badge bg-secondary"><?php echo $log['action']; ?></span></td>
                            <td><?php echo $log['description'] ? $log['description'] : '-'; ?></td>
                            <td><?php echo $log['ip_address']; ?></td>
                            <td>
                                <small class="text-muted">
                                    <?php echo substr($log['user_agent'], 0, 50); ?>
                                    <?php echo strlen($log['user_agent']) > 50 ? '...' : ''; ?>
                                </small>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7" class="text-center">Tidak ada log aktivitas</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <!-- Pagination -->
        <?php if ($total_pages > 1): ?>
        <nav aria-label="Page navigation">
            <ul class="pagination justify-content-center">
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                <li class="page-item <?php echo $i == $current_page ? 'active' : ''; ?>">
                    <a class="page-link" href="<?php echo base_url('admin/logs?page=' . $i . '&' . http_build_query($this->input->get())); ?>">
                        <?php echo $i; ?>
                    </a>
                </li>
                <?php endfor; ?>
            </ul>
        </nav>
        <?php endif; ?>
    </div>
</div>
