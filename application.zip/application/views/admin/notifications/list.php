<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2"><i class="fas fa-bell"></i> Notifikasi</h1>
    <div class="btn-toolbar mb-2 mb-md-0">
        <a href="<?php echo base_url('admin/notifications_read_all'); ?>" class="btn btn-sm btn-primary">
            <i class="fas fa-check-double"></i> Tandai Semua Dibaca
        </a>
    </div>
</div>

<?php if ($this->session->flashdata('success')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <?php echo $this->session->flashdata('success'); ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Semua Notifikasi</h6>
    </div>
    <div class="card-body">
        <?php if (!empty($notifications)): ?>
        <div class="list-group">
            <?php foreach ($notifications as $notif): ?>
            <a href="<?php echo base_url('admin/notification_read/' . $notif['notification_id']); ?>" 
               class="list-group-item list-group-item-action <?php echo $notif['is_read'] ? '' : 'list-group-item-primary'; ?>">
                <div class="d-flex w-100 justify-content-between">
                    <h6 class="mb-1">
                        <?php if ($notif['type'] == 'bug_report'): ?>
                            <i class="fas fa-bug text-danger"></i>
                        <?php elseif ($notif['type'] == 'support_request'): ?>
                            <i class="fas fa-question-circle text-warning"></i>
                        <?php elseif ($notif['type'] == 'new_content'): ?>
                            <i class="fas fa-music text-success"></i>
                        <?php else: ?>
                            <i class="fas fa-info-circle text-info"></i>
                        <?php endif; ?>
                        <?php echo $notif['title']; ?>
                        <?php if (!$notif['is_read']): ?>
                        <span class="badge bg-primary ms-2">Baru</span>
                        <?php endif; ?>
                    </h6>
                    <small class="text-muted"><?php echo date('d M Y, H:i', strtotime($notif['created_at'])); ?></small>
                </div>
                <p class="mb-1"><?php echo $notif['message']; ?></p>
                <?php if ($notif['username']): ?>
                <small class="text-muted">
                    Dari: <strong><?php echo $notif['username']; ?></strong>
                </small>
                <?php endif; ?>
            </a>
            <?php endforeach; ?>
        </div>
        <?php else: ?>
        <div class="text-center py-5">
            <i class="fas fa-bell-slash fa-3x text-muted mb-3"></i>
            <p class="text-muted">Tidak ada notifikasi</p>
        </div>
        <?php endif; ?>
    </div>
</div>
