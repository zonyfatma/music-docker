<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Music - Admin Panel</title>
    <link rel="stylesheet" href="<?= base_url('assets/css/admin.css') ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .upload-container {
            max-width: 800px;
            margin: 40px auto;
            padding: 30px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
        }
        
        .form-group input[type="text"],
        .form-group input[type="file"],
        .form-group select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
        }
        
        .form-group small {
            display: block;
            margin-top: 5px;
            color: #666;
            font-size: 12px;
        }
        
        .upload-options {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 5px;
            margin: 20px 0;
        }
        
        .upload-options h3 {
            margin-top: 0;
            color: #333;
            font-size: 16px;
        }
        
        .radio-group {
            margin: 15px 0;
        }
        
        .radio-group label {
            display: flex;
            align-items: center;
            margin-bottom: 10px;
            cursor: pointer;
        }
        
        .radio-group input[type="radio"] {
            margin-right: 10px;
        }
        
        .conditional-field {
            display: none;
            margin-top: 10px;
            padding-left: 30px;
        }
        
        .conditional-field.active {
            display: block;
        }
        
        .btn-submit {
            background: #667eea;
            color: white;
            padding: 12px 30px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .btn-submit:hover {
            background: #5568d3;
            transform: translateY(-2px);
        }
        
        .btn-back {
            background: #6c757d;
            color: white;
            padding: 12px 30px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            margin-right: 10px;
        }
        
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 5px;
        }
        
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
    </style>
</head>
<body>
    <div class="upload-container">
        <h1><i class="fas fa-music"></i> Upload Music</h1>
        
        <?php if($this->session->flashdata('success')): ?>
            <div class="alert alert-success">
                <?= $this->session->flashdata('success') ?>
            </div>
        <?php endif; ?>
        
        <?php if($this->session->flashdata('error')): ?>
            <div class="alert alert-error">
                <?= $this->session->flashdata('error') ?>
            </div>
        <?php endif; ?>
        
        <form action="<?= base_url('admin_music/do_upload') ?>" method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label for="title">Song Title *</label>
                <input type="text" id="title" name="title" required>
            </div>
            
            <div class="form-group">
                <label for="artist">Artist Name *</label>
                <input type="text" id="artist" name="artist" required>
            </div>
            
            <div class="form-group">
                <label for="album">Album Name</label>
                <input type="text" id="album" name="album">
            </div>
            
            <div class="form-group">
                <label for="genre">Genre</label>
                <select id="genre" name="genre">
                    <option value="">Select Genre</option>
                    <option value="Pop">Pop</option>
                    <option value="Rock">Rock</option>
                    <option value="Hip Hop">Hip Hop</option>
                    <option value="Electronic">Electronic</option>
                    <option value="Jazz">Jazz</option>
                    <option value="Classical">Classical</option>
                    <option value="R&B">R&B</option>
                    <option value="Country">Country</option>
                    <option value="Other">Other</option>
                </select>
            </div>
            
            <div class="form-group">
                <label for="cover_image">Cover Image</label>
                <input type="file" id="cover_image" name="cover_image" accept="image/*">
                <small>Supported formats: JPG, PNG, GIF, WEBP (Max 5MB)</small>
            </div>
            
            <div class="upload-options">
                <h3>Audio File Options</h3>
                
                <div class="radio-group">
                    <label>
                        <input type="radio" name="audio_option" value="upload" checked onchange="toggleAudioOption('upload')">
                        Upload Audio File
                    </label>
                    <div id="upload-field" class="conditional-field active">
                        <input type="file" name="audio_file" accept="audio/*">
                        <small>Supported formats: MP3, WAV, OGG, M4A (Max 50MB)</small>
                    </div>
                </div>
                
                <div class="radio-group">
                    <label>
                        <input type="radio" name="audio_option" value="url" onchange="toggleAudioOption('url')">
                        Use External URL
                    </label>
                    <div id="url-field" class="conditional-field">
                        <input type="text" name="audio_url" placeholder="https://example.com/audio.mp3">
                        <small>Enter direct URL to audio file</small>
                    </div>
                </div>
                
                <div class="radio-group">
                    <label>
                        <input type="radio" name="audio_option" value="demo" onchange="toggleAudioOption('demo')">
                        Use Demo Audio (for testing)
                    </label>
                    <div id="demo-field" class="conditional-field">
                        <small>Will use default demo audio file</small>
                    </div>
                </div>
            </div>
            
            <div style="margin-top: 30px;">
                <a href="<?= base_url('admin_music') ?>" class="btn-back">
                    <i class="fas fa-arrow-left"></i> Back
                </a>
                <button type="submit" class="btn-submit">
                    <i class="fas fa-upload"></i> Upload Music
                </button>
            </div>
        </form>
    </div>
    
    <script>
        function toggleAudioOption(option) {
            // Hide all conditional fields
            document.querySelectorAll('.conditional-field').forEach(field => {
                field.classList.remove('active');
            });
            
            // Show selected field
            const fieldMap = {
                'upload': 'upload-field',
                'url': 'url-field',
                'demo': 'demo-field'
            };
            
            const selectedField = document.getElementById(fieldMap[option]);
            if (selectedField) {
                selectedField.classList.add('active');
            }
            
            // Clear other inputs
            if (option !== 'upload') {
                document.querySelector('input[name="audio_file"]').value = '';
            }
            if (option !== 'url') {
                document.querySelector('input[name="audio_url"]').value = '';
            }
        }
    </script>
</body>
</html>
