<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2"><i class="fas fa-upload"></i> Upload Musik</h1>
    <div class="btn-toolbar mb-2 mb-md-0">
        <a href="<?php echo base_url('admin/music'); ?>" class="btn btn-sm btn-outline-secondary">
            <i class="fas fa-arrow-left"></i> Kembali ke Daftar Musik
        </a>
    </div>
</div>

<?php if ($this->session->flashdata('success')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <?php echo $this->session->flashdata('success'); ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<?php if ($this->session->flashdata('error')): ?>
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <?php echo $this->session->flashdata('error'); ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<div class="row">
    <div class="col-lg-8">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">
                    <i class="fas fa-music"></i> Informasi Musik
                </h6>
            </div>
            <div class="card-body">
                <form action="<?php echo base_url('admin_music/do_upload'); ?>" method="post" enctype="multipart/form-data">
                    
                    <div class="mb-3">
                        <label for="title" class="form-label">Judul Lagu <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="title" name="title" required>
                        <small class="form-text text-muted">Masukkan judul lagu</small>
                    </div>

                    <div class="mb-3">
                        <label for="artist" class="form-label">Artis <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="artist" name="artist" required>
                        <small class="form-text text-muted">Nama artis atau penyanyi</small>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="album" class="form-label">Album</label>
                            <input type="text" class="form-control" id="album" name="album">
                            <small class="form-text text-muted">Nama album (opsional)</small>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="genre" class="form-label">Genre <span class="text-danger">*</span></label>
                            <select class="form-select" id="genre" name="genre" required>
                                <option value="">Pilih Genre</option>
                                <option value="Pop">Pop</option>
                                <option value="Rock">Rock</option>
                                <option value="Jazz">Jazz</option>
                                <option value="Classical">Classical</option>
                                <option value="Electronic">Electronic</option>
                                <option value="Hip Hop">Hip Hop</option>
                                <option value="R&B">R&B</option>
                                <option value="Country">Country</option>
                                <option value="Reggae">Reggae</option>
                                <option value="Blues">Blues</option>
                                <option value="Metal">Metal</option>
                                <option value="Folk">Folk</option>
                                <option value="Indie">Indie</option>
                                <option value="Alternative">Alternative</option>
                                <option value="Other">Lainnya</option>
                            </select>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="cover_image" class="form-label">Cover Album</label>
                        <input type="file" class="form-control" id="cover_image" name="cover_image" accept="image/*">
                        <small class="form-text text-muted">Format: JPG, PNG, WEBP (Maks. 5MB)</small>
                        <div id="cover_preview" class="mt-2" style="display: none;">
                            <img src="" alt="Preview" style="max-width: 200px; border-radius: 8px;">
                        </div>
                    </div>

                    <hr class="my-4">

                    <h6 class="mb-3"><i class="fas fa-file-audio"></i> Sumber Audio</h6>
                    
                    <div class="mb-3">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="audio_source" id="source_upload" value="upload" checked>
                            <label class="form-check-label" for="source_upload">
                                Upload File Audio
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="audio_source" id="source_url" value="url">
                            <label class="form-check-label" for="source_url">
                                URL Eksternal
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="audio_source" id="source_demo" value="demo">
                            <label class="form-check-label" for="source_demo">
                                Gunakan Audio Demo
                            </label>
                        </div>
                    </div>

                    <div id="upload_section" class="mb-3">
                        <label for="audio_file" class="form-label">File Audio <span class="text-danger">*</span></label>
                        <input type="file" class="form-control" id="audio_file" name="audio_file" accept="audio/*">
                        <small class="form-text text-muted">Format: MP3, WAV, OGG, M4A (Maks. 50MB)</small>
                    </div>

                    <div id="url_section" class="mb-3" style="display: none;">
                        <label for="audio_url" class="form-label">URL Audio <span class="text-danger">*</span></label>
                        <input type="url" class="form-control" id="audio_url" name="audio_url" placeholder="https://example.com/song.mp3">
                        <small class="form-text text-muted">Masukkan URL langsung ke file audio</small>
                    </div>

                    <div id="demo_section" class="alert alert-info" style="display: none;">
                        <i class="fas fa-info-circle"></i> Audio demo akan digunakan untuk lagu ini.
                    </div>

                    <hr class="my-4">

                    <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                        <a href="<?php echo base_url('admin_music'); ?>" class="btn btn-secondary me-md-2">
                            <i class="fas fa-times"></i> Batal
                        </a>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-upload"></i> Upload Musik
                        </button>
                    </div>

                </form>
            </div>
        </div>
    </div>

    <div class="col-lg-4">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">
                    <i class="fas fa-info-circle"></i> Panduan Upload
                </h6>
            </div>
            <div class="card-body">
                <h6><i class="fas fa-check-circle text-success"></i> Format yang Didukung</h6>
                <ul class="small">
                    <li><strong>Audio:</strong> MP3, WAV, OGG, M4A</li>
                    <li><strong>Cover:</strong> JPG, PNG, WEBP</li>
                </ul>

                <h6 class="mt-3"><i class="fas fa-exclamation-triangle text-warning"></i> Batasan Ukuran</h6>
                <ul class="small">
                    <li><strong>File Audio:</strong> Maksimal 50MB</li>
                    <li><strong>Cover Album:</strong> Maksimal 5MB</li>
                </ul>

                <h6 class="mt-3"><i class="fas fa-lightbulb text-info"></i> Tips</h6>
                <ul class="small">
                    <li>Gunakan cover album berkualitas tinggi (minimal 500x500px)</li>
                    <li>Pastikan informasi lagu lengkap dan akurat</li>
                    <li>Pilih genre yang sesuai untuk memudahkan pencarian</li>
                    <li>Anda dapat menggunakan URL eksternal jika file terlalu besar</li>
                </ul>
            </div>
        </div>

        <?php if (isset($music_list) && !empty($music_list)): ?>
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">
                    <i class="fas fa-music"></i> Musik Terbaru
                </h6>
            </div>
            <div class="card-body">
                <div class="list-group list-group-flush">
                    <?php foreach (array_slice($music_list, 0, 5) as $music): ?>
                    <div class="list-group-item px-0">
                        <div class="d-flex w-100 justify-content-between">
                            <h6 class="mb-1"><?php echo $music['title']; ?></h6>
                        </div>
                        <p class="mb-1 small text-muted"><?php echo $music['artist']; ?></p>
                        <small class="text-muted"><?php echo $music['genre']; ?></small>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<script>
// Preview cover image
document.getElementById('cover_image').addEventListener('change', function(e) {
    const file = e.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            const preview = document.getElementById('cover_preview');
            preview.querySelector('img').src = e.target.result;
            preview.style.display = 'block';
        }
        reader.readAsDataURL(file);
    }
});

// Toggle audio source sections
document.querySelectorAll('input[name="audio_source"]').forEach(radio => {
    radio.addEventListener('change', function() {
        const uploadSection = document.getElementById('upload_section');
        const urlSection = document.getElementById('url_section');
        const demoSection = document.getElementById('demo_section');
        const audioFile = document.getElementById('audio_file');
        const audioUrl = document.getElementById('audio_url');

        // Hide all sections
        uploadSection.style.display = 'none';
        urlSection.style.display = 'none';
        demoSection.style.display = 'none';

        // Remove required attributes
        audioFile.removeAttribute('required');
        audioUrl.removeAttribute('required');

        // Show selected section
        if (this.value === 'upload') {
            uploadSection.style.display = 'block';
            audioFile.setAttribute('required', 'required');
        } else if (this.value === 'url') {
            urlSection.style.display = 'block';
            audioUrl.setAttribute('required', 'required');
        } else if (this.value === 'demo') {
            demoSection.style.display = 'block';
        }
    });
});
</script>
