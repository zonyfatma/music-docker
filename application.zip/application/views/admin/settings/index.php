<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2"><i class="fas fa-cog"></i> Pengaturan Sistem</h1>
</div>

<?php if ($this->session->flashdata('success')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <?php echo $this->session->flashdata('success'); ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<div class="row">
    <div class="col-lg-8">
        <!-- General Settings -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Pengaturan Umum</h6>
            </div>
            <div class="card-body">
                <form method="post" action="<?php echo base_url('admin/settings_update'); ?>">
                    <div class="mb-3">
                        <label for="app_name" class="form-label">Nama Aplikasi</label>
                        <input type="text" class="form-control" id="app_name" name="settings[app_name]" 
                               value="<?php echo isset($settings['app_name']) ? $settings['app_name'] : 'Musikk App'; ?>">
                    </div>
                    
                    <div class="mb-3">
                        <label for="app_logo" class="form-label">Logo Aplikasi (Path)</label>
                        <input type="text" class="form-control" id="app_logo" name="settings[app_logo]" 
                               value="<?php echo isset($settings['app_logo']) ? $settings['app_logo'] : 'assets/images/logo.png'; ?>">
                        <small class="form-text text-muted">Masukkan path relatif ke logo (contoh: assets/images/logo.png)</small>
                    </div>
                    
                    <div class="mb-3">
                        <label for="email_notifications" class="form-label">Notifikasi Email</label>
                        <select class="form-select" id="email_notifications" name="settings[email_notifications]">
                            <option value="enabled" <?php echo (isset($settings['email_notifications']) && $settings['email_notifications'] == 'enabled') ? 'selected' : ''; ?>>Aktif</option>
                            <option value="disabled" <?php echo (isset($settings['email_notifications']) && $settings['email_notifications'] == 'disabled') ? 'selected' : ''; ?>>Nonaktif</option>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label for="maintenance_mode" class="form-label">Mode Maintenance</label>
                        <select class="form-select" id="maintenance_mode" name="settings[maintenance_mode]">
                            <option value="disabled" <?php echo (isset($settings['maintenance_mode']) && $settings['maintenance_mode'] == 'disabled') ? 'selected' : ''; ?>>Nonaktif</option>
                            <option value="enabled" <?php echo (isset($settings['maintenance_mode']) && $settings['maintenance_mode'] == 'enabled') ? 'selected' : ''; ?>>Aktif</option>
                        </select>
                        <small class="form-text text-muted">Ketika aktif, hanya admin yang dapat mengakses situs</small>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Simpan Pengaturan
                    </button>
                </form>
            </div>
        </div>
    </div>
    
    <div class="col-lg-4">
        <!-- User Roles -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Role Pengguna</h6>
            </div>
            <div class="card-body">
                <div class="list-group list-group-flush">
                    <?php foreach ($roles as $role): ?>
                    <div class="list-group-item">
                        <div class="d-flex w-100 justify-content-between">
                            <h6 class="mb-1"><?php echo $role['role_name']; ?></h6>
                            <span class="badge bg-primary"><?php echo $role['role_id']; ?></span>
                        </div>
                        <small class="text-muted">
                            <?php 
                            $permissions = json_decode($role['permissions'], true);
                            if ($permissions) {
                                echo 'Permissions: ' . implode(', ', array_keys($permissions));
                            }
                            ?>
                        </small>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        
        <!-- System Info -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Informasi Sistem</h6>
            </div>
            <div class="card-body">
                <div class="mb-2">
                    <strong>PHP Version:</strong><br>
                    <span class="text-muted"><?php echo phpversion(); ?></span>
                </div>
                <div class="mb-2">
                    <strong>CodeIgniter Version:</strong><br>
                    <span class="text-muted"><?php echo CI_VERSION; ?></span>
                </div>
                <div class="mb-2">
                    <strong>Database:</strong><br>
                    <span class="text-muted">MySQL</span>
                </div>
                <div class="mb-2">
                    <strong>Server Software:</strong><br>
                    <span class="text-muted"><?php echo $_SERVER['SERVER_SOFTWARE']; ?></span>
                </div>
            </div>
        </div>
    </div>
</div>
