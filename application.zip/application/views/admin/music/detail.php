<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2"><i class="fas fa-music"></i> Detail Musik</h1>
    <div class="btn-toolbar mb-2 mb-md-0">
        <a href="<?php echo base_url('admin/music'); ?>" class="btn btn-sm btn-outline-secondary">
            <i class="fas fa-arrow-left"></i> Kembali
        </a>
    </div>
</div>

<?php if ($this->session->flashdata('success')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <?php echo $this->session->flashdata('success'); ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<div class="row">
    <!-- Music Info -->
    <div class="col-lg-4">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Informasi Musik</h6>
            </div>
            <div class="card-body text-center">
                <div class="mb-3">
                    <?php if ($music['cover_image']): ?>
                    <img src="<?php echo base_url($music['cover_image']); ?>" class="img-fluid rounded" alt="Cover" style="max-height: 250px;">
                    <?php else: ?>
                    <i class="fas fa-music fa-5x text-secondary"></i>
                    <?php endif; ?>
                </div>
                
                <h4><?php echo $music['title']; ?></h4>
                <p class="text-muted"><?php echo $music['artist']; ?></p>
                
                <div class="mb-3">
                    <?php if ($music['status'] == 'approved'): ?>
                        <span class="badge bg-success">Disetujui</span>
                    <?php elseif ($music['status'] == 'pending'): ?>
                        <span class="badge bg-warning">Menunggu</span>
                    <?php else: ?>
                        <span class="badge bg-danger">Ditolak</span>
                    <?php endif; ?>
                </div>
                
                <div class="list-group list-group-flush text-start">
                    <div class="list-group-item">
                        <strong>Music ID:</strong> <?php echo $music['music_id']; ?>
                    </div>
                    <div class="list-group-item">
                        <strong>Album:</strong> <?php echo $music['album'] ? $music['album'] : '-'; ?>
                    </div>
                    <div class="list-group-item">
                        <strong>Genre:</strong> <?php echo $music['genre'] ? $music['genre'] : '-'; ?>
                    </div>
                    <div class="list-group-item">
                        <strong>Durasi:</strong> <?php echo gmdate("i:s", $music['duration']); ?>
                    </div>
                    <div class="list-group-item">
                        <strong>Pemutaran:</strong> <?php echo number_format($music['play_count']); ?>
                    </div>
                    <div class="list-group-item">
                        <strong>Rating:</strong> ⭐ <?php echo $music['rating']; ?>
                    </div>
                    <div class="list-group-item">
                        <strong>Diunggah Oleh:</strong> 
                        <?php if ($music['uploaded_by_name']): ?>
                        <a href="<?php echo base_url('admin/user_detail/' . $music['upload_by']); ?>">
                            <?php echo $music['uploaded_by_name']; ?>
                        </a>
                        <?php else: ?>
                        System
                        <?php endif; ?>
                    </div>
                    <div class="list-group-item">
                        <strong>Diunggah:</strong> <?php echo date('d M Y, H:i', strtotime($music['created_at'])); ?>
                    </div>
                    <div class="list-group-item">
                        <strong>Terakhir Update:</strong> <?php echo date('d M Y, H:i', strtotime($music['updated_at'])); ?>
                    </div>
                </div>
                
                <div class="mt-3 d-grid gap-2">
                    <?php if ($music['status'] == 'pending'): ?>
                    <a href="<?php echo base_url('admin/music_approve/' . $music['music_id']); ?>" 
                       class="btn btn-success" 
                       onclick="return confirm('Yakin ingin menyetujui musik ini?');">
                        <i class="fas fa-check"></i> Setujui Musik
                    </a>
                    <a href="<?php echo base_url('admin/music_reject/' . $music['music_id']); ?>" 
                       class="btn btn-warning" 
                       onclick="return confirm('Yakin ingin menolak musik ini?');">
                        <i class="fas fa-times"></i> Tolak Musik
                    </a>
                    <?php endif; ?>
                    
                    <a href="<?php echo base_url('admin/music_delete/' . $music['music_id']); ?>" 
                       class="btn btn-danger" 
                       onclick="return confirm('Yakin ingin menghapus musik ini? Tindakan ini tidak dapat dibatalkan!');">
                        <i class="fas fa-trash"></i> Hapus Musik
                    </a>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Additional Info -->
    <div class="col-lg-8">
        <!-- File Info -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Informasi File</h6>
            </div>
            <div class="card-body">
                <table class="table table-borderless">
                    <tr>
                        <th width="200">File Path:</th>
                        <td><?php echo $music['file_path'] ? $music['file_path'] : '-'; ?></td>
                    </tr>
                    <tr>
                        <th>Cover Image:</th>
                        <td><?php echo $music['cover_image'] ? $music['cover_image'] : '-'; ?></td>
                    </tr>
                </table>
                
                <?php if ($music['file_path'] && file_exists($music['file_path'])): ?>
                <div class="mt-3">
                    <audio controls class="w-100">
                        <source src="<?php echo base_url($music['file_path']); ?>" type="audio/mpeg">
                        Browser Anda tidak mendukung audio player.
                    </audio>
                </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Statistics -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">
                    <i class="fas fa-chart-line"></i> Statistik Pemutaran
                </h6>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4 text-center mb-3">
                        <div class="border rounded p-3">
                            <h5 class="text-muted mb-0">Total Pemutaran</h5>
                            <h2 class="text-primary"><?php echo number_format($music['play_count']); ?></h2>
                        </div>
                    </div>
                    <div class="col-md-4 text-center mb-3">
                        <div class="border rounded p-3">
                            <h5 class="text-muted mb-0">Rating</h5>
                            <h2 class="text-warning">⭐ <?php echo $music['rating']; ?></h2>
                        </div>
                    </div>
                    <div class="col-md-4 text-center mb-3">
                        <div class="border rounded p-3">
                            <h5 class="text-muted mb-0">Status</h5>
                            <h2>
                                <?php if ($music['status'] == 'approved'): ?>
                                    <span class="badge bg-success">✓</span>
                                <?php elseif ($music['status'] == 'pending'): ?>
                                    <span class="badge bg-warning">⏳</span>
                                <?php else: ?>
                                    <span class="badge bg-danger">✗</span>
                                <?php endif; ?>
                            </h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
