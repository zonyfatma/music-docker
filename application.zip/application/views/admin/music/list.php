<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2"><i class="fas fa-music"></i> Manajemen Musik</h1>
    <div class="btn-toolbar mb-2 mb-md-0">
        <div class="btn-group me-2">
            <button type="button" class="btn btn-sm btn-outline-secondary" onclick="location.reload();">
                <i class="fas fa-sync-alt"></i> Refresh
            </button>
        </div>
    </div>
</div>

<?php if ($this->session->flashdata('success')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <?php echo $this->session->flashdata('success'); ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<!-- Filters -->
<div class="card mb-4">
    <div class="card-body">
        <form method="get" action="<?php echo base_url('admin/music'); ?>" class="row g-3">
            <div class="col-md-4">
                <label class="form-label">Status</label>
                <select name="status" class="form-select">
                    <option value="">Semua Status</option>
                    <option value="approved" <?php echo $this->input->get('status') == 'approved' ? 'selected' : ''; ?>>Disetujui</option>
                    <option value="pending" <?php echo $this->input->get('status') == 'pending' ? 'selected' : ''; ?>>Menunggu</option>
                    <option value="rejected" <?php echo $this->input->get('status') == 'rejected' ? 'selected' : ''; ?>>Ditolak</option>
                </select>
            </div>
            <div class="col-md-6">
                <label class="form-label">Cari</label>
                <input type="text" name="search" class="form-control" placeholder="Judul atau artis..." value="<?php echo $this->input->get('search'); ?>">
            </div>
            <div class="col-md-2">
                <label class="form-label">&nbsp;</label>
                <button type="submit" class="btn btn-primary w-100">
                    <i class="fas fa-filter"></i> Filter
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Music Table -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">
            Daftar Musik (<?php echo number_format($total_music); ?> total)
        </h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <th width="50">ID</th>
                        <th>Judul</th>
                        <th>Artis</th>
                        <th>Album</th>
                        <th>Genre</th>
                        <th>Diunggah Oleh</th>
                        <th>Pemutaran</th>
                        <th>Status</th>
                        <th width="180">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($music)): ?>
                        <?php foreach ($music as $item): ?>
                        <tr>
                            <td><?php echo $item['music_id']; ?></td>
                            <td><strong><?php echo $item['title']; ?></strong></td>
                            <td><?php echo $item['artist']; ?></td>
                            <td><?php echo $item['album'] ? $item['album'] : '-'; ?></td>
                            <td><?php echo $item['genre'] ? $item['genre'] : '-'; ?></td>
                            <td><?php echo $item['uploaded_by_name'] ? $item['uploaded_by_name'] : 'System'; ?></td>
                            <td><?php echo number_format($item['play_count']); ?></td>
                            <td>
                                <?php if ($item['status'] == 'approved'): ?>
                                    <span class="badge bg-success">Disetujui</span>
                                <?php elseif ($item['status'] == 'pending'): ?>
                                    <span class="badge bg-warning">Menunggu</span>
                                <?php else: ?>
                                    <span class="badge bg-danger">Ditolak</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="<?php echo base_url('admin/music_detail/' . $item['music_id']); ?>" class="btn btn-sm btn-primary" title="Detail">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <?php if ($item['status'] == 'pending'): ?>
                                <a href="<?php echo base_url('admin/music_approve/' . $item['music_id']); ?>" class="btn btn-sm btn-success" title="Setujui">
                                    <i class="fas fa-check"></i>
                                </a>
                                <a href="<?php echo base_url('admin/music_reject/' . $item['music_id']); ?>" class="btn btn-sm btn-warning" title="Tolak">
                                    <i class="fas fa-times"></i>
                                </a>
                                <?php endif; ?>
                                <a href="<?php echo base_url('admin/music_delete/' . $item['music_id']); ?>" class="btn btn-sm btn-danger" 
                                   onclick="return confirm('Yakin ingin menghapus musik ini?');" title="Hapus">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="9" class="text-center">Tidak ada data musik</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <!-- Pagination -->
        <?php if ($total_pages > 1): ?>
        <nav aria-label="Page navigation">
            <ul class="pagination justify-content-center">
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                <li class="page-item <?php echo $i == $current_page ? 'active' : ''; ?>">
                    <a class="page-link" href="<?php echo base_url('admin/music?page=' . $i . '&' . http_build_query($this->input->get())); ?>">
                        <?php echo $i; ?>
                    </a>
                </li>
                <?php endfor; ?>
            </ul>
        </nav>
        <?php endif; ?>
    </div>
</div>
