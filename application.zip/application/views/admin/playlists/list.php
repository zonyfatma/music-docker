<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2"><i class="fas fa-list"></i> Manajemen Playlist</h1>
    <div class="btn-toolbar mb-2 mb-md-0">
        <button type="button" class="btn btn-sm btn-outline-secondary" onclick="location.reload();">
            <i class="fas fa-sync-alt"></i> Refresh
        </button>
    </div>
</div>

<?php if ($this->session->flashdata('success')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <?php echo $this->session->flashdata('success'); ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<!-- Filters -->
<div class="card mb-4">
    <div class="card-body">
        <form method="get" action="<?php echo base_url('admin/playlists'); ?>" class="row g-3">
            <div class="col-md-4">
                <label class="form-label">Status</label>
                <select name="status" class="form-select">
                    <option value="">Semua Status</option>
                    <option value="active" <?php echo $this->input->get('status') == 'active' ? 'selected' : ''; ?>>Aktif</option>
                    <option value="deleted" <?php echo $this->input->get('status') == 'deleted' ? 'selected' : ''; ?>>Dihapus</option>
                </select>
            </div>
            <div class="col-md-6">
                <label class="form-label">Cari</label>
                <input type="text" name="search" class="form-control" placeholder="Nama playlist..." value="<?php echo $this->input->get('search'); ?>">
            </div>
            <div class="col-md-2">
                <label class="form-label">&nbsp;</label>
                <button type="submit" class="btn btn-primary w-100">
                    <i class="fas fa-filter"></i> Filter
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Playlists Table -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">
            Daftar Playlist (<?php echo number_format($total_playlists); ?> total)
        </h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <th width="50">ID</th>
                        <th>Nama Playlist</th>
                        <th>Pemilik</th>
                        <th>Jumlah Lagu</th>
                        <th>Pemutaran</th>
                        <th>Dibuat</th>
                        <th>Status</th>
                        <th width="100">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($playlists)): ?>
                        <?php foreach ($playlists as $playlist): ?>
                        <tr>
                            <td><?php echo $playlist['playlist_id']; ?></td>
                            <td>
                                <strong><?php echo $playlist['playlist_name']; ?></strong>
                                <?php if (isset($playlist['is_public']) && !$playlist['is_public']): ?>
                                <i class="fas fa-lock text-muted" title="Private"></i>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="<?php echo base_url('admin/user_detail/' . $playlist['user_id']); ?>">
                                    <?php echo $playlist['username']; ?>
                                </a>
                            </td>
                            <td><?php echo isset($playlist['song_count']) ? $playlist['song_count'] : 0; ?> lagu</td>
                            <td><?php echo isset($playlist['play_count']) ? number_format($playlist['play_count']) : 0; ?></td>
                            <td><?php echo date('d/m/Y', strtotime($playlist['created_at'])); ?></td>
                            <td>
                                <?php if (isset($playlist['status']) && $playlist['status'] == 'active'): ?>
                                    <span class="badge bg-success">Aktif</span>
                                <?php else: ?>
                                    <span class="badge bg-danger">Dihapus</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if (!isset($playlist['status']) || $playlist['status'] == 'active'): ?>
                                <a href="<?php echo base_url('admin/playlist_delete/' . $playlist['playlist_id']); ?>" 
                                   class="btn btn-sm btn-danger" 
                                   onclick="return confirm('Yakin ingin menghapus playlist ini?');" 
                                   title="Hapus">
                                    <i class="fas fa-trash"></i>
                                </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="8" class="text-center">Tidak ada data playlist</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <!-- Pagination -->
        <?php if ($total_pages > 1): ?>
        <nav aria-label="Page navigation">
            <ul class="pagination justify-content-center">
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                <li class="page-item <?php echo $i == $current_page ? 'active' : ''; ?>">
                    <a class="page-link" href="<?php echo base_url('admin/playlists?page=' . $i . '&' . http_build_query($this->input->get())); ?>">
                        <?php echo $i; ?>
                    </a>
                </li>
                <?php endfor; ?>
            </ul>
        </nav>
        <?php endif; ?>
    </div>
</div>
