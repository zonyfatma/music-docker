<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2"><i class="fas fa-user"></i> Detail Pengguna</h1>
    <div class="btn-toolbar mb-2 mb-md-0">
        <a href="<?php echo base_url('admin/users'); ?>" class="btn btn-sm btn-outline-secondary">
            <i class="fas fa-arrow-left"></i> Kembali
        </a>
    </div>
</div>

<?php if ($this->session->flashdata('success')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <?php echo $this->session->flashdata('success'); ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<?php if ($this->session->flashdata('error')): ?>
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <?php echo $this->session->flashdata('error'); ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<div class="row">
    <!-- User Info -->
    <div class="col-lg-4">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Informasi Pengguna</h6>
            </div>
            <div class="card-body text-center">
                <div class="mb-3">
                    <i class="fas fa-user-circle fa-5x text-secondary"></i>
                </div>
                <h4><?php echo $user['username']; ?></h4>
                <p class="text-muted"><?php echo $user['email']; ?></p>
                
                <div class="mb-3">
                    <span class="badge bg-info"><?php echo $user['role_name']; ?></span>
                    <?php if ($user['status'] == 'active'): ?>
                        <span class="badge bg-success">Aktif</span>
                    <?php elseif ($user['status'] == 'inactive'): ?>
                        <span class="badge bg-secondary">Nonaktif</span>
                    <?php else: ?>
                        <span class="badge bg-danger">Diblokir</span>
                    <?php endif; ?>
                </div>
                
                <div class="list-group list-group-flush text-start">
                    <div class="list-group-item">
                        <strong>User ID:</strong> <?php echo $user['user_id']; ?>
                    </div>
                    <div class="list-group-item">
                        <strong>Terdaftar:</strong> <?php echo date('d M Y, H:i', strtotime($user['created_at'])); ?>
                    </div>
                    <div class="list-group-item">
                        <strong>Login Terakhir:</strong> 
                        <?php echo $user['last_login'] ? date('d M Y, H:i', strtotime($user['last_login'])) : 'Belum pernah login'; ?>
                    </div>
                    <div class="list-group-item">
                        <strong>Total Login:</strong> <?php echo $user['login_count']; ?> kali
                    </div>
                </div>
                
                <?php if ($user['user_id'] != $this->session->userdata('user_id')): ?>
                <div class="mt-3 d-grid gap-2">
                    <?php if ($user['status'] == 'blocked'): ?>
                    <a href="<?php echo base_url('admin/user_unblock/' . $user['user_id']); ?>" 
                       class="btn btn-success" 
                       onclick="return confirm('Yakin ingin mengaktifkan kembali pengguna ini?');">
                        <i class="fas fa-unlock"></i> Aktifkan Kembali
                    </a>
                    <?php else: ?>
                    <a href="<?php echo base_url('admin/user_block/' . $user['user_id']); ?>" 
                       class="btn btn-warning" 
                       onclick="return confirm('Yakin ingin memblokir pengguna ini?');">
                        <i class="fas fa-ban"></i> Blokir Pengguna
                    </a>
                    <?php endif; ?>
                    
                    <a href="<?php echo base_url('admin/user_delete/' . $user['user_id']); ?>" 
                       class="btn btn-danger" 
                       onclick="return confirm('Yakin ingin menghapus pengguna ini? Tindakan ini tidak dapat dibatalkan!');">
                        <i class="fas fa-trash"></i> Hapus Pengguna
                    </a>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Edit Form & Activity -->
    <div class="col-lg-8">
        <!-- Edit Form -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Edit Informasi</h6>
            </div>
            <div class="card-body">
                <form method="post" action="<?php echo base_url('admin/user_update/' . $user['user_id']); ?>">
                    <div class="mb-3">
                        <label for="username" class="form-label">Username</label>
                        <input type="text" class="form-control" id="username" name="username" value="<?php echo $user['username']; ?>" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" name="email" value="<?php echo $user['email']; ?>" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="role_id" class="form-label">Role</label>
                        <select class="form-select" id="role_id" name="role_id" required>
                            <?php foreach ($roles as $role): ?>
                            <option value="<?php echo $role['role_id']; ?>" <?php echo $user['role_id'] == $role['role_id'] ? 'selected' : ''; ?>>
                                <?php echo $role['role_name']; ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label for="status" class="form-label">Status</label>
                        <select class="form-select" id="status" name="status" required>
                            <option value="active" <?php echo $user['status'] == 'active' ? 'selected' : ''; ?>>Aktif</option>
                            <option value="inactive" <?php echo $user['status'] == 'inactive' ? 'selected' : ''; ?>>Nonaktif</option>
                            <option value="blocked" <?php echo $user['status'] == 'blocked' ? 'selected' : ''; ?>>Diblokir</option>
                        </select>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Simpan Perubahan
                    </button>
                </form>
            </div>
        </div>
        
        <!-- Activity Log -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">
                    <i class="fas fa-history"></i> Aktivitas Terbaru
                </h6>
            </div>
            <div class="card-body">
                <?php if (!empty($activity)): ?>
                <div class="table-responsive">
                    <table class="table table-sm table-hover">
                        <thead>
                            <tr>
                                <th>Waktu</th>
                                <th>Aksi</th>
                                <th>Deskripsi</th>
                                <th>IP Address</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($activity as $log): ?>
                            <tr>
                                <td><?php echo date('d/m/Y H:i', strtotime($log['created_at'])); ?></td>
                                <td><span class="badge bg-secondary"><?php echo $log['action']; ?></span></td>
                                <td><?php echo $log['description']; ?></td>
                                <td><?php echo $log['ip_address']; ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php else: ?>
                <p class="text-muted text-center">Belum ada aktivitas yang tercatat</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
