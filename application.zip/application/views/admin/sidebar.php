            <!-- Sidebar -->
            <nav id="sidebar" class="col-md-3 col-lg-2 d-md-block bg-light sidebar">
                <div class="position-sticky pt-3">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link <?php echo $this->uri->segment(2) == '' || $this->uri->segment(2) == 'index' ? 'active' : ''; ?>" href="<?php echo base_url('admin'); ?>">
                                <i class="fas fa-tachometer-alt"></i> Dashboard
                            </a>
                        </li>
                        
                        <li class="nav-item">
                            <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
                                <span>MANAJEMEN</span>
                            </h6>
                        </li>
                        
                        <li class="nav-item">
                            <a class="nav-link <?php echo $this->uri->segment(2) == 'users' || $this->uri->segment(2) == 'user_detail' ? 'active' : ''; ?>" href="<?php echo base_url('admin/users'); ?>">
                                <i class="fas fa-users"></i> Pengguna
                            </a>
                        </li>
                        
                        <li class="nav-item">
                            <a class="nav-link <?php echo $this->uri->segment(2) == 'music' || $this->uri->segment(2) == 'music_detail' ? 'active' : ''; ?>" href="<?php echo base_url('admin/music'); ?>">
                                <i class="fas fa-music"></i> Musik
                            </a>
                        </li>
                        
                        <li class="nav-item">
                            <a class="nav-link <?php echo $this->uri->segment(1) == 'admin_music' ? 'active' : ''; ?>" href="<?php echo base_url('admin_music'); ?>">
                                <i class="fas fa-upload"></i> Upload Musik
                            </a>
                        </li>
                        
                        <li class="nav-item">
                            <a class="nav-link <?php echo $this->uri->segment(2) == 'podcasts' || $this->uri->segment(2) == 'podcast_detail' ? 'active' : ''; ?>" href="<?php echo base_url('admin/podcasts'); ?>">
                                <i class="fas fa-podcast"></i> Podcast
                            </a>
                        </li>
                        
                        <li class="nav-item">
                            <a class="nav-link <?php echo $this->uri->segment(2) == 'playlists' ? 'active' : ''; ?>" href="<?php echo base_url('admin/playlists'); ?>">
                                <i class="fas fa-list"></i> Playlist
                            </a>
                        </li>
                        
                        <li class="nav-item">
                            <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
                                <span>LAPORAN</span>
                            </h6>
                        </li>
                        
                        <li class="nav-item">
                            <a class="nav-link <?php echo $this->uri->segment(2) == 'reports' ? 'active' : ''; ?>" href="<?php echo base_url('admin/reports'); ?>">
                                <i class="fas fa-chart-bar"></i> Statistik & Laporan
                            </a>
                        </li>
                        
                        <li class="nav-item">
                            <a class="nav-link <?php echo $this->uri->segment(2) == 'logs' ? 'active' : ''; ?>" href="<?php echo base_url('admin/logs'); ?>">
                                <i class="fas fa-history"></i> Log Aktivitas
                            </a>
                        </li>
                        
                        <li class="nav-item">
                            <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
                                <span>SISTEM</span>
                            </h6>
                        </li>
                        
                        <li class="nav-item">
                            <a class="nav-link <?php echo $this->uri->segment(2) == 'notifications' ? 'active' : ''; ?>" href="<?php echo base_url('admin/notifications'); ?>">
                                <i class="fas fa-bell"></i> Notifikasi
                                <?php if (isset($stats['unread_notifications']) && $stats['unread_notifications'] > 0): ?>
                                <span class="badge bg-danger ms-2"><?php echo $stats['unread_notifications']; ?></span>
                                <?php endif; ?>
                            </a>
                        </li>
                        
                        <li class="nav-item">
                            <a class="nav-link <?php echo $this->uri->segment(2) == 'settings' ? 'active' : ''; ?>" href="<?php echo base_url('admin/settings'); ?>">
                                <i class="fas fa-cog"></i> Pengaturan
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>
            
            <!-- Main Content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
