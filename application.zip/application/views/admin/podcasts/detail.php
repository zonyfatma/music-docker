<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2"><i class="fas fa-podcast"></i> Detail Podcast</h1>
    <div class="btn-toolbar mb-2 mb-md-0">
        <a href="<?php echo base_url('admin/podcasts'); ?>" class="btn btn-sm btn-outline-secondary">
            <i class="fas fa-arrow-left"></i> Kembali
        </a>
    </div>
</div>

<?php if ($this->session->flashdata('success')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <?php echo $this->session->flashdata('success'); ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<div class="row">
    <!-- Podcast Info -->
    <div class="col-lg-4">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Informasi Podcast</h6>
            </div>
            <div class="card-body text-center">
                <div class="mb-3">
                    <?php if ($podcast['cover_image']): ?>
                    <img src="<?php echo base_url($podcast['cover_image']); ?>" class="img-fluid rounded" alt="Cover" style="max-height: 250px;">
                    <?php else: ?>
                    <i class="fas fa-podcast fa-5x text-secondary"></i>
                    <?php endif; ?>
                </div>
                
                <h4><?php echo $podcast['title']; ?></h4>
                <p class="text-muted">Host: <?php echo $podcast['host']; ?></p>
                
                <div class="mb-3">
                    <?php if ($podcast['status'] == 'approved'): ?>
                        <span class="badge bg-success">Disetujui</span>
                    <?php elseif ($podcast['status'] == 'pending'): ?>
                        <span class="badge bg-warning">Menunggu</span>
                    <?php else: ?>
                        <span class="badge bg-danger">Ditolak</span>
                    <?php endif; ?>
                </div>
                
                <div class="list-group list-group-flush text-start">
                    <div class="list-group-item">
                        <strong>Podcast ID:</strong> <?php echo $podcast['podcast_id']; ?>
                    </div>
                    <div class="list-group-item">
                        <strong>Kategori:</strong> <?php echo $podcast['category'] ? $podcast['category'] : '-'; ?>
                    </div>
                    <div class="list-group-item">
                        <strong>Durasi:</strong> <?php echo gmdate("H:i:s", $podcast['duration']); ?>
                    </div>
                    <div class="list-group-item">
                        <strong>Pemutaran:</strong> <?php echo number_format($podcast['play_count']); ?>
                    </div>
                    <div class="list-group-item">
                        <strong>Rating:</strong> ⭐ <?php echo $podcast['rating']; ?>
                    </div>
                    <div class="list-group-item">
                        <strong>Diunggah Oleh:</strong> 
                        <?php if ($podcast['uploaded_by_name']): ?>
                        <a href="<?php echo base_url('admin/user_detail/' . $podcast['upload_by']); ?>">
                            <?php echo $podcast['uploaded_by_name']; ?>
                        </a>
                        <?php else: ?>
                        System
                        <?php endif; ?>
                    </div>
                    <div class="list-group-item">
                        <strong>Diunggah:</strong> <?php echo date('d M Y, H:i', strtotime($podcast['created_at'])); ?>
                    </div>
                    <div class="list-group-item">
                        <strong>Terakhir Update:</strong> <?php echo date('d M Y, H:i', strtotime($podcast['updated_at'])); ?>
                    </div>
                </div>
                
                <div class="mt-3 d-grid gap-2">
                    <a href="<?php echo base_url('admin/podcast_delete/' . $podcast['podcast_id']); ?>" 
                       class="btn btn-danger" 
                       onclick="return confirm('Yakin ingin menghapus podcast ini? Tindakan ini tidak dapat dibatalkan!');">
                        <i class="fas fa-trash"></i> Hapus Podcast
                    </a>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Additional Info -->
    <div class="col-lg-8">
        <!-- Description -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Deskripsi</h6>
            </div>
            <div class="card-body">
                <?php if ($podcast['description']): ?>
                <p><?php echo nl2br($podcast['description']); ?></p>
                <?php else: ?>
                <p class="text-muted">Tidak ada deskripsi</p>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- File Info -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Informasi File</h6>
            </div>
            <div class="card-body">
                <table class="table table-borderless">
                    <tr>
                        <th width="200">File Path:</th>
                        <td><?php echo $podcast['file_path'] ? $podcast['file_path'] : '-'; ?></td>
                    </tr>
                    <tr>
                        <th>Cover Image:</th>
                        <td><?php echo $podcast['cover_image'] ? $podcast['cover_image'] : '-'; ?></td>
                    </tr>
                </table>
                
                <?php if ($podcast['file_path'] && file_exists($podcast['file_path'])): ?>
                <div class="mt-3">
                    <audio controls class="w-100">
                        <source src="<?php echo base_url($podcast['file_path']); ?>" type="audio/mpeg">
                        Browser Anda tidak mendukung audio player.
                    </audio>
                </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Statistics -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">
                    <i class="fas fa-chart-line"></i> Statistik Pemutaran
                </h6>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4 text-center mb-3">
                        <div class="border rounded p-3">
                            <h5 class="text-muted mb-0">Total Pemutaran</h5>
                            <h2 class="text-primary"><?php echo number_format($podcast['play_count']); ?></h2>
                        </div>
                    </div>
                    <div class="col-md-4 text-center mb-3">
                        <div class="border rounded p-3">
                            <h5 class="text-muted mb-0">Rating</h5>
                            <h2 class="text-warning">⭐ <?php echo $podcast['rating']; ?></h2>
                        </div>
                    </div>
                    <div class="col-md-4 text-center mb-3">
                        <div class="border rounded p-3">
                            <h5 class="text-muted mb-0">Status</h5>
                            <h2>
                                <?php if ($podcast['status'] == 'approved'): ?>
                                    <span class="badge bg-success">✓</span>
                                <?php elseif ($podcast['status'] == 'pending'): ?>
                                    <span class="badge bg-warning">⏳</span>
                                <?php else: ?>
                                    <span class="badge bg-danger">✗</span>
                                <?php endif; ?>
                            </h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
