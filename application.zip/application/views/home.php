<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset(
$this->app_settings['app_name']) ? $this->app_settings['app_name'] : 'Musikk'; ?> - <?= $artist->name ?></title>
    <link rel="stylesheet" href="<?= base_url('assets/css/main.css') ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
</head>
<body>
    <div class="container">
        <!-- Sidebar -->
        <?php $this->load->view('partials/sidebar'); ?>

        <!-- Main Content -->
        <main class="main-content">
            <!-- Header -->
            <?php $this->load->view('partials/header'); ?>

            <!-- Artist Header -->
            <section class="artist-header">
                <div class="artist-info">
                    <div class="verified-badge">
                        <i class="fas fa-check-circle"></i>
                        <span>Verified Artist</span>
                    </div>
                    <h1 class="artist-name"><?= $artist->name ?></h1>
                    <div class="artist-stats">
                        <i class="fas fa-users"></i>
                        <span><?= number_format($artist->monthly_listeners) ?> monthly listeners</span>
                    </div>
                    <div class="artist-actions">
                        <?php if (!empty($current_song)): ?>
                        <button class="btn-play" onclick="(function(){ try{ var s = <?= htmlspecialchars(json_encode($current_song), ENT_QUOTES, 'UTF-8') ?>; if(typeof playSong === 'function'){ playSong(s); } else { console.error('Player not ready'); } }catch(e){console.error(e);} })()">
                            <i class="fas fa-play"></i>
                            PLAY
                        </button>
                        <?php else: ?>
                        <button class="btn-play">
                            <i class="fas fa-play"></i>
                            PLAY
                        </button>
                        <?php endif; ?>

                        <button class="btn-following">
                            <i class="fas fa-check"></i>
                            FOLLOWING
                        </button>
                    </div>
                </div>
                <div class="artist-image">
                    <img src="<?= base_url('assets/images/artists/' . $artist->image) ?>" alt="<?= $artist->name ?>" onerror="this.src='https://ui-avatars.com/api/?name=<?= urlencode($artist->name) ?>&size=400&background=random'">
                </div>
            </section>

            <!-- Popular Releases -->
            <section class="popular-releases">
                <div class="section-header">
                    <h2>Popular Releases</h2>
                    <a href="#" class="see-all">See All</a>
                </div>
                <div class="albums-grid">
                    <?php foreach($albums as $album): ?>
                    <div class="album-card">
                        <div class="album-cover">
                            <img src="<?= base_url('assets/images/albums/' . $album->cover_image) ?>" alt="<?= $album->title ?>" onerror="this.src='https://ui-avatars.com/api/?name=<?= urlencode($album->title) ?>&size=200&background=random'">
                            <button class="play-overlay">
                                <i class="fas fa-play"></i>
                            </button>
                        </div>
                        <div class="album-info">
                            <h3 class="album-title"><?= $album->title ?></h3>
                            <p class="album-meta"><?= $album->release_year ?> • <?= $album->album_type ?></p>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </section>

            <!-- Popular Songs -->
            <section class="popular-songs">
                <div class="section-header">
                    <h2>Popular Song</h2>
                </div>
                <div class="songs-list">
                    <?php $index = 1; foreach($songs as $song): ?>
                    <div class="song-item" data-song-id="<?= $song->id ?>" onclick="playSongFromList(<?= htmlspecialchars(json_encode($song)) ?>)">
                        <div class="song-number"><?= $index ?></div>
                        <div class="song-cover">
                            <img src="<?= base_url('assets/images/albums/' . $song->cover_image) ?>" alt="<?= $song->title ?>" onerror="this.src='https://ui-avatars.com/api/?name=<?= urlencode($song->title) ?>&size=100&background=random'">
                        </div>
                        <div class="song-details">
                            <h4 class="song-title"><?= $song->title ?></h4>
                            <p class="song-artist"><?= $artist->name ?></p>
                        </div>
                        <div class="song-stats">
                            <i class="fas fa-user"></i>
                            <?php
                                // Support both legacy `plays` and uploaded-music `play_count` properties.
                                $play_count_value = 0;
                                if (is_array($song)) {
                                    $play_count_value = isset($song['plays']) ? $song['plays'] : (isset($song['play_count']) ? $song['play_count'] : 0);
                                } else {
                                    $play_count_value = isset($song->plays) ? $song->plays : (isset($song->play_count) ? $song->play_count : 0);
                                }
                            ?>
                            <span><?= number_format($play_count_value) ?></span>
                        </div>
                        <div class="song-duration">
                            <i class="far fa-clock"></i>
                            <span><?= date('i:s', strtotime($song->duration)) ?></span>
                        </div>
                        <div class="song-actions">
                            <button class="btn-like favorite-btn" data-item-id="<?= $song->id ?>" data-type="song">
                                <i class="far fa-heart"></i>
                            </button>
                            <button class="btn-more" onclick="showSongMenu(<?= $song->id ?>, this)">
                                <i class="fas fa-ellipsis-h"></i>
                            </button>
                        </div>
                    </div>
                    <?php $index++; endforeach; ?>
                </div>
            </section>
        </main>

        <!-- Right Sidebar -->
        <?php $this->load->view('partials/right_sidebar'); ?>
    </div>

    <!-- Music Player -->
    <?php $this->load->view('partials/player'); ?>

    <script src="<?= base_url('assets/js/main.js') ?>"></script>
    <script>
        /* Favorite toggling is handled centrally in assets/js/main.js */

        // Show song menu
        function showSongMenu(songId, btn) {
            <?php if($this->session->userdata('logged_in')): ?>
            alert('Song menu for ID: ' + songId + '\nFeatures: Add to playlist, Share, Download');
            <?php else: ?>
            window.location.href = '<?= base_url('auth/login') ?>';
            <?php endif; ?>
        }

        // Play song from list
        function playSongFromList(songData) {
            // Build pageSongList from DOM if not already present or length mismatch
            try {
                const items = document.querySelectorAll('.song-item');
                const parsed = Array.from(items).map(el => {
                    const onclick = el.getAttribute('onclick') || '';
                    const start = onclick.indexOf('(');
                    const end = onclick.lastIndexOf(')');
                    if (start >= 0 && end > start) {
                        const jsonText = onclick.slice(start + 1, end);
                        try { return JSON.parse(jsonText); } catch (e) { return null; }
                    }
                    return null;
                }).filter(Boolean);
                if (parsed.length > 0) window.pageSongList = parsed;
            } catch (e) { console.warn('Failed to build pageSongList from DOM', e); }

            if (typeof playSong === 'function') {
                playSong(songData);
            } else {
                console.error('Player not loaded');
            }
        }
    </script>
    <script>
        // Expose the current page's songs to the player so next/prev can build the queue
        window.pageSongList = <?= json_encode($songs, JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT) ?> || [];
    </script>
</body>
</html>
