<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BeatBay - Radio</title>
    <link rel="stylesheet" href="<?= base_url('assets/css/main.css') ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
</head>
<body>
    <div class="container">
        <!-- Sidebar -->
        <?php $this->load->view('partials/sidebar'); ?>

        <!-- Main Content -->
        <main class="main-content">
            <!-- Header -->
            <?php $this->load->view('partials/header'); ?>

            <!-- Page Title -->
            <section class="page-title-section">
                <div class="radio-hero">
                    <i class="fas fa-radio radio-icon-large"></i>
                    <h1 class="page-title">Radio</h1>
                    <p class="page-subtitle">Listen to personalized radio stations based on your favorite artists and genres</p>
                </div>
            </section>

            <!-- Featured Radio Stations -->
            <section class="featured-radios-section">
                <div class="section-header">
                    <h2>Featured Stations</h2>
                </div>
                <div class="radio-grid">
                    <?php foreach($featured_radios as $radio): ?>
                    <div class="radio-card">
                        <div class="radio-cover">
                            <img src="<?= base_url('assets/images/radio/' . $radio['image']) ?>" alt="<?= $radio['name'] ?>" onerror="this.src='https://ui-avatars.com/api/?name=<?= urlencode($radio['name']) ?>&size=300&background=random'">
                            <div class="radio-overlay">
                                <button class="btn-radio-play">
                                    <i class="fas fa-play"></i>
                                    <span>LISTEN NOW</span>
                                </button>
                            </div>
                            <div class="live-badge">
                                <span class="pulse-dot"></span>
                                LIVE
                            </div>
                        </div>
                        <div class="radio-info">
                            <h3><?= $radio['name'] ?></h3>
                            <p class="radio-description"><?= $radio['description'] ?></p>
                            <div class="radio-listeners">
                                <i class="fas fa-users"></i>
                                <span><?= number_format($radio['listeners']) ?> listening</span>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </section>

            <!-- Genre Radio -->
            <section class="genre-radio-section">
                <div class="section-header">
                    <h2>Genre Stations</h2>
                </div>
                <div class="genre-radio-grid">
                    <?php foreach($genre_radios as $genre): ?>
                    <div class="genre-radio-card" style="background: linear-gradient(135deg, <?= $genre['color'] ?>, <?= $genre['color'] ?>99);">
                        <i class="fas fa-broadcast-tower"></i>
                        <h3><?= $genre['name'] ?></h3>
                        <button class="btn-tune-in">
                            <i class="fas fa-play"></i>
                        </button>
                    </div>
                    <?php endforeach; ?>
                </div>
            </section>

            <!-- Artist Radio -->
            <section class="artist-radio-section">
                <div class="section-header">
                    <h2>Artist Radio</h2>
                    <p class="section-description">Radio stations based on your favorite artists</p>
                </div>
                <div class="artist-radio-grid">
                    <?php foreach($artist_radios as $artist): ?>
                    <div class="artist-radio-card">
                        <div class="artist-radio-image">
                            <img src="<?= base_url('assets/images/artists/' . $artist->image) ?>" alt="<?= $artist->name ?>" onerror="this.src='https://ui-avatars.com/api/?name=<?= urlencode($artist->name) ?>&size=200&background=random'">
                            <div class="radio-badge">
                                <i class="fas fa-radio"></i>
                            </div>
                        </div>
                        <div class="artist-radio-info">
                            <h4><?= $artist->name ?> Radio</h4>
                            <p>Music inspired by <?= $artist->name ?></p>
                            <button class="btn-play-artist-radio">
                                <i class="fas fa-play"></i>
                                Play
                            </button>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </section>

            <!-- Recent Stations -->
            <section class="recent-stations-section">
                <div class="section-header">
                    <h2>Recently Played Stations</h2>
                </div>
                <div class="recent-stations-list">
                    <?php foreach(array_slice($featured_radios, 0, 3) as $radio): ?>
                    <div class="recent-station-item">
                        <div class="recent-station-cover">
                            <img src="<?= base_url('assets/images/radio/' . $radio['image']) ?>" alt="<?= $radio['name'] ?>" onerror="this.src='https://ui-avatars.com/api/?name=<?= urlencode($radio['name']) ?>&size=100&background=random'">
                        </div>
                        <div class="recent-station-info">
                            <h4><?= $radio['name'] ?></h4>
                            <p><?= $radio['description'] ?></p>
                            <div class="station-stats">
                                <span><i class="fas fa-users"></i> <?= number_format($radio['listeners']) ?></span>
                            </div>
                        </div>
                        <button class="btn-station-play">
                            <i class="fas fa-play"></i>
                        </button>
                    </div>
                    <?php endforeach; ?>
                </div>
            </section>

        </main>

        <!-- Right Sidebar -->
        <?php $this->load->view('partials/right_sidebar'); ?>
    </div>

    <!-- Music Player -->
    <?php $this->load->view('partials/player'); ?>

    <script src="<?= base_url('assets/js/main.js') ?>"></script>
</body>
</html>
