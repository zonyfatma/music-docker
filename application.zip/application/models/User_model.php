<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    /**
     * Register new user
     */
    public function register($data) {
        // Hash password
        $data['password'] = password_hash($data['password'], PASSWORD_DEFAULT);
        $data['created_at'] = date('Y-m-d H:i:s');
        $data['updated_at'] = date('Y-m-d H:i:s');
        
        return $this->db->insert('users', $data);
    }

    /**
     * Login user with email/username
     */
    public function login($identifier, $password) {
        // Check if identifier is email or username
        $this->db->where('email', $identifier);
        $this->db->or_where('username', $identifier);
        $query = $this->db->get('users');
        
        if ($query->num_rows() == 1) {
            $user = $query->row();
            
            // Verify password
            if (password_verify($password, $user->password)) {
                return $user;
            }
        }
        
        return false;
    }

    /**
     * Get user by ID
     */
    public function get_user_by_id($user_id) {
        $this->db->where('id', $user_id);
        $query = $this->db->get('users');
        return $query->row();
    }

    /**
     * Get user by email
     */
    public function get_user_by_email($email) {
        $this->db->where('email', $email);
        $query = $this->db->get('users');
        return $query->row();
    }

    /**
     * Get user by username
     */
    public function get_user_by_username($username) {
        $this->db->where('username', $username);
        $query = $this->db->get('users');
        return $query->row();
    }

    /**
     * Check if email exists
     */
    public function email_exists($email) {
        $this->db->where('email', $email);
        $query = $this->db->get('users');
        return $query->num_rows() > 0;
    }

    /**
     * Check if username exists
     */
    public function username_exists($username) {
        $this->db->where('username', $username);
        $query = $this->db->get('users');
        return $query->num_rows() > 0;
    }

    /**
     * Update user profile
     */
    public function update_profile($user_id, $data) {
        $data['updated_at'] = date('Y-m-d H:i:s');
        
        $this->db->where('id', $user_id);
        return $this->db->update('users', $data);
    }

    /**
     * Update user password
     */
    public function update_password($user_id, $new_password) {
        $data = array(
            'password' => password_hash($new_password, PASSWORD_DEFAULT),
            'updated_at' => date('Y-m-d H:i:s')
        );
        
        $this->db->where('id', $user_id);
        return $this->db->update('users', $data);
    }

    /**
     * Update user avatar
     */
    public function update_avatar($user_id, $avatar_path) {
        $data = array(
            'avatar' => $avatar_path,
            'updated_at' => date('Y-m-d H:i:s')
        );
        
        $this->db->where('id', $user_id);
        return $this->db->update('users', $data);
    }

    /**
     * Get or create user from Google OAuth
     */
    public function get_or_create_google_user($google_data) {
        // Check if user exists with google_id
        $this->db->where('google_id', $google_data['id']);
        $query = $this->db->get('users');
        
        if ($query->num_rows() > 0) {
            return $query->row();
        }
        
        // Check if user exists with email
        $this->db->where('email', $google_data['email']);
        $query = $this->db->get('users');
        
        if ($query->num_rows() > 0) {
            // Update with google_id
            $user = $query->row();
            $this->db->where('id', $user->id);
            $this->db->update('users', array('google_id' => $google_data['id']));
            return $user;
        }
        
        // Create new user
        $username = $this->generate_unique_username($google_data['name']);
        $data = array(
            'username' => $username,
            'email' => $google_data['email'],
            'password' => password_hash(uniqid(), PASSWORD_DEFAULT), // Random password
            'full_name' => $google_data['name'],
            'avatar' => $google_data['picture'] ?? null,
            'google_id' => $google_data['id'],
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        );
        
        $this->db->insert('users', $data);
        return $this->get_user_by_id($this->db->insert_id());
    }

    /**
     * Generate unique username
     */
    private function generate_unique_username($name) {
        $base_username = strtolower(str_replace(' ', '_', $name));
        $username = $base_username;
        $counter = 1;
        
        while ($this->username_exists($username)) {
            $username = $base_username . $counter;
            $counter++;
        }
        
        return $username;
    }

    /**
     * Delete user account
     */
    public function delete_user($user_id) {
        $this->db->where('id', $user_id);
        return $this->db->delete('users');
    }

    /**
     * Get total users count
     */
    public function get_total_users() {
        return $this->db->count_all('users');
    }

    /**
     * Get premium users count
     */
    public function get_premium_users_count() {
        $this->db->where('is_premium', 1);
        return $this->db->count_all_results('users');
    }

    /**
     * Upgrade to premium
     */
    public function upgrade_to_premium($user_id) {
        $data = array(
            'is_premium' => 1,
            'updated_at' => date('Y-m-d H:i:s')
        );
        
        $this->db->where('id', $user_id);
        return $this->db->update('users', $data);
    }
}
