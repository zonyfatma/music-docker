<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Music_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    // Get artist by ID with details
    public function get_artist($artist_id) {
        return $this->db->get_where('artists', array('id' => $artist_id))->row();
    }

    // Get all artists
    public function get_all_artists() {
        return $this->db->get('artists')->result();
    }

    // Get popular albums by artist
    public function get_artist_albums($artist_id, $limit = 6) {
        $this->db->where('artist_id', $artist_id);
        $this->db->limit($limit);
        return $this->db->get('albums')->result();
    }

    // Get popular songs by artist
    public function get_artist_songs($artist_id, $limit = 10) {
        $this->db->select('songs.*, albums.cover_image, albums.title as album_title');
        $this->db->from('songs');
        $this->db->join('albums', 'albums.id = songs.album_id', 'left');
        $this->db->where('songs.artist_id', $artist_id);
        $this->db->order_by('songs.plays', 'DESC');
        $this->db->limit($limit);
        return $this->db->get()->result();
    }

    // Get recent played songs
    public function get_recent_plays($limit = 10, $user_id = null) {
        $this->db->select('songs.*, albums.cover_image, artists.name as artist_name, play_history.played_at');
        $this->db->from('play_history');
        $this->db->join('songs', 'songs.id = play_history.song_id');
        $this->db->join('albums', 'albums.id = songs.album_id', 'left');
        $this->db->join('artists', 'artists.id = songs.artist_id');
        
        // Filter by user if provided
        if ($user_id) {
            $this->db->where('play_history.user_id', $user_id);
        }
        
        $this->db->order_by('play_history.played_at', 'DESC');
        $this->db->limit($limit);
        return $this->db->get()->result();
    }

    // Get song details
    public function get_song($song_id) {
        $this->db->select('songs.*, albums.cover_image, albums.title as album_title, artists.name as artist_name');
        $this->db->from('songs');
        $this->db->join('albums', 'albums.id = songs.album_id', 'left');
        $this->db->join('artists', 'artists.id = songs.artist_id');
        $this->db->where('songs.id', $song_id);
        return $this->db->get()->row();
    }

    // Add to recent plays
    public function add_recent_play($song_id, $user_id = null) {
        $data = array(
            'song_id' => $song_id,
            'played_at' => date('Y-m-d H:i:s')
        );
        
        // Add user_id if provided
        if ($user_id) {
            $data['user_id'] = $user_id;
        }
        
        return $this->db->insert('play_history', $data);
    }

    // Update play count
    public function increment_play_count($song_id) {
        $this->db->set('plays', 'plays+1', FALSE);
        $this->db->where('id', $song_id);
        return $this->db->update('songs');
    }

    // Get fans also like (similar artists)
    public function get_similar_artists($artist_id, $limit = 4) {
        $this->db->where('id !=', $artist_id);
        $this->db->order_by('monthly_listeners', 'DESC');
        $this->db->limit($limit);
        return $this->db->get('artists')->result();
    }

    // Search functionality
    public function search($keyword) {
        // Search artists
        $this->db->like('name', $keyword);
        $artists = $this->db->get('artists')->result();

        // Search songs
        $this->db->select('songs.*, artists.name as artist_name, albums.cover_image');
        $this->db->from('songs');
        $this->db->join('artists', 'artists.id = songs.artist_id');
        $this->db->join('albums', 'albums.id = songs.album_id', 'left');
        $this->db->like('songs.title', $keyword);
        $songs = $this->db->get()->result();

        // Search albums
        $this->db->select('albums.*, artists.name as artist_name');
        $this->db->from('albums');
        $this->db->join('artists', 'artists.id = albums.artist_id');
        $this->db->like('albums.title', $keyword);
        $albums = $this->db->get()->result();

        // Search uploaded music (admin uploads)
        $this->db->select('music.music_id, music.title, music.artist, music.album, music.genre, music.duration, music.file_path, music.cover_image, music.play_count');
        $this->db->from('music');
        // search in title, artist and genre
        $this->db->group_start();
        $this->db->like('music.title', $keyword);
        $this->db->or_like('music.artist', $keyword);
        $this->db->or_like('music.genre', $keyword);
        $this->db->group_end();
        // only approved uploads
        $this->db->where('music.status', 'approved');
        $uploaded_music = $this->db->order_by('music.play_count', 'DESC')->limit(50)->get()->result();

        return array(
            'artists' => $artists,
            'songs' => $songs,
            'albums' => $albums,
            'uploaded_music' => $uploaded_music
        );
    }

    // Get all albums with artist info
    public function get_all_albums() {
        $this->db->select('albums.*, artists.name as artist_name');
        $this->db->from('albums');
        $this->db->join('artists', 'artists.id = albums.artist_id');
        $this->db->order_by('albums.created_at', 'DESC');
        return $this->db->get()->result();
    }

    // Get featured albums
    public function get_featured_albums($limit = 12) {
        $this->db->select('albums.*, artists.name as artist_name');
        $this->db->from('albums');
        $this->db->join('artists', 'artists.id = albums.artist_id');
        $this->db->order_by('RAND()');
        $this->db->limit($limit);
        return $this->db->get()->result();
    }

    // Get trending songs
    public function get_trending_songs($limit = 20) {
        $this->db->select('songs.*, albums.cover_image, albums.title as album_title, artists.name as artist_name');
        $this->db->from('songs');
        $this->db->join('albums', 'albums.id = songs.album_id', 'left');
        $this->db->join('artists', 'artists.id = songs.artist_id');
        $this->db->order_by('songs.plays', 'DESC');
        $this->db->limit($limit);
        return $this->db->get()->result();
    }

    // Get new releases
    public function get_new_releases($limit = 8) {
        $this->db->select('albums.*, artists.name as artist_name');
        $this->db->from('albums');
        $this->db->join('artists', 'artists.id = albums.artist_id');
        $this->db->order_by('albums.created_at', 'DESC');
        $this->db->limit($limit);
        return $this->db->get()->result();
    }

    // Get popular albums
    public function get_popular_albums($limit = 6) {
        $this->db->select('albums.*, artists.name as artist_name, SUM(songs.plays) as total_plays');
        $this->db->from('albums');
        $this->db->join('artists', 'artists.id = albums.artist_id');
        $this->db->join('songs', 'songs.album_id = albums.id', 'left');
        $this->db->group_by('albums.id');
        $this->db->order_by('total_plays', 'DESC');
        $this->db->limit($limit);
        return $this->db->get()->result();
    }

    // Get albums by year
    public function get_albums_by_year($year, $limit = 6) {
        $this->db->select('albums.*, artists.name as artist_name');
        $this->db->from('albums');
        $this->db->join('artists', 'artists.id = albums.artist_id');
        $this->db->where('albums.release_year', $year);
        $this->db->limit($limit);
        return $this->db->get()->result();
    }

    // Get album details
    public function get_album_details($album_id) {
        $this->db->select('albums.*, artists.name as artist_name');
        $this->db->from('albums');
        $this->db->join('artists', 'artists.id = albums.artist_id');
        $this->db->where('albums.id', $album_id);
        return $this->db->get()->row();
    }

    // Get album songs
    public function get_album_songs($album_id) {
        $this->db->select('songs.*, artists.name as artist_name');
        $this->db->from('songs');
        $this->db->join('artists', 'artists.id = songs.artist_id');
        $this->db->where('songs.album_id', $album_id);
        $this->db->order_by('songs.id', 'ASC');
        return $this->db->get()->result();
    }

    // Get songs by category (for future implementation)
    public function get_songs_by_category($category, $limit = 20) {
        // For now, return random songs
        $this->db->select('songs.*, albums.cover_image, albums.title as album_title, artists.name as artist_name');
        $this->db->from('songs');
        $this->db->join('albums', 'albums.id = songs.album_id', 'left');
        $this->db->join('artists', 'artists.id = songs.artist_id');
        $this->db->order_by('RAND()');
        $this->db->limit($limit);
        return $this->db->get()->result();
    }

    // Get uploaded music from admin (tabel music)
    public function get_uploaded_music($limit = 50, $status = 'approved') {
        $this->db->select('music.*, users.username as uploaded_by_name');
        $this->db->from('music');
        $this->db->join('users', 'music.upload_by = users.id', 'left');
        
        if ($status) {
            $this->db->where('music.status', $status);
        }
        
        $this->db->order_by('music.created_at', 'DESC');
        $this->db->limit($limit);
        return $this->db->get()->result();
    }

    // Get popular uploaded music ordered by play_count
    public function get_popular_uploaded_music($limit = 8, $status = 'approved') {
        $this->db->select('music.music_id as id, music.title, music.artist as artist_name, music.album, music.cover_image, music.play_count, music.file_path, music.duration');
        $this->db->from('music');
        if ($status) {
            $this->db->where('music.status', $status);
        }
        $this->db->order_by('music.play_count', 'DESC');
        $this->db->limit($limit);
        return $this->db->get()->result();
    }

    // Get uploaded music for a specific artist name
    public function get_uploaded_music_by_artist($artist_name, $limit = 5, $status = 'approved') {
        $this->db->select('music.music_id as id, music.title, music.artist as artist_name, music.album, music.cover_image, music.play_count, music.file_path, music.duration, music.created_at');
        $this->db->from('music');
        if ($status) {
            $this->db->where('music.status', $status);
        }
        // match artist name (case-insensitive)
        $this->db->like('music.artist', $artist_name);
        $this->db->order_by('music.play_count', 'DESC');
        $this->db->limit($limit);
        return $this->db->get()->result();
    }

    // Get uploaded music by genre
    public function get_uploaded_music_by_genre($genre, $limit = 50, $status = 'approved') {
        $this->db->select('music.music_id as id, music.title, music.artist as artist_name, music.album, music.cover_image, music.play_count, music.file_path, music.duration');
        $this->db->from('music');
        if ($status) {
            $this->db->where('music.status', $status);
        }
        // match exact or similar genre text
        $this->db->like('music.genre', $genre);
        $this->db->order_by('music.play_count', 'DESC');
        $this->db->limit($limit);
        return $this->db->get()->result();
    }

    // Group uploaded music into albums (by album title + artist)
    public function get_uploaded_albums($limit = 0) {
        // fetch uploaded music (no limit to allow grouping)
        $this->db->select('music.*');
        $this->db->from('music');
        $this->db->where('music.status', 'approved');
        $this->db->order_by('music.created_at', 'DESC');
        $uploaded = $this->db->get()->result();

        $groups = array();
        foreach ($uploaded as $u) {
            $albumName = trim(!empty($u->album) ? $u->album : $u->title);
            $artistName = trim(!empty($u->artist) ? $u->artist : (isset($u->artist_name) ? $u->artist_name : 'Unknown'));
            $key = strtolower($artistName) . '::' . strtolower($albumName);

            if (!isset($groups[$key])) {
                $grp = new stdClass();
                $grp->title = $albumName;
                $grp->artist_name = $artistName;
                $grp->cover_image = isset($u->cover_image) ? $u->cover_image : '';
                $grp->tracks = array();
                $grp->play_count = 0;
                $grp->latest_date = isset($u->created_at) ? $u->created_at : null;
                $grp->years = array();
                $groups[$key] = $grp;
            }

            $groups[$key]->tracks[] = $u;
            $groups[$key]->play_count += isset($u->play_count) ? intval($u->play_count) : 0;
            if (isset($u->created_at) && $u->created_at) {
                $groups[$key]->years[] = date('Y', strtotime($u->created_at));
                if (!$groups[$key]->latest_date || strtotime($u->created_at) > strtotime($groups[$key]->latest_date)) {
                    $groups[$key]->latest_date = $u->created_at;
                }
            }
        }

        $all_albums = array();
        foreach ($groups as $g) {
            $a = new stdClass();
            $a->title = $g->title;
            $a->artist_name = $g->artist_name;
            $a->cover_image = $g->cover_image;
            $a->release_year = !empty($g->years) ? max($g->years) : '';
            $a->album_type = 'Album';
            $a->track_count = count($g->tracks);
            $a->play_count = $g->play_count;
            $a->latest_date = $g->latest_date;
            $a->tracks = $g->tracks;
            $all_albums[] = $a;
        }

        // sort by latest_date desc
        usort($all_albums, function($x, $y){
            $dx = strtotime($x->latest_date ?: '1970-01-01');
            $dy = strtotime($y->latest_date ?: '1970-01-01');
            return $dy - $dx;
        });

        if ($limit && is_numeric($limit) && $limit > 0) {
            return array_slice($all_albums, 0, intval($limit));
        }
        return $all_albums;
    }

    // Retrieve tracks for a specific uploaded album (artist + album name)
    public function get_uploaded_album_tracks($artist, $album) {
        if (!$artist || !$album) return array();
        $artist_dec = urldecode($artist);
        $album_dec = urldecode($album);

        $this->db->select('music.*');
        $this->db->from('music');
        $this->db->where('music.status', 'approved');
        // case-insensitive match
        $this->db->where("LOWER(music.artist) = ".$this->db->escape(strtolower($artist_dec)));
        $this->db->where("LOWER(IFNULL(music.album, music.title)) = ".$this->db->escape(strtolower($album_dec)));
        // Some schemas do not have a track_number column; fall back to created_at
        $this->db->order_by('music.created_at', 'ASC');
        $res = $this->db->get()->result();
        return $res;
    }

    // Get all music (combine songs and uploaded music)
    public function get_all_music_combined($limit = 50) {
        // Get from songs table
        $this->db->select('
            songs.id,
            songs.title,
            artists.name as artist,
            albums.title as album,
            "" as genre,
            songs.duration,
            songs.audio_file as file_path,
            albums.cover_image,
            songs.plays,
            "songs" as source
        ');
        $this->db->from('songs');
        $this->db->join('artists', 'artists.id = songs.artist_id', 'left');
        $this->db->join('albums', 'albums.id = songs.album_id', 'left');
        
        $songs_query = $this->db->get_compiled_select();
        
        // Get from music table
        $this->db->select('
            music.music_id as id,
            music.title,
            music.artist,
            music.album,
            music.genre,
            music.duration,
            music.file_path,
            music.cover_image,
            music.play_count as plays,
            "music" as source
        ');
        $this->db->from('music');
        $this->db->where('music.status', 'approved');
        
        $music_query = $this->db->get_compiled_select();
        
        // Combine both queries
        $query = $this->db->query($songs_query . ' UNION ALL ' . $music_query . ' ORDER BY plays DESC LIMIT ' . $limit);
        
        return $query->result();
    }

    // Get music by ID from music table
    public function get_uploaded_music_by_id($music_id) {
        $this->db->select('music.*, users.username as uploaded_by_name');
        $this->db->from('music');
        $this->db->join('users', 'music.upload_by = users.id', 'left');
        $this->db->where('music.music_id', $music_id);
        return $this->db->get()->row();
    }

    // Increment play count for uploaded music
    public function increment_music_play_count($music_id) {
        $this->db->set('play_count', 'play_count+1', FALSE);
        $this->db->where('music_id', $music_id);
        return $this->db->update('music');
    }
}
