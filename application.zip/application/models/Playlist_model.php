<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Playlist_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    /**
     * Create new playlist
     */
    public function create_playlist($user_id, $data) {
        $playlist_data = array(
            'user_id' => $user_id,
            'name' => $data['name'],
            'description' => $data['description'] ?? null,
            'cover_image' => $data['cover_image'] ?? null,
            'is_public' => $data['is_public'] ?? 1,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        );
        
        $this->db->insert('playlists', $playlist_data);
        return $this->db->insert_id();
    }

    /**
     * Get user playlists
     */
    public function get_user_playlists($user_id) {
        $this->db->select('playlists.*, COUNT(playlist_songs.id) as song_count');
        $this->db->from('playlists');
        $this->db->join('playlist_songs', 'playlist_songs.playlist_id = playlists.id', 'left');
        $this->db->where('playlists.user_id', $user_id);
        $this->db->group_by('playlists.id');
        $this->db->order_by('playlists.created_at', 'DESC');
        $query = $this->db->get();
        return $query->result();
    }

    /**
     * Get playlist by ID
     */
    public function get_playlist($playlist_id) {
        $this->db->select('playlists.*, users.username, users.full_name');
        $this->db->from('playlists');
        $this->db->join('users', 'users.id = playlists.user_id');
        $this->db->where('playlists.id', $playlist_id);
        $query = $this->db->get();
        return $query->row();
    }

    /**
     * Get playlist songs
     */
    public function get_playlist_songs($playlist_id) {
        $this->db->select('songs.*, artists.name as artist_name, albums.title as album_title, albums.cover_image as album_cover, playlist_songs.position, playlist_songs.added_at');
        $this->db->from('playlist_songs');
        $this->db->join('songs', 'songs.id = playlist_songs.song_id');
        $this->db->join('artists', 'artists.id = songs.artist_id');
        $this->db->join('albums', 'albums.id = songs.album_id', 'left');
        $this->db->where('playlist_songs.playlist_id', $playlist_id);
        $this->db->order_by('playlist_songs.position', 'ASC');
        $query = $this->db->get();
        return $query->result();
    }

    /**
     * Add song to playlist
     */
    public function add_song_to_playlist($playlist_id, $song_id) {
        // Check if song already in playlist
        $this->db->where('playlist_id', $playlist_id);
        $this->db->where('song_id', $song_id);
        $query = $this->db->get('playlist_songs');
        
        if ($query->num_rows() > 0) {
            return false; // Song already in playlist
        }
        
        // Get next position
        $this->db->select_max('position');
        $this->db->where('playlist_id', $playlist_id);
        $query = $this->db->get('playlist_songs');
        $max_position = $query->row()->position ?? 0;
        
        $data = array(
            'playlist_id' => $playlist_id,
            'song_id' => $song_id,
            'position' => $max_position + 1,
            'added_at' => date('Y-m-d H:i:s')
        );
        
        return $this->db->insert('playlist_songs', $data);
    }

    /**
     * Remove song from playlist
     */
    public function remove_song_from_playlist($playlist_id, $song_id) {
        $this->db->where('playlist_id', $playlist_id);
        $this->db->where('song_id', $song_id);
        return $this->db->delete('playlist_songs');
    }

    /**
     * Update playlist
     */
    public function update_playlist($playlist_id, $data) {
        $data['updated_at'] = date('Y-m-d H:i:s');
        
        $this->db->where('id', $playlist_id);
        return $this->db->update('playlists', $data);
    }

    /**
     * Delete playlist
     */
    public function delete_playlist($playlist_id) {
        // playlist_songs will be deleted automatically (ON DELETE CASCADE)
        $this->db->where('id', $playlist_id);
        return $this->db->delete('playlists');
    }

    /**
     * Reorder playlist songs
     */
    public function reorder_songs($playlist_id, $song_orders) {
        foreach ($song_orders as $song_id => $position) {
            $this->db->where('playlist_id', $playlist_id);
            $this->db->where('song_id', $song_id);
            $this->db->update('playlist_songs', array('position' => $position));
        }
        return true;
    }

    /**
     * Check if user owns playlist
     */
    public function is_playlist_owner($playlist_id, $user_id) {
        $this->db->where('id', $playlist_id);
        $this->db->where('user_id', $user_id);
        $query = $this->db->get('playlists');
        return $query->num_rows() > 0;
    }

    /**
     * Get public playlists
     */
    public function get_public_playlists($limit = 20) {
        $this->db->select('playlists.*, users.username, users.full_name, COUNT(playlist_songs.id) as song_count');
        $this->db->from('playlists');
        $this->db->join('users', 'users.id = playlists.user_id');
        $this->db->join('playlist_songs', 'playlist_songs.playlist_id = playlists.id', 'left');
        $this->db->where('playlists.is_public', 1);
        $this->db->group_by('playlists.id');
        $this->db->order_by('playlists.created_at', 'DESC');
        $this->db->limit($limit);
        $query = $this->db->get();
        return $query->result();
    }

    /**
     * Search playlists
     */
    public function search_playlists($keyword, $limit = 20) {
        $this->db->select('playlists.*, users.username, users.full_name, COUNT(playlist_songs.id) as song_count');
        $this->db->from('playlists');
        $this->db->join('users', 'users.id = playlists.user_id');
        $this->db->join('playlist_songs', 'playlist_songs.playlist_id = playlists.id', 'left');
        $this->db->where('playlists.is_public', 1);
        $this->db->like('playlists.name', $keyword);
        $this->db->or_like('playlists.description', $keyword);
        $this->db->group_by('playlists.id');
        $this->db->order_by('playlists.created_at', 'DESC');
        $this->db->limit($limit);
        $query = $this->db->get();
        return $query->result();
    }

    /**
     * Get playlist count by user
     */
    public function get_user_playlist_count($user_id) {
        $this->db->where('user_id', $user_id);
        return $this->db->count_all_results('playlists');
    }

    /**
     * Get total duration of playlist
     */
    public function get_playlist_duration($playlist_id) {
        $this->db->select_sum('songs.duration');
        $this->db->from('playlist_songs');
        $this->db->join('songs', 'songs.id = playlist_songs.song_id');
        $this->db->where('playlist_songs.playlist_id', $playlist_id);
        $query = $this->db->get();
        return $query->row()->duration ?? 0;
    }

    /**
     * Add favorite (song, album, or artist)
     */
    public function add_favorite($user_id, $item_id, $type) {
        // Check if already favorited
        $this->db->where('user_id', $user_id);
        $this->db->where('type', $type);
        
        if ($type === 'song') {
            $this->db->where('song_id', $item_id);
        } elseif ($type === 'album') {
            $this->db->where('album_id', $item_id);
        } elseif ($type === 'artist') {
            $this->db->where('artist_id', $item_id);
        }
        
        $query = $this->db->get('favorites');
        
        if ($query->num_rows() > 0) {
            return false; // Already favorited
        }
        
        $data = array(
            'user_id' => $user_id,
            'type' => $type,
            'created_at' => date('Y-m-d H:i:s')
        );
        
        if ($type === 'song') {
            $data['song_id'] = $item_id;
        } elseif ($type === 'album') {
            $data['album_id'] = $item_id;
        } elseif ($type === 'artist') {
            $data['artist_id'] = $item_id;
        }
        
        return $this->db->insert('favorites', $data);
    }

    /**
     * Remove favorite
     */
    public function remove_favorite($user_id, $item_id, $type) {
        $this->db->where('user_id', $user_id);
        $this->db->where('type', $type);
        
        if ($type === 'song') {
            $this->db->where('song_id', $item_id);
        } elseif ($type === 'album') {
            $this->db->where('album_id', $item_id);
        } elseif ($type === 'artist') {
            $this->db->where('artist_id', $item_id);
        }
        
        return $this->db->delete('favorites');
    }

    /**
     * Check if item is favorited
     */
    public function is_favorited($user_id, $item_id, $type) {
        $this->db->where('user_id', $user_id);
        $this->db->where('type', $type);
        
        if ($type === 'song') {
            $this->db->where('song_id', $item_id);
        } elseif ($type === 'album') {
            $this->db->where('album_id', $item_id);
        } elseif ($type === 'artist') {
            $this->db->where('artist_id', $item_id);
        }
        
        $query = $this->db->get('favorites');
        return $query->num_rows() > 0;
    }

    /**
     * Get user favorite songs
     */
    public function get_favorite_songs($user_id) {
        $this->db->select('songs.*, artists.name as artist_name, albums.title as album_title, albums.cover_image as album_cover, favorites.created_at as favorited_at');
        $this->db->from('favorites');
        $this->db->join('songs', 'songs.id = favorites.song_id');
        $this->db->join('artists', 'artists.id = songs.artist_id');
        $this->db->join('albums', 'albums.id = songs.album_id', 'left');
        $this->db->where('favorites.user_id', $user_id);
        $this->db->where('favorites.type', 'song');
        $this->db->order_by('favorites.created_at', 'DESC');
        $query = $this->db->get();
        return $query->result();
    }

    /**
     * Get user favorite albums
     */
    public function get_favorite_albums($user_id) {
        $this->db->select('albums.*, artists.name as artist_name, favorites.created_at as favorited_at');
        $this->db->from('favorites');
        $this->db->join('albums', 'albums.id = favorites.album_id');
        $this->db->join('artists', 'artists.id = albums.artist_id');
        $this->db->where('favorites.user_id', $user_id);
        $this->db->where('favorites.type', 'album');
        $this->db->order_by('favorites.created_at', 'DESC');
        $query = $this->db->get();
        return $query->result();
    }

    /**
     * Get user favorite artists
     */
    public function get_favorite_artists($user_id) {
        $this->db->select('artists.*, favorites.created_at as favorited_at');
        $this->db->from('favorites');
        $this->db->join('artists', 'artists.id = favorites.artist_id');
        $this->db->where('favorites.user_id', $user_id);
        $this->db->where('favorites.type', 'artist');
        $this->db->order_by('favorites.created_at', 'DESC');
        $query = $this->db->get();
        return $query->result();
    }

    /**
     * Add play history
     */
    public function add_play_history($user_id, $song_id, $duration_played = 0) {
        $data = array(
            'user_id' => $user_id,
            'song_id' => $song_id,
            'played_at' => date('Y-m-d H:i:s'),
            'duration_played' => $duration_played,
            'device' => 'web'
        );
        
        return $this->db->insert('play_history', $data);
    }

    /**
     * Get user play history
     */
    public function get_play_history($user_id, $limit = 50) {
        $this->db->select('songs.*, artists.name as artist_name, albums.title as album_title, albums.cover_image as album_cover, play_history.played_at, play_history.duration_played');
        $this->db->from('play_history');
        $this->db->join('songs', 'songs.id = play_history.song_id');
        $this->db->join('artists', 'artists.id = songs.artist_id');
        $this->db->join('albums', 'albums.id = songs.album_id', 'left');
        $this->db->where('play_history.user_id', $user_id);
        $this->db->order_by('play_history.played_at', 'DESC');
        $this->db->limit($limit);
        $query = $this->db->get();
        return $query->result();
    }

    /**
     * Get recently played (unique songs)
     */
    public function get_recently_played($user_id, $limit = 20) {
        $this->db->select('songs.*, artists.name as artist_name, albums.title as album_title, albums.cover_image as album_cover, MAX(play_history.played_at) as last_played');
        $this->db->from('play_history');
        $this->db->join('songs', 'songs.id = play_history.song_id');
        $this->db->join('artists', 'artists.id = songs.artist_id');
        $this->db->join('albums', 'albums.id = songs.album_id', 'left');
        $this->db->where('play_history.user_id', $user_id);
        $this->db->group_by('songs.id');
        $this->db->order_by('last_played', 'DESC');
        $this->db->limit($limit);
        $query = $this->db->get();
        return $query->result();
    }

    /**
     * Get most played songs
     */
    public function get_most_played($user_id, $limit = 20) {
        $this->db->select('songs.*, artists.name as artist_name, albums.title as album_title, albums.cover_image as album_cover, COUNT(play_history.id) as play_count');
        $this->db->from('play_history');
        $this->db->join('songs', 'songs.id = play_history.song_id');
        $this->db->join('artists', 'artists.id = songs.artist_id');
        $this->db->join('albums', 'albums.id = songs.album_id', 'left');
        $this->db->where('play_history.user_id', $user_id);
        $this->db->group_by('songs.id');
        $this->db->order_by('play_count', 'DESC');
        $this->db->limit($limit);
        $query = $this->db->get();
        return $query->result();
    }
}
