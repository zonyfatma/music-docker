<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Podcast_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    // Add podcast-related methods here for future database integration
    // For now, controllers use static data
}
