<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    // ==========================================
    // STATISTIK DASHBOARD
    // ==========================================
    
    public function get_dashboard_stats() {
        $stats = array();
        
        // Total users
        $stats['total_users'] = $this->db->count_all('users');
        
        // Active users (logged in last 30 days)
        $this->db->where('last_login >=', date('Y-m-d H:i:s', strtotime('-30 days')));
        $stats['active_users'] = $this->db->count_all_results('users');
        
        // New users (registered last 7 days)
        $this->db->where('created_at >=', date('Y-m-d H:i:s', strtotime('-7 days')));
        $stats['new_users'] = $this->db->count_all_results('users');
        
        // Total music
        $stats['total_music'] = $this->db->count_all('music');
        
        // Total podcasts
        $stats['total_podcasts'] = $this->db->count_all('podcasts');
        
        // Total playlists
        $stats['total_playlists'] = $this->db->count_all('playlists');
        
        // Total plays today
        $this->db->where('DATE(played_at) =', date('Y-m-d'));
        $stats['plays_today'] = $this->db->count_all_results('play_history');
        
        // Unread notifications
        $this->db->where('is_read', 0);
        $stats['unread_notifications'] = $this->db->count_all_results('admin_notifications');
        
        // Pending content
        $this->db->where('status', 'pending');
        $pending_music = $this->db->count_all_results('music');
        $this->db->where('status', 'pending');
        $pending_podcasts = $this->db->count_all_results('podcasts');
        $stats['pending_content'] = $pending_music + $pending_podcasts;
        
        return $stats;
    }
    
    public function get_usage_trend($days = 30) {
        $sql = "SELECT DATE(played_at) as date, COUNT(*) as plays
                FROM play_history
                WHERE played_at >= DATE_SUB(NOW(), INTERVAL ? DAY)
                GROUP BY DATE(played_at)
                ORDER BY date ASC";
        
        return $this->db->query($sql, array($days))->result_array();
    }
    
    public function get_user_growth($days = 30) {
        $sql = "SELECT DATE(created_at) as date, COUNT(*) as new_users
                FROM users
                WHERE created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)
                GROUP BY DATE(created_at)
                ORDER BY date ASC";
        
        return $this->db->query($sql, array($days))->result_array();
    }

    // ==========================================
    // MANAJEMEN PENGGUNA
    // ==========================================
    
    public function get_all_users($limit = 50, $offset = 0, $filters = array()) {
        $this->db->select('users.id as user_id, users.username, users.email, users.status, users.created_at, users.last_login, user_roles.role_name');
        $this->db->from('users');
        $this->db->join('user_roles', 'users.role_id = user_roles.role_id', 'left');
        
        // Apply filters
        if (!empty($filters['status'])) {
            $this->db->where('users.status', $filters['status']);
        }
        
        if (!empty($filters['role_id'])) {
            $this->db->where('users.role_id', $filters['role_id']);
        }
        
        if (!empty($filters['search'])) {
            $this->db->group_start();
            $this->db->like('users.username', $filters['search']);
            $this->db->or_like('users.email', $filters['search']);
            $this->db->group_end();
        }
        
        $this->db->order_by('users.created_at', 'DESC');
        $this->db->limit($limit, $offset);
        
        return $this->db->get()->result_array();
    }
    
    public function count_users($filters = array()) {
        $this->db->from('users');
        
        if (!empty($filters['status'])) {
            $this->db->where('status', $filters['status']);
        }
        
        if (!empty($filters['role_id'])) {
            $this->db->where('role_id', $filters['role_id']);
        }
        
        if (!empty($filters['search'])) {
            $this->db->group_start();
            $this->db->like('username', $filters['search']);
            $this->db->or_like('email', $filters['search']);
            $this->db->group_end();
        }
        
        return $this->db->count_all_results();
    }
    
    public function get_user($user_id) {
        $this->db->select('users.id as user_id, users.*, user_roles.role_name');
        $this->db->from('users');
        $this->db->join('user_roles', 'users.role_id = user_roles.role_id', 'left');
        $this->db->where('users.id', $user_id);
        
        return $this->db->get()->row_array();
    }
    
    public function update_user($user_id, $data) {
        $this->db->where('id', $user_id);
        return $this->db->update('users', $data);
    }
    
    public function delete_user($user_id) {
        $this->db->where('id', $user_id);
        return $this->db->delete('users');
    }
    
    public function change_user_status($user_id, $status) {
        $this->db->where('id', $user_id);
        return $this->db->update('users', array('status' => $status));
    }
    
    public function get_user_activity($user_id, $limit = 20) {
        $this->db->select('activity_logs.*');
        $this->db->from('activity_logs');
        $this->db->where('user_id', $user_id);
        $this->db->order_by('created_at', 'DESC');
        $this->db->limit($limit);
        
        return $this->db->get()->result_array();
    }

    // ==========================================
    // MANAJEMEN KONTEN (MUSIK)
    // ==========================================
    
    public function get_all_music($limit = 50, $offset = 0, $filters = array()) {
        $this->db->select('music.*, users.username as uploaded_by_name');
        $this->db->from('music');
        $this->db->join('users', 'music.upload_by = users.id', 'left');
        
        if (!empty($filters['status'])) {
            $this->db->where('music.status', $filters['status']);
        }
        
        if (!empty($filters['search'])) {
            $this->db->group_start();
            $this->db->like('music.title', $filters['search']);
            $this->db->or_like('music.artist', $filters['search']);
            $this->db->group_end();
        }
        
        $this->db->order_by('music.created_at', 'DESC');
        $this->db->limit($limit, $offset);
        
        return $this->db->get()->result_array();
    }
    
    public function count_music($filters = array()) {
        $this->db->from('music');
        
        if (!empty($filters['status'])) {
            $this->db->where('status', $filters['status']);
        }
        
        if (!empty($filters['search'])) {
            $this->db->group_start();
            $this->db->like('title', $filters['search']);
            $this->db->or_like('artist', $filters['search']);
            $this->db->group_end();
        }
        
        return $this->db->count_all_results();
    }
    
    public function get_music($music_id) {
        $this->db->select('music.*, users.username as uploaded_by_name');
        $this->db->from('music');
        $this->db->join('users', 'music.upload_by = users.id', 'left');
        $this->db->where('music.music_id', $music_id);
        
        return $this->db->get()->row_array();
    }
    
    public function update_music($music_id, $data) {
        $this->db->where('music_id', $music_id);
        return $this->db->update('music', $data);
    }
    
    public function delete_music($music_id) {
        $this->db->where('music_id', $music_id);
        return $this->db->delete('music');
    }
    
    public function approve_music($music_id) {
        return $this->update_music($music_id, array('status' => 'approved'));
    }
    
    public function reject_music($music_id) {
        return $this->update_music($music_id, array('status' => 'rejected'));
    }

    // ==========================================
    // MANAJEMEN PODCAST
    // ==========================================
    
    public function get_all_podcasts($limit = 50, $offset = 0, $filters = array()) {
        $this->db->select('podcasts.*, users.username as uploaded_by_name');
        $this->db->from('podcasts');
        $this->db->join('users', 'podcasts.upload_by = users.id', 'left');
        
        if (!empty($filters['status'])) {
            $this->db->where('podcasts.status', $filters['status']);
        }
        
        if (!empty($filters['search'])) {
            $this->db->group_start();
            $this->db->like('podcasts.title', $filters['search']);
            $this->db->or_like('podcasts.host', $filters['search']);
            $this->db->group_end();
        }
        
        $this->db->order_by('podcasts.created_at', 'DESC');
        $this->db->limit($limit, $offset);
        
        return $this->db->get()->result_array();
    }
    
    public function count_podcasts($filters = array()) {
        $this->db->from('podcasts');
        
        if (!empty($filters['status'])) {
            $this->db->where('status', $filters['status']);
        }
        
        if (!empty($filters['search'])) {
            $this->db->group_start();
            $this->db->like('title', $filters['search']);
            $this->db->or_like('host', $filters['search']);
            $this->db->group_end();
        }
        
        return $this->db->count_all_results();
    }
    
    public function get_podcast($podcast_id) {
        $this->db->select('podcasts.*, users.username as uploaded_by_name');
        $this->db->from('podcasts');
        $this->db->join('users', 'podcasts.upload_by = users.id', 'left');
        $this->db->where('podcasts.podcast_id', $podcast_id);
        
        return $this->db->get()->row_array();
    }
    
    public function update_podcast($podcast_id, $data) {
        $this->db->where('podcast_id', $podcast_id);
        return $this->db->update('podcasts', $data);
    }
    
    public function delete_podcast($podcast_id) {
        $this->db->where('podcast_id', $podcast_id);
        return $this->db->delete('podcasts');
    }

    // ==========================================
    // MANAJEMEN PLAYLIST
    // ==========================================
    
    public function get_all_playlists($limit = 50, $offset = 0, $filters = array()) {
        $this->db->select('playlists.id as playlist_id, playlists.name as playlist_name, playlists.*, users.username, COUNT(playlist_songs.id) as song_count');
        $this->db->from('playlists');
        $this->db->join('users', 'playlists.user_id = users.id', 'left');
        $this->db->join('playlist_songs', 'playlists.id = playlist_songs.playlist_id', 'left');
        
        if (!empty($filters['status'])) {
            $this->db->where('playlists.status', $filters['status']);
        }
        
        if (!empty($filters['search'])) {
            $this->db->like('playlists.name', $filters['search']);
        }
        
        $this->db->group_by('playlists.id');
        $this->db->order_by('playlists.created_at', 'DESC');
        $this->db->limit($limit, $offset);
        
        return $this->db->get()->result_array();
    }
    
    public function count_playlists($filters = array()) {
        $this->db->from('playlists');
        
        if (!empty($filters['status'])) {
            $this->db->where('status', $filters['status']);
        }
        
        if (!empty($filters['search'])) {
            $this->db->like('playlist_name', $filters['search']);
        }
        
        return $this->db->count_all_results();
    }
    
    public function delete_playlist($playlist_id) {
        $this->db->where('id', $playlist_id);
        return $this->db->update('playlists', array('status' => 'deleted'));
    }

    // ==========================================
    // NOTIFIKASI
    // ==========================================
    
    public function get_notifications($limit = 20, $unread_only = false) {
        $this->db->select('admin_notifications.*, users.username');
        $this->db->from('admin_notifications');
        $this->db->join('users', 'admin_notifications.user_id = users.id', 'left');
        
        if ($unread_only) {
            $this->db->where('admin_notifications.is_read', 0);
        }
        
        $this->db->order_by('admin_notifications.created_at', 'DESC');
        $this->db->limit($limit);
        
        return $this->db->get()->result_array();
    }
    
    public function mark_notification_read($notification_id) {
        $this->db->where('notification_id', $notification_id);
        return $this->db->update('admin_notifications', array('is_read' => 1));
    }
    
    public function mark_all_notifications_read() {
        $this->db->where('is_read', 0);
        return $this->db->update('admin_notifications', array('is_read' => 1));
    }
    
    public function create_notification($data) {
        return $this->db->insert('admin_notifications', $data);
    }

    // ==========================================
    // LOG AKTIVITAS
    // ==========================================
    
    public function log_activity($user_id, $action, $description = '', $ip_address = '', $user_agent = '') {
        $data = array(
            'user_id' => $user_id,
            'action' => $action,
            'description' => $description,
            'ip_address' => $ip_address,
            'user_agent' => $user_agent
        );
        
        return $this->db->insert('activity_logs', $data);
    }
    
    public function get_activity_logs($limit = 50, $offset = 0, $filters = array()) {
        $this->db->select('activity_logs.*, users.username');
        $this->db->from('activity_logs');
        $this->db->join('users', 'activity_logs.user_id = users.id', 'left');
        
        if (!empty($filters['user_id'])) {
            $this->db->where('activity_logs.user_id', $filters['user_id']);
        }
        
        if (!empty($filters['action'])) {
            $this->db->like('activity_logs.action', $filters['action']);
        }
        
        if (!empty($filters['date_from'])) {
            $this->db->where('DATE(activity_logs.created_at) >=', $filters['date_from']);
        }
        
        if (!empty($filters['date_to'])) {
            $this->db->where('DATE(activity_logs.created_at) <=', $filters['date_to']);
        }
        
        $this->db->order_by('activity_logs.created_at', 'DESC');
        $this->db->limit($limit, $offset);
        
        return $this->db->get()->result_array();
    }
    
    public function count_activity_logs($filters = array()) {
        $this->db->from('activity_logs');
        
        if (!empty($filters['user_id'])) {
            $this->db->where('user_id', $filters['user_id']);
        }
        
        if (!empty($filters['action'])) {
            $this->db->like('action', $filters['action']);
        }
        
        if (!empty($filters['date_from'])) {
            $this->db->where('DATE(created_at) >=', $filters['date_from']);
        }
        
        if (!empty($filters['date_to'])) {
            $this->db->where('DATE(created_at) <=', $filters['date_to']);
        }
        
        return $this->db->count_all_results();
    }

    // ==========================================
    // PENGATURAN SISTEM
    // ==========================================
    
    public function get_all_settings() {
        $query = $this->db->get('system_settings');
        $settings = array();
        
        foreach ($query->result_array() as $row) {
            $settings[$row['setting_key']] = $row['setting_value'];
        }
        
        return $settings;
    }
    
    public function get_setting($key) {
        $this->db->where('setting_key', $key);
        $query = $this->db->get('system_settings');
        
        if ($query->num_rows() > 0) {
            return $query->row()->setting_value;
        }
        
        return null;
    }
    
    public function update_setting($key, $value) {
        $this->db->where('setting_key', $key);
        $existing = $this->db->get('system_settings');
        
        if ($existing->num_rows() > 0) {
            $this->db->where('setting_key', $key);
            return $this->db->update('system_settings', array('setting_value' => $value));
        } else {
            return $this->db->insert('system_settings', array(
                'setting_key' => $key,
                'setting_value' => $value
            ));
        }
    }

    // ==========================================
    // ROLES
    // ==========================================
    
    public function get_all_roles() {
        return $this->db->get('user_roles')->result_array();
    }
    
    public function get_role($role_id) {
        $this->db->where('role_id', $role_id);
        return $this->db->get('user_roles')->row_array();
    }

    // ==========================================
    // LAPORAN
    // ==========================================
    
    public function get_report_data($type, $date_from = null, $date_to = null) {
        switch ($type) {
            case 'users':
                return $this->get_users_report($date_from, $date_to);
            case 'content':
                return $this->get_content_report($date_from, $date_to);
            case 'activity':
                return $this->get_activity_report($date_from, $date_to);
            default:
                return array();
        }
    }
    
    private function get_users_report($date_from, $date_to) {
        $this->db->select('users.*, user_roles.role_name');
        $this->db->from('users');
        $this->db->join('user_roles', 'users.role_id = user_roles.role_id', 'left');
        
        if ($date_from) {
            $this->db->where('DATE(users.created_at) >=', $date_from);
        }
        
        if ($date_to) {
            $this->db->where('DATE(users.created_at) <=', $date_to);
        }
        
        $this->db->order_by('users.created_at', 'DESC');
        
        return $this->db->get()->result_array();
    }
    
    private function get_content_report($date_from, $date_to) {
        $music = $this->db->select('music_id as id, title, artist as creator, play_count, created_at, "music" as type')
                          ->from('music');
        
        if ($date_from) {
            $this->db->where('DATE(created_at) >=', $date_from);
        }
        
        if ($date_to) {
            $this->db->where('DATE(created_at) <=', $date_to);
        }
        
        $music_query = $this->db->get_compiled_select();
        
        $podcasts = $this->db->select('podcast_id as id, title, host as creator, play_count, created_at, "podcast" as type')
                             ->from('podcasts');
        
        if ($date_from) {
            $this->db->where('DATE(created_at) >=', $date_from);
        }
        
        if ($date_to) {
            $this->db->where('DATE(created_at) <=', $date_to);
        }
        
        $podcasts_query = $this->db->get_compiled_select();
        
        $sql = $music_query . ' UNION ALL ' . $podcasts_query . ' ORDER BY created_at DESC';
        
        return $this->db->query($sql)->result_array();
    }
    
    private function get_activity_report($date_from, $date_to) {
        $this->db->select('activity_logs.*, users.username');
        $this->db->from('activity_logs');
        $this->db->join('users', 'activity_logs.user_id = users.id', 'left');
        
        if ($date_from) {
            $this->db->where('DATE(activity_logs.created_at) >=', $date_from);
        }
        
        if ($date_to) {
            $this->db->where('DATE(activity_logs.created_at) <=', $date_to);
        }
        
        $this->db->order_by('activity_logs.created_at', 'DESC');
        
        return $this->db->get()->result_array();
    }
    
    /**
     * Get application settings
     * @return array
     */
    public function get_app_settings() {
        $query = $this->db->get('system_settings');
        $settings = array();

        foreach ($query->result_array() as $row) {
            $settings[$row['setting_key']] = $row['setting_value'];
        }

        return [
            'app_name' => $settings['app_name'] ?? 'Musikk',
            'app_logo' => $settings['app_logo'] ?? '/assets/logo.png',
        ];
    }

    public function get_music_by_id($music_id) {
        return $this->db->get_where('music', array('music_id' => $music_id))->row();
    }

    public function insert_music($data) {
        return $this->db->insert('music', $data);
    }
}
